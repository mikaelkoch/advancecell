"use client";

import { ServiceOrder, Client, Product, ServiceType, ServiceOrderStatus, STATUS_LABELS, STATUS_COLORS, STATUS_FLOW } from "@/lib/types";
import { Modal, ConfirmDialog } from "@/components/ui/Modal";
import { ChangeEvent, FormEvent, useState, useEffect } from "react";
import API from "@/lib/api";

const openPDF = (orderId: string) => {
  window.open(`/api/service-orders/${orderId}/pdf`, "_blank");
};

interface ServiceOrderManagerProps {
  clients: Client[];
  products: Product[];
  serviceTypes: ServiceType[];
  onDataChange: () => void;
}

export function ServiceOrderManager({ clients, products, serviceTypes, onDataChange }: ServiceOrderManagerProps) {
  const [orders, setOrders] = useState<ServiceOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<ServiceOrder | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<ServiceOrder | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [filterStatus, setFilterStatus] = useState<ServiceOrderStatus | "">("");
  const [search, setSearch] = useState("");

  const [form, setForm] = useState({
    clientId: "",
    deviceBrand: "",
    deviceModel: "",
    deviceSerial: "",
    deviceImei: "",
    defectDesc: "",
    accessories: "",
    diagnosis: "",
    solution: "",
    technician: "",
    warrantyDays: "90",
    discount: "0",
    paidAmount: "0",
    paymentMethod: "",
    notes: "",
    estimatedDate: "",
    items: [] as { productId: string; quantity: number; unitPrice: string }[],
    services: [] as { serviceTypeId: string; quantity: number; unitPrice: string; notes: string }[],
  });

  const fetchData = async () => {
    const data = await API.serviceOrders.list({ status: filterStatus || undefined, search: search || undefined });
    setOrders(data);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, [filterStatus, search]);

  const calculateTotals = () => {
    const partsPrice = form.items.reduce((sum, i) => sum + i.quantity * parseFloat(i.unitPrice), 0);
    const laborPrice = form.services.reduce((sum, s) => sum + s.quantity * parseFloat(s.unitPrice), 0);
    const discount = parseFloat(form.discount) || 0;
    return { partsPrice, laborPrice, totalPrice: partsPrice + laborPrice - discount };
  };

  const sendWhatsAppNotification = async (order: ServiceOrder, type: "OS_CREATED" | "OS_STATUS_CHANGED" | "OS_READY" | "OS_DELIVERED", extraData?: Record<string, string>) => {
    const clientPhone = order.client.whatsapp || order.client.phone;
    if (!clientPhone) return;

    const data = {
      orderNumber: order.orderNumber.toString(),
      clientName: order.client.name,
      deviceBrand: order.deviceBrand,
      deviceModel: order.deviceModel,
      defectDesc: order.defectDesc,
      newStatus: STATUS_LABELS[order.status] || order.status,
      totalPrice: Number(order.totalPrice).toFixed(2).replace(".", ","),
      paidAmount: Number(order.paidAmount).toFixed(2).replace(".", ","),
      pendingAmount: (Number(order.totalPrice) - Number(order.paidAmount)).toFixed(2).replace(".", ","),
      warrantyDays: order.warrantyDays.toString(),
      ...extraData,
    };

    await API.whatsapp.send({
      type,
      to: clientPhone,
      serviceOrderId: order.id,
      clientId: order.clientId,
      data,
    });
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const { partsPrice, laborPrice, totalPrice } = calculateTotals();
      const payload = {
        ...form,
        items: form.items.map(i => ({ productId: i.productId, quantity: i.quantity, unitPrice: parseFloat(i.unitPrice) })),
        services: form.services.map(s => ({ serviceTypeId: s.serviceTypeId, quantity: s.quantity, unitPrice: parseFloat(s.unitPrice), notes: s.notes })),
        laborPrice, partsPrice, discount: parseFloat(form.discount) || 0, totalPrice,
        paidAmount: parseFloat(form.paidAmount) || 0,
        estimatedDate: form.estimatedDate || null,
      };
      let savedOrder: ServiceOrder;
      if (editing) {
        await API.serviceOrders.update(editing.id, payload);
        savedOrder = { ...editing, ...payload } as ServiceOrder;
      } else {
        const result = await API.serviceOrders.create(payload);
        savedOrder = result;
      }
      closeModal();
      onDataChange();

      if (!editing) {
        sendWhatsAppNotification(savedOrder, "OS_CREATED");
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    await API.serviceOrders.delete(confirmDelete.id);
    setConfirmDelete(null);
    onDataChange();
  };

  const handleEdit = async (order: ServiceOrder) => {
    setEditing(order);
    setForm({
      clientId: order.clientId,
      deviceBrand: order.deviceBrand,
      deviceModel: order.deviceModel,
      deviceSerial: order.deviceSerial || "",
      deviceImei: order.deviceImei || "",
      defectDesc: order.defectDesc,
      accessories: order.accessories || "",
      diagnosis: order.diagnosis || "",
      solution: order.solution || "",
      technician: order.technician || "",
      warrantyDays: order.warrantyDays.toString(),
      discount: order.discount.toString(),
      paidAmount: order.paidAmount.toString(),
      paymentMethod: order.paymentMethod || "",
      notes: order.notes || "",
      estimatedDate: order.estimatedDate ? order.estimatedDate.split("T")[0] : "",
      items: order.items.map(i => ({ productId: i.productId, quantity: i.quantity, unitPrice: i.unitPrice.toString() })),
      services: order.services.map(s => ({ serviceTypeId: s.serviceTypeId, quantity: s.quantity, unitPrice: s.unitPrice.toString(), notes: s.notes || "" })),
    });
    setShowModal(true);
  };

  const handleNew = () => {
    setEditing(null);
    setForm({
      clientId: clients[0]?.id || "",
      deviceBrand: "", deviceModel: "", deviceSerial: "", deviceImei: "",
      defectDesc: "", accessories: "", diagnosis: "", solution: "", technician: "",
      warrantyDays: "90", discount: "0", paidAmount: "0", paymentMethod: "", notes: "", estimatedDate: "",
      items: [], services: [],
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditing(null);
    setForm({
      clientId: clients[0]?.id || "",
      deviceBrand: "", deviceModel: "", deviceSerial: "", deviceImei: "",
      defectDesc: "", accessories: "", diagnosis: "", solution: "", technician: "",
      warrantyDays: "90", discount: "0", paidAmount: "0", paymentMethod: "", notes: "", estimatedDate: "",
      items: [], services: [],
    });
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const addItem = () => setForm(prev => ({ ...prev, items: [...prev.items, { productId: "", quantity: 1, unitPrice: "" }] }));
  const removeItem = (idx: number) => setForm(prev => ({ ...prev, items: prev.items.filter((_, i) => i !== idx) }));
  const updateItem = (idx: number, field: string, value: string) => setForm(prev => ({ ...prev, items: prev.items.map((i, i2) => i2 === idx ? { ...i, [field]: value } : i) }));

  const addService = () => setForm(prev => ({ ...prev, services: [...prev.services, { serviceTypeId: "", quantity: 1, unitPrice: "", notes: "" }] }));
  const removeService = (idx: number) => setForm(prev => ({ ...prev, services: prev.services.filter((_, i) => i !== idx) }));
  const updateService = (idx: number, field: string, value: string) => setForm(prev => ({ ...prev, services: prev.services.map((s, i) => i === idx ? { ...s, [field]: value } : s) }));

  const canTransition = (current: ServiceOrderStatus, next: ServiceOrderStatus) => STATUS_FLOW[current]?.includes(next) ?? false;

  const handleStatusChange = async (order: ServiceOrder, newStatus: ServiceOrderStatus) => {
    if (!canTransition(order.status, newStatus)) return;
    await API.serviceOrders.update(order.id, { status: newStatus });
    onDataChange();

    const updatedOrder = { ...order, status: newStatus };
    
    if (newStatus === "READY") {
      sendWhatsAppNotification(updatedOrder, "OS_READY");
    } else if (newStatus === "DELIVERED") {
      sendWhatsAppNotification(updatedOrder, "OS_DELIVERED");
    } else {
      sendWhatsAppNotification(updatedOrder, "OS_STATUS_CHANGED");
    }
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  return (
    <div>
      <div className="mb-6">
        <div className="flex flex-wrap gap-2 mb-4">
          {(["RECEIVED", "DIAGNOSING", "WAITING_APPROVAL", "IN_REPAIR", "READY", "DELIVERED", "CANCELLED"] as ServiceOrderStatus[]).map(s => (
            <button
              key={s}
              onClick={() => setFilterStatus(filterStatus === s ? "" : s)}
              className={`px-3 py-1 rounded-full text-xs font-medium ${filterStatus === s ? STATUS_COLORS[s] : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}
            >
              {STATUS_LABELS[s]}
            </button>
          ))}
        </div>
        <div className="flex justify-between items-center">
          <input
            type="text"
            placeholder="Buscar por #OS, cliente, modelo..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg w-64 focus:ring-2 focus:ring-blue-500"
          />
          <button onClick={handleNew} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">+ Nova OS</button>
        </div>
      </div>

      {orders.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl shadow-sm">
          <p className="text-gray-500 mb-4">Nenhuma ordem de serviço</p>
          <button onClick={handleNew} className="bg-blue-600 text-white px-4 py-2 rounded-lg">Criar primeira OS</button>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">#OS</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Cliente</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Aparelho</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Total</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Pago</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {orders.map(order => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm font-mono text-gray-900">#{order.orderNumber.toString().padStart(6, "0")}</td>
                  <td className="px-6 py-4">
                    <p className="text-sm font-medium text-gray-900">{order.client.name}</p>
                    <p className="text-xs text-gray-500">{order.client.phone}</p>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {order.deviceBrand} {order.deviceModel}
                    {order.deviceSerial && <p className="text-xs">SN: {order.deviceSerial}</p>}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${STATUS_COLORS[order.status]}`}>
                      {STATUS_LABELS[order.status]}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right text-sm font-medium text-gray-900">
                    R$ {Number(order.totalPrice).toFixed(2).replace(".", ",")}
                  </td>
                  <td className="px-6 py-4 text-center text-sm text-gray-500">
                    R$ {Number(order.paidAmount).toFixed(2).replace(".", ",")}
                    {Number(order.paidAmount) < Number(order.totalPrice) && (
                      <span className="text-red-500 ml-1">⚠</span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button onClick={() => openPDF(order.id)} className="text-green-600 hover:text-green-900 text-sm font-medium">PDF</button>
                      <button onClick={() => handleEdit(order)} className="text-blue-600 hover:text-blue-900 text-sm font-medium">Editar</button>
                      <button onClick={() => setConfirmDelete(order)} className="text-red-600 hover:text-red-900 text-sm font-medium">Excluir</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <Modal
          title={editing ? `Editar OS #${editing.orderNumber.toString().padStart(6, "0")}` : "Nova Ordem de Serviço"}
          onClose={closeModal}
          onSubmit={handleSubmit}
          submitting={submitting}
          submitLabel={editing ? "Atualizar" : "Criar"}
          extraActions={editing && (
            <button
              type="button"
              onClick={() => openPDF(editing.id)}
              className="px-3 py-1 text-sm text-green-600 hover:text-green-800 border border-green-300 rounded-lg hover:bg-green-50"
            >
              📄 PDF
            </button>
          )}
        >
          <div className="space-y-6 max-h-[70vh] overflow-y-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Cliente *</label>
                <select name="clientId" value={form.clientId} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                  <option value="">Selecione</option>
                  {clients.map(c => <option key={c.id} value={c.id}>{c.name} - {c.phone}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Marca *</label>
                <input type="text" name="deviceBrand" value={form.deviceBrand} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Modelo *</label>
                <input type="text" name="deviceModel" value={form.deviceModel} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nº Série</label>
                <input type="text" name="deviceSerial" value={form.deviceSerial} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">IMEI</label>
                <input type="text" name="deviceImei" value={form.deviceImei} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Garantia (dias)</label>
                <input type="number" name="warrantyDays" value={form.warrantyDays} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Técnico</label>
                <input type="text" name="technician" value={form.technician} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Previsão Entrega</label>
                <input type="date" name="estimatedDate" value={form.estimatedDate} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Defeito Relatado *</label>
              <textarea name="defectDesc" value={form.defectDesc} onChange={handleChange} rows={3} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Acessórios Entregues</label>
              <textarea name="accessories" value={form.accessories} onChange={handleChange} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>

            {editing && (
              <div className="border-t pt-4">
                <h4 className="font-medium mb-2">Alterar Status</h4>
                <div className="flex flex-wrap gap-2">
                  {STATUS_FLOW[editing.status].map(s => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => handleStatusChange(editing, s)}
                      className={`px-3 py-1 rounded-full text-xs font-medium ${STATUS_COLORS[s]}`}
                    >
                      {STATUS_LABELS[s]}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="border-t pt-4">
              <div className="flex justify-between items-center mb-2">
                <h4 className="font-medium">Peças/Produtos</h4>
                <button type="button" onClick={addItem} className="text-sm text-blue-600 hover:text-blue-700">+ Adicionar</button>
              </div>
              <div className="space-y-2">
                {form.items.length === 0 && <p className="text-sm text-gray-500 text-center py-4">Nenhum produto adicionado</p>}
                {form.items.map((item, idx) => (
                  <div key={idx} className="flex gap-2 p-2 bg-gray-50 rounded">
                    <select
                      value={item.productId}
                      onChange={e => updateItem(idx, "productId", e.target.value)}
                      className="flex-1 px-2 py-1 border border-gray-300 rounded text-sm"
                    >
                      <option value="">Selecione produto</option>
                      {products.filter(p => p.active).map(p => (
                        <option key={p.id} value={p.id}>{p.name} - R$ {Number(p.price).toFixed(2)} (Est: {p.stock})</option>
                      ))}
                    </select>
                    <input
                      type="number" min="1" value={item.quantity}
                      onChange={e => updateItem(idx, "quantity", e.target.value)}
                      className="w-16 px-2 py-1 border border-gray-300 rounded text-sm"
                    />
                    <input
                      type="number" step="0.01" min="0" value={item.unitPrice}
                      onChange={e => updateItem(idx, "unitPrice", e.target.value)}
                      className="w-24 px-2 py-1 border border-gray-300 rounded text-sm"
                      placeholder="Preço unit."
                    />
                    <button type="button" onClick={() => removeItem(idx)} className="text-red-500 hover:text-red-700">×</button>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t pt-4">
              <div className="flex justify-between items-center mb-2">
                <h4 className="font-medium">Serviços</h4>
                <button type="button" onClick={addService} className="text-sm text-blue-600 hover:text-blue-700">+ Adicionar</button>
              </div>
              <div className="space-y-2">
                {form.services.length === 0 && <p className="text-sm text-gray-500 text-center py-4">Nenhum serviço adicionado</p>}
                {form.services.map((svc, idx) => (
                  <div key={idx} className="flex gap-2 p-2 bg-gray-50 rounded">
                    <select
                      value={svc.serviceTypeId}
                      onChange={e => updateService(idx, "serviceTypeId", e.target.value)}
                      className="flex-1 px-2 py-1 border border-gray-300 rounded text-sm"
                    >
                      <option value="">Selecione serviço</option>
                      {serviceTypes.filter(s => s.active).map(s => (
                        <option key={s.id} value={s.id}>{s.name} - R$ {Number(s.price).toFixed(2)}</option>
                      ))}
                    </select>
                    <input
                      type="number" min="1" value={svc.quantity}
                      onChange={e => updateService(idx, "quantity", e.target.value)}
                      className="w-16 px-2 py-1 border border-gray-300 rounded text-sm"
                    />
                    <input
                      type="number" step="0.01" min="0" value={svc.unitPrice}
                      onChange={e => updateService(idx, "unitPrice", e.target.value)}
                      className="w-24 px-2 py-1 border border-gray-300 rounded text-sm"
                      placeholder="Preço unit."
                    />
                    <input
                      type="text" value={svc.notes}
                      onChange={e => updateService(idx, "notes", e.target.value)}
                      className="flex-1 px-2 py-1 border border-gray-300 rounded text-sm"
                      placeholder="Obs."
                    />
                    <button type="button" onClick={() => removeService(idx)} className="text-red-500 hover:text-red-700">×</button>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t pt-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Desconto</label>
                <input type="number" step="0.01" min="0" name="discount" value={form.discount} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Pago</label>
                <input type="number" step="0.01" min="0" name="paidAmount" value={form.paidAmount} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Forma Pagamento</label>
                <select name="paymentMethod" value={form.paymentMethod} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                  <option value="">Selecione</option>
                  <option value="DINHEIRO">Dinheiro</option>
                  <option value="CARTAO_CREDITO">Cartão Crédito</option>
                  <option value="CARTAO_DEBITO">Cartão Débito</option>
                  <option value="PIX">PIX</option>
                  <option value="TRANSFERENCIA">Transferência</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Diagnóstico</label>
              <textarea name="diagnosis" value={form.diagnosis} onChange={handleChange} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Solução</label>
              <textarea name="solution" value={form.solution} onChange={handleChange} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Observações Internas</label>
              <textarea name="notes" value={form.notes} onChange={handleChange} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>

            {editing && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium mb-2">Totais</h4>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div><span className="text-gray-500">Peças:</span> <span className="font-medium ml-2">R$ {calculateTotals().partsPrice.toFixed(2).replace(".", ",")}</span></div>
                  <div><span className="text-gray-500">Mão de obra:</span> <span className="font-medium ml-2">R$ {calculateTotals().laborPrice.toFixed(2).replace(".", ",")}</span></div>
                  <div><span className="text-gray-500">Total:</span> <span className="font-bold text-lg ml-2">R$ {calculateTotals().totalPrice.toFixed(2).replace(".", ",")}</span></div>
                </div>
              </div>
            )}
          </div>
        </Modal>
      )}

      {confirmDelete && (
        <ConfirmDialog open={true} onClose={() => setConfirmDelete(null)} onConfirm={handleDelete} title="Excluir OS" message={`Excluir OS #${confirmDelete.orderNumber.toString().padStart(6, "0")}?`} />
      )}
    </div>
  );
}