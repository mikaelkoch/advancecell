export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  imageUrl: string | null;
  _count: { products: number };
  createdAt: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  price: number;
  costPrice: number | null;
  stock: number;
  minStock: number;
  sku: string | null;
  barcode: string | null;
  imageUrl: string | null;
  active: boolean;
  featured: boolean;
  categoryId: string;
  category: Category;
  createdAt: string;
}

export interface Client {
  id: string;
  name: string;
  email: string | null;
  phone: string;
  whatsapp: string | null;
  cpfCnpj: string | null;
  address: string | null;
  neighborhood: string | null;
  city: string | null;
  state: string | null;
  zipCode: string | null;
  notes: string | null;
  _count: { serviceOrders: number };
  createdAt: string;
  serviceOrders?: ServiceOrder[];
}

export type ServiceOrderStatus =
  | "RECEIVED"
  | "DIAGNOSING"
  | "WAITING_APPROVAL"
  | "IN_REPAIR"
  | "READY"
  | "DELIVERED"
  | "CANCELLED";

export interface ServiceOrderItem {
  id: string;
  serviceOrderId: string;
  productId: string;
  product: Product;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  createdAt: string;
}

export interface ServiceOrderService {
  id: string;
  serviceOrderId: string;
  serviceTypeId: string;
  serviceType: ServiceType;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  notes: string | null;
  createdAt: string;
}

export interface ServiceType {
  id: string;
  name: string;
  description: string | null;
  price: number;
  durationMin: number;
  active: boolean;
  createdAt: string;
}

export interface ServiceOrder {
  id: string;
  orderNumber: number;
  status: ServiceOrderStatus;
  clientId: string;
  client: Client;
  deviceBrand: string;
  deviceModel: string;
  deviceSerial: string | null;
  deviceImei: string | null;
  defectDesc: string;
  accessories: string | null;
  diagnosis: string | null;
  solution: string | null;
  technician: string | null;
  warrantyDays: number;
  laborPrice: number;
  partsPrice: number;
  discount: number;
  totalPrice: number;
  paidAmount: number;
  paymentMethod: string | null;
  notes: string | null;
  estimatedDate: string | null;
  startedAt: string | null;
  finishedAt: string | null;
  deliveredAt: string | null;
  createdAt: string;
  updatedAt: string;
  items: ServiceOrderItem[];
  services: ServiceOrderService[];
}

export const STATUS_LABELS: Record<ServiceOrderStatus, string> = {
  RECEIVED: "Recebido",
  DIAGNOSING: "Diagnosticando",
  WAITING_APPROVAL: "Aguardando Aprovação",
  IN_REPAIR: "Em Reparo",
  READY: "Pronto",
  DELIVERED: "Entregue",
  CANCELLED: "Cancelado",
};

export const STATUS_COLORS: Record<ServiceOrderStatus, string> = {
  RECEIVED: "bg-blue-100 text-blue-800",
  DIAGNOSING: "bg-purple-100 text-purple-800",
  WAITING_APPROVAL: "bg-yellow-100 text-yellow-800",
  IN_REPAIR: "bg-orange-100 text-orange-800",
  READY: "bg-green-100 text-green-800",
  DELIVERED: "bg-gray-100 text-gray-800",
  CANCELLED: "bg-red-100 text-red-800",
};

export const STATUS_FLOW: Record<ServiceOrderStatus, ServiceOrderStatus[]> = {
  RECEIVED: ["DIAGNOSING", "CANCELLED"],
  DIAGNOSING: ["WAITING_APPROVAL", "IN_REPAIR", "CANCELLED"],
  WAITING_APPROVAL: ["IN_REPAIR", "CANCELLED", "DIAGNOSING"],
  IN_REPAIR: ["READY", "WAITING_APPROVAL", "CANCELLED"],
  READY: ["DELIVERED", "IN_REPAIR", "CANCELLED"],
  DELIVERED: [],
  CANCELLED: [],
};

export type CashRegisterStatus = "OPEN" | "CLOSED";

export type CashMovementType =
  | "OPENING"
  | "CLOSING"
  | "SALE"
  | "REFUND"
  | "SANGRIA"
  | "SUPRIMENTO"
  | "EXPENSE";

export interface CashRegister {
  id: string;
  sessionNumber: number;
  status: CashRegisterStatus;
  openedBy: string;
  closedBy: string | null;
  openedAt: string;
  closedAt: string | null;
  openingAmount: number;
  closingAmount: number | null;
  expectedAmount: number | null;
  difference: number | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  movements?: CashMovement[];
  summary?: CashRegisterSummary;
}

export interface CashMovement {
  id: string;
  cashRegisterId: string;
  type: CashMovementType;
  paymentMethod: string | null;
  amount: number;
  description: string | null;
  serviceOrderId: string | null;
  serviceOrder?: { orderNumber: number; client: { name: string } } | null;
  createdBy: string;
  createdAt: string;
}

export interface CashRegisterSummary {
  sales: number;
  refunds: number;
  sangrias: number;
  suprimentos: number;
  expenses: number;
  netSales: number;
  expectedClosing: number;
  salesByMethod: Record<string, number>;
}

export const MOVEMENT_TYPE_LABELS: Record<CashMovementType, string> = {
  OPENING: "Abertura",
  CLOSING: "Fechamento",
  SALE: "Venda",
  REFUND: "Estorno",
  SANGRIA: "Sangria",
  SUPRIMENTO: "Suprimento",
  EXPENSE: "Despesa",
};

export const MOVEMENT_TYPE_COLORS: Record<CashMovementType, string> = {
  OPENING: "bg-green-100 text-green-800",
  CLOSING: "bg-blue-100 text-blue-800",
  SALE: "bg-emerald-100 text-emerald-800",
  REFUND: "bg-red-100 text-red-800",
  SANGRIA: "bg-orange-100 text-orange-800",
  SUPRIMENTO: "bg-purple-100 text-purple-800",
  EXPENSE: "bg-gray-100 text-gray-800",
};

export type WhatsAppProvider = "TWILIO" | "META" | "ZENVIA" | "WATI" | "GUPSHUP" | "MOCK";

export type WhatsAppMessageType =
  | "OS_CREATED"
  | "OS_STATUS_CHANGED"
  | "OS_READY"
  | "OS_DELIVERED"
  | "PAYMENT_REMINDER"
  | "LOW_STOCK"
  | "CUSTOM";

export type WhatsAppMessageStatus = "PENDING" | "SENT" | "DELIVERED" | "READ" | "FAILED";

export interface WhatsAppSettings {
  id: string;
  provider: WhatsAppProvider;
  phoneNumber: string;
  accountSid: string | null;
  authToken: string | null;
  apiUrl: string | null;
  apiKey: string | null;
  templatePrefix: string | null;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface WhatsAppLog {
  id: string;
  type: WhatsAppMessageType;
  to: string;
  message: string;
  status: WhatsAppMessageStatus;
  providerId: string | null;
  errorMessage: string | null;
  serviceOrderId: string | null;
  serviceOrder: { orderNumber: number } | null;
  clientId: string | null;
  client: { name: string } | null;
  createdAt: string;
  sentAt: string | null;
  deliveredAt: string | null;
  readAt: string | null;
}

export const WHATSAPP_PROVIDERS: { value: WhatsAppProvider; label: string; fields: string[] }[] = [
  { value: "MOCK", label: "Mock (Desenvolvimento)", fields: [] },
  { value: "TWILIO", label: "Twilio", fields: ["accountSid", "authToken", "phoneNumber"] },
  { value: "META", label: "WhatsApp Business API (Meta)", fields: ["apiUrl", "apiKey", "phoneNumber"] },
  { value: "ZENVIA", label: "Zenvia", fields: ["apiKey", "phoneNumber"] },
  { value: "WATI", label: "Wati", fields: ["apiUrl", "apiKey"] },
  { value: "GUPSHUP", label: "Gupshup", fields: ["apiKey", "phoneNumber"] },
];

export const MESSAGE_TYPE_LABELS: Record<WhatsAppMessageType, string> = {
  OS_CREATED: "OS Criada",
  OS_STATUS_CHANGED: "Status Alterado",
  OS_READY: "OS Pronta",
  OS_DELIVERED: "OS Entregue",
  PAYMENT_REMINDER: "Lembrete Pagamento",
  LOW_STOCK: "Estoque Baixo",
  CUSTOM: "Personalizada",
};

export const MESSAGE_STATUS_COLORS: Record<WhatsAppMessageStatus, string> = {
  PENDING: "bg-yellow-100 text-yellow-800",
  SENT: "bg-blue-100 text-blue-800",
  DELIVERED: "bg-green-100 text-green-800",
  READ: "bg-purple-100 text-purple-800",
  FAILED: "bg-red-100 text-red-800",
};