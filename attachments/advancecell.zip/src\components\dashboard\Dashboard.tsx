"use client";

import { useState, useEffect } from "react";
import API from "@/lib/api";
import { format } from "date-fns";

interface KPIs {
  totalClients: number;
  totalProducts: number;
  totalServiceOrders: number;
  ordersPeriod: number;
  revenue: number;
  paid: number;
  pending: number;
  avgTicket: number;
}

interface DashboardData {
  period: string;
  kpis: KPIs;
  ordersByStatus: { status: string; count: number }[];
  topServices: { name: string; quantity: number; revenue: number; count: number }[];
  topProducts: { name: string; quantity: number; revenue: number; count: number }[];
  lowStockProducts: { id: string; name: string; stock: number; minStock: number; category: string }[];
  monthlyRevenue: { month: string; revenue: number; orders: number }[];
}

const STATUS_LABELS: Record<string, string> = {
  RECEIVED: "Recebido",
  DIAGNOSING: "Diagnosticando",
  WAITING_APPROVAL: "Aguardando Aprovação",
  IN_REPAIR: "Em Reparo",
  READY: "Pronto",
  DELIVERED: "Entregue",
  CANCELLED: "Cancelado",
};

const STATUS_COLORS: Record<string, string> = {
  RECEIVED: "bg-blue-500",
  DIAGNOSING: "bg-purple-500",
  WAITING_APPROVAL: "bg-yellow-500",
  IN_REPAIR: "bg-orange-500",
  READY: "bg-green-500",
  DELIVERED: "bg-gray-500",
  CANCELLED: "bg-red-500",
};

export function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<"today" | "week" | "month" | "year">("month");

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await API.dashboard.get(period);
      setData(res);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [period]);

  const formatCurrency = (v: number) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  if (!data) return <div className="text-center py-12 text-gray-500">Erro ao carregar dashboard</div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <div className="flex gap-2">
          {(["today", "week", "month", "year"] as const).map(p => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
                period === p ? "bg-blue-600 text-white" : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              {p === "today" ? "Hoje" : p === "week" ? "7 dias" : p === "month" ? "30 dias" : "12 meses"}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Clientes" value={data.kpis.totalClients} icon="👥" color="bg-blue-500" />
        <KPICard title="Produtos Ativos" value={data.kpis.totalProducts} icon="📦" color="bg-green-500" />
        <KPICard title="OS no Período" value={data.kpis.ordersPeriod} icon="🔧" color="bg-purple-500" />
        <KPICard title="Ticket Médio" value={formatCurrency(data.kpis.avgTicket)} icon="💰" color="bg-orange-500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm p-6">
          <h3 className="font-bold mb-4">Faturamento por Mês</h3>
          <div className="h-64 flex items-end gap-2">
            {data.monthlyRevenue.map((m, i) => (
              <div key={m.month} className="flex-1 flex flex-col items-center">
                <div
                  className="w-full bg-blue-600 rounded-t transition-all hover:bg-blue-500"
                  style={{ height: `${data.monthlyRevenue.length > 0 ? (m.revenue / Math.max(...data.monthlyRevenue.map(x => x.revenue)) * 100) : 0}%` }}
                  title={formatCurrency(m.revenue)}
                ></div>
                <span className="text-xs text-gray-500 mt-2">{m.month}</span>
                <span className="text-xs font-medium text-gray-900">{formatCurrency(m.revenue)}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="font-bold mb-4">OS por Status</h3>
          <div className="space-y-3">
            {data.ordersByStatus.map(s => (
              <div key={s.status} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full ${STATUS_COLORS[s.status]}`}></div>
                  <span className="text-sm">{STATUS_LABELS[s.status] || s.status}</span>
                </div>
                <span className="font-medium">{s.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="font-bold mb-4">Top 10 Serviços</h3>
          <div className="space-y-2">
            {data.topServices.length === 0 ? (
              <p className="text-gray-500 text-center py-4">Nenhum serviço no período</p>
            ) : (
              data.topServices.map((s, i) => (
                <div key={s.name} className="flex items-center justify-between py-2 border-b last:border-0">
                  <div className="flex items-center gap-3">
                    <span className="w-6 text-center text-gray-400">{i + 1}</span>
                    <span className="text-sm truncate max-w-[200px]">{s.name}</span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{s.quantity}x</p>
                    <p className="text-xs text-gray-500">{formatCurrency(s.revenue)}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="font-bold mb-4">Top 10 Produtos Vendidos</h3>
          <div className="space-y-2">
            {data.topProducts.length === 0 ? (
              <p className="text-gray-500 text-center py-4">Nenhum produto vendido no período</p>
            ) : (
              data.topProducts.map((p, i) => (
                <div key={p.name} className="flex items-center justify-between py-2 border-b last:border-0">
                  <div className="flex items-center gap-3">
                    <span className="w-6 text-center text-gray-400">{i + 1}</span>
                    <span className="text-sm truncate max-w-[200px]">{p.name}</span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{p.quantity}x</p>
                    <p className="text-xs text-gray-500">{formatCurrency(p.revenue)}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {data.lowStockProducts.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-yellow-500">
          <h3 className="font-bold mb-4 flex items-center gap-2 text-yellow-800">
            ⚠ {data.lowStockProducts.length} Produto(s) com Estoque Baixo
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-gray-500 border-b">
                  <th className="pb-2">Produto</th>
                  <th className="pb-2 text-center">Estoque</th>
                  <th className="pb-2 text-center">Mínimo</th>
                  <th className="pb-2">Categoria</th>
                </tr>
              </thead>
              <tbody>
                {data.lowStockProducts.map(p => (
                  <tr key={p.id} className="border-b last:border-0">
                    <td className="py-2 font-medium">{p.name}</td>
                    <td className="py-2 text-center text-red-600 font-bold">{p.stock}</td>
                    <td className="py-2 text-center text-gray-500">{p.minStock}</td>
                    <td className="py-2 text-gray-500">{p.category}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-green-500">
          <h3 className="font-bold mb-2 text-green-800">Faturamento Total</h3>
          <p className="text-3xl font-bold">{formatCurrency(data.kpis.revenue)}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-blue-500">
          <h3 className="font-bold mb-2 text-blue-800">Recebido</h3>
          <p className="text-3xl font-bold">{formatCurrency(data.kpis.paid)}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-orange-500">
          <h3 className="font-bold mb-2 text-orange-800">A Receber</h3>
          <p className="text-3xl font-bold">{formatCurrency(data.kpis.pending)}</p>
        </div>
      </div>
    </div>
  );
}

function KPICard({ title, value, icon, color }: { title: string; value: string | number; icon: string; color: string }) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-500">{title}</p>
          <p className="text-2xl font-bold mt-1">{value}</p>
        </div>
        <div className={`${color} p-3 rounded-xl text-2xl`}>{icon}</div>
      </div>
    </div>
  );
}