"use client";

import { useState, useEffect } from "react";
import API from "@/lib/api";
import { format, parseISO } from "date-fns";

type ReportType = "sales" | "products" | "services" | "clients" | "technician" | "payment" | "abc";

const REPORT_TYPES: { id: ReportType; label: string; icon: string }[] = [
  { id: "sales", label: "Vendas/Faturamento", icon: "💰" },
  { id: "products", label: "Produtos Vendidos", icon: "📦" },
  { id: "services", label: "Serviços Realizados", icon: "🔧" },
  { id: "clients", label: "Clientes", icon: "👥" },
  { id: "technician", label: "Por Técnico", icon: "👨‍🔧" },
  { id: "payment", label: "Formas de Pagamento", icon: "💳" },
  { id: "abc", label: "Curva ABC", icon: "📈" },
];

const formatCurrency = (v: number) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export function Reports() {
  const [activeReport, setActiveReport] = useState<ReportType>("sales");
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [startDate, setStartDate] = useState(format(subDays(new Date(), 30), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [groupBy, setGroupBy] = useState<"day" | "month">("day");

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await API.reports.get(activeReport, startDate, endDate, groupBy);
      setData(res);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [activeReport, startDate, endDate, groupBy]);

  const exportCSV = () => {
    if (!data?.data) return;
    const headers = Object.keys(data.data[0] || {}).join(",");
    const rows = data.data.map((row: any) => Object.values(row).map(v => `"${v}"`).join(",")).join("\n");
    const csv = headers + "\n" + rows;
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `relatorio-${activeReport}-${startDate}-a-${endDate}.csv`;
    link.click();
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-2xl font-bold">Relatórios</h1>
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex gap-2">
            <label className="text-sm text-gray-600">De:</label>
            <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="px-3 py-2 border border-gray-300 rounded-lg" />
            <label className="text-sm text-gray-600">Até:</label>
            <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="px-3 py-2 border border-gray-300 rounded-lg" />
          </div>
          {activeReport === "sales" && (
            <select value={groupBy} onChange={e => setGroupBy(e.target.value as "day" | "month")} className="px-3 py-2 border border-gray-300 rounded-lg">
              <option value="day">Por Dia</option>
              <option value="month">Por Mês</option>
            </select>
          )}
          <button onClick={exportCSV} disabled={!data?.data?.length} className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 disabled:opacity-50">Exportar CSV</button>
        </div>
      </div>

      <div className="flex gap-1 overflow-x-auto pb-2" role="tablist">
        {REPORT_TYPES.map(t => (
          <button
            key={t.id}
            role="tab"
            aria-selected={activeReport === t.id}
            onClick={() => setActiveReport(t.id)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${activeReport === t.id ? "bg-blue-600 text-white" : "text-gray-600 hover:bg-gray-100"}`}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {data?.summary && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {Object.entries(data.summary).map(([key, value]) => (
            <div key={key} className="bg-white rounded-xl shadow-sm p-4">
              <p className="text-sm text-gray-500">{key.replace(/([A-Z])/g, " $1").replace(/^./, c => c.toUpperCase())}</p>
              <p className="text-2xl font-bold mt-1">{typeof value === "number" ? formatCurrency(value) : value}</p>
            </div>
          ))}
        </div>
      )}

      {data?.data && data.data.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  {getColumns(activeReport).map(col => (
                    <th key={col.key} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{col.label}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {data.data.map((row: any, i: number) => (
                  <tr key={row.productId || row.serviceTypeId || row.clientId || row.technician || row.method || row.date || i} className="hover:bg-gray-50">
                    {getColumns(activeReport).map(col => (
                      <td key={col.key} className="px-6 py-4 text-sm">
                        {col.format ? col.format(row[col.key]) : row[col.key]}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {data?.data && data.data.length === 0 && (
        <div className="text-center py-12 bg-white rounded-xl shadow-sm">
          <p className="text-gray-500">Nenhum dado encontrado para o período selecionado</p>
        </div>
      )}
    </div>
  );
}

function getColumns(type: ReportType) {
  switch (type) {
    case "sales":
      return [
        { key: "date", label: "Data" },
        { key: "orders", label: "OS" },
        { key: "revenue", label: "Faturamento", format: formatCurrency },
        { key: "partsRevenue", label: "Peças", format: formatCurrency },
        { key: "laborRevenue", label: "Mão de Obra", format: formatCurrency },
        { key: "paid", label: "Recebido", format: formatCurrency },
        { key: "pending", label: "A Receber", format: formatCurrency },
      ];
    case "products":
      return [
        { key: "name", label: "Produto" },
        { key: "category", label: "Categoria" },
        { key: "sku", label: "SKU" },
        { key: "quantity", label: "Qtd" },
        { key: "revenue", label: "Receita", format: formatCurrency },
        { key: "cost", label: "Custo", format: formatCurrency },
        { key: "margin", label: "Margem", format: (v: any, row: any) => formatCurrency(row.revenue - row.cost) },
      ];
    case "services":
      return [
        { key: "name", label: "Serviço" },
        { key: "quantity", label: "Qtd" },
        { key: "revenue", label: "Receita", format: formatCurrency },
        { key: "avgPrice", label: "Preço Médio", format: formatCurrency },
      ];
    case "clients":
      return [
        { key: "name", label: "Cliente" },
        { key: "phone", label: "Telefone" },
        { key: "orders", label: "OS" },
        { key: "totalSpent", label: "Total Gasto", format: formatCurrency },
        { key: "lastOrder", label: "Última OS", format: (d: string) => format(parseISO(d), "dd/MM/yyyy") },
      ];
    case "technician":
      return [
        { key: "technician", label: "Técnico" },
        { key: "orders", label: "OS" },
        { key: "revenue", label: "Faturamento", format: formatCurrency },
        { key: "partsRevenue", label: "Peças", format: formatCurrency },
        { key: "laborRevenue", label: "Mão de Obra", format: formatCurrency },
      ];
    case "payment":
      return [
        { key: "method", label: "Forma" },
        { key: "count", label: "Qtd" },
        { key: "paid", label: "Recebido", format: formatCurrency },
        { key: "total", label: "Total OS", format: formatCurrency },
      ];
    case "abc":
      return [
        { key: "name", label: "Produto" },
        { key: "revenue", label: "Receita", format: formatCurrency },
        { key: "percent", label: "% Acumulado", format: (v: number) => `${v}%` },
        { key: "curve", label: "Curva", format: (v: string) => `<span className="px-2 py-1 text-xs font-medium rounded-full ${v === "A" ? "bg-green-100 text-green-800" : v === "B" ? "bg-yellow-100 text-yellow-800" : "bg-gray-100 text-gray-800"}">${v}</span>` },
      ];
  }
}

// Helper to access row data in format function
function subDays(date: Date, days: number) {
  const result = new Date(date);
  result.setDate(result.getDate() - days);
  return result;
}