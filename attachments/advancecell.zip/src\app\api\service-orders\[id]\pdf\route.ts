import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { generateServiceOrderPDF } from "@/lib/pdf";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  const order = await prisma.serviceOrder.findUnique({
    where: { id },
    include: {
      client: true,
      items: { include: { product: true } },
      services: { include: { serviceType: true } },
    },
  });

  if (!order) {
    return NextResponse.json({ error: "OS não encontrada" }, { status: 404 });
  }

  try {
    const pdfBlob = await generateServiceOrderPDF(order as any);
    const arrayBuffer = await pdfBlob.arrayBuffer();
    
    return new NextResponse(arrayBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `inline; filename="OS-${order.orderNumber.toString().padStart(6, "0")}.pdf"`,
        "Content-Length": arrayBuffer.byteLength.toString(),
      },
    });
  } catch (error) {
    console.error("Erro ao gerar PDF:", error);
    return NextResponse.json({ error: "Erro ao gerar PDF" }, { status: 500 });
  }
}