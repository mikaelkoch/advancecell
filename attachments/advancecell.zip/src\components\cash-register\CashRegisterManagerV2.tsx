"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { Plus, Search, ChevronDown, DollarSign, TrendingUp, TrendingDown, Minus, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Modal } from "@/components/ui/Modal";
import { Badge } from "@/components/ui/Badge";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/Table";
import { DropdownMenu } from "@/components/ui/Dropdown";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { CashRegister, CashMovement, CashMovementType, CashRegisterSummary, MOVEMENT_TYPE_LABELS, MOVEMENT_TYPE_COLORS } from "@/lib/types";
import { format, formatCurrency } from "@/lib/utils";
import API from "@/lib/api";
import { ChangeEvent, FormEvent, useState, useEffect } from "react";

interface CashRegisterManagerV2Props {
  onDataChange: () => void;
}

export function CashRegisterManagerV2({ onDataChange }: CashRegisterManagerV2Props) {
  const [registers, setRegisters] = useState<CashRegister[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [filterStatus, setFilterStatus] = useState<"all" | "OPEN" | "CLOSED">("all");
  const [showModal, setShowModal] = useState(false);
  const [viewingRegister, setViewingRegister] = useState<CashRegister | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [openForm, setOpenForm] = useState({ openingAmount: "", notes: "" });
  const [movementForm, setMovementForm] = useState({
    type: "SALE" as CashMovementType,
    amount: "",
    description: "",
    paymentMethod: "",
  });
  const [addingMovement, setAddingMovement] = useState(false);
  const [closeForm, setCloseForm] = useState({ closingAmount: "", notes: "" });

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await API.cashRegister.list(filterStatus !== "all" ? filterStatus : undefined, page);
      setRegisters(res.data);
      setTotalPages(res.totalPages);
    } catch (error) {
      console.error("Erro ao carregar caixa:", error);
      setRegisters([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [page, filterStatus]);

  const handleOpenRegister = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await API.cashRegister.open(parseFloat(openForm.openingAmount), openForm.notes, "Sistema");
      setShowModal(false);
      setOpenForm({ openingAmount: "", notes: "" });
      onDataChange();
    } finally {
      setSubmitting(false);
    }
  };

  const handleCloseRegister = async (e: FormEvent) => {
    e.preventDefault();
    if (!viewingRegister) return;
    setSubmitting(true);
    try {
      await API.cashRegister.close(viewingRegister.id, parseFloat(closeForm.closingAmount), closeForm.notes, "Sistema");
      setViewingRegister(null);
      setCloseForm({ closingAmount: "", notes: "" });
      onDataChange();
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddMovement = async (e: FormEvent) => {
    e.preventDefault();
    if (!viewingRegister) return;
    setAddingMovement(true);
    try {
      await API.cashMovements.create({
        cashRegisterId: viewingRegister.id,
        type: movementForm.type,
        amount: parseFloat(movementForm.amount),
        description: movementForm.description,
        paymentMethod: movementForm.paymentMethod || undefined,
        createdBy: "Sistema",
      });
      setMovementForm({ type: "SALE", amount: "", description: "", paymentMethod: "" });
      onDataChange();
    } finally {
      setAddingMovement(false);
    }
  };

  const viewRegister = async (register: CashRegister) => {
    const detail = await API.cashRegister.get(register.id);
    setViewingRegister(detail);
  };

  const canAddMovement = viewingRegister?.status === "OPEN";

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  const openRegister = registers.find(r => r.status === "OPEN");

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Controle de Caixa</h1>
          <p className="text-gray-500 mt-1">Gerencie aberturas, fechamentos e movimentações financeiras.</p>
        </div>
        <div className="flex items-center gap-4">
          <Select
            value={filterStatus}
            onChange={e => { setFilterStatus(e.target.value as "all" | "OPEN" | "CLOSED"); setPage(1); }}
            options={[
              { value: "all", label: "Todos" },
              { value: "OPEN", label: "Aberto" },
              { value: "CLOSED", label: "Fechado" },
            ]}
            className="w-40"
          />
          {!openRegister && (
            <Button onClick={() => setShowModal(true)} className="bg-green-600 hover:bg-green-700">
              <Plus className="h-4 w-4 mr-2" /> Abrir Caixa
            </Button>
          )}
        </div>
      </div>

      {openRegister && (
        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-3 w-3 bg-green-500 rounded-full animate-pulse" />
                <div>
                  <p className="font-medium text-green-800">Caixa Aberto - Sessão #{openRegister.sessionNumber}</p>
                  <p className="text-sm text-green-600">Aberto por {openRegister.openedBy} em {format(new Date(openRegister.openedAt), "dd/MM/yyyy HH:mm")}</p>
                </div>
              </div>
              <Button onClick={() => viewRegister(openRegister)} className="bg-green-600 hover:bg-green-700">Gerenciar</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {registers.length === 0 ? (
        <div className="text-center py-12 card bg-white rounded-xl border border-gray-200">
          <DollarSign className="h-12 w-12 mx-auto text-gray-300 mb-3" />
          <h3 className="text-lg font-medium text-gray-900 mb-1">Nenhuma sessão de caixa</h3>
          <p className="text-gray-500 mb-4">Abra o primeiro caixa para começar</p>
          {!openRegister && <Button onClick={() => setShowModal(true)} className="bg-green-600 hover:bg-green-700"><Plus className="h-4 w-4 mr-2" /> Abrir primeiro caixa</Button>}
        </div>
      ) : (
        <div className="card bg-white rounded-xl border border-gray-200 overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-20">Sessão</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Abertura</TableHead>
                <TableHead>Fechamento</TableHead>
                <TableHead className="w-32 text-right">Abertura</TableHead>
                <TableHead className="w-32 text-right">Fechamento</TableHead>
                <TableHead className="w-28 text-right">Diferença</TableHead>
                <TableHead className="w-24">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {registers.map(reg => (
                <TableRow key={reg.id}>
                  <TableCell className="font-mono text-gray-900">#{reg.sessionNumber.toString().padStart(6, "0")}</TableCell>
                  <TableCell>
                    <Badge variant={reg.status === "OPEN" ? "success" : "secondary"}>{reg.status === "OPEN" ? "Aberto" : "Fechado"}</Badge>
                  </TableCell>
                  <TableCell className="text-gray-500">{format(new Date(reg.openedAt), "dd/MM/yyyy HH:mm")}</TableCell>
                  <TableCell className="text-gray-500">{reg.closedAt ? format(new Date(reg.closedAt), "dd/MM/yyyy HH:mm") : "-"}</TableCell>
                  <TableCell className="text-right font-medium text-gray-900">{formatCurrency(reg.openingAmount)}</TableCell>
                  <TableCell className="text-right font-medium text-gray-900">{reg.closingAmount ? formatCurrency(reg.closingAmount) : "-"}</TableCell>
                  <TableCell className="text-right">
                    {reg.difference !== null && (
                      <Badge variant={reg.difference >= 0 ? "success" : "destructive"}>
                        {reg.difference >= 0 ? "+" : ""}{formatCurrency(reg.difference)}
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon" onClick={() => viewRegister(reg)}><MoreHorizontal className="h-4 w-4" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-4">
              <Button variant="outline" size="sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}>Anterior</Button>
              <span className="px-3 text-sm text-gray-600">{page} / {totalPages}</span>
              <Button variant="outline" size="sm" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}>Próximo</Button>
            </div>
          )}
        </div>
      )}

      {showModal && (
        <Modal
          open={true}
          onClose={() => setShowModal(false)}
          title="Abrir Caixa"
          description="Informe o valor inicial do caixa"
        >
          <form onSubmit={handleOpenRegister} className="space-y-6">
            <div className="space-y-4">
              <Input label="Valor de Abertura *" name="openingAmount" type="number" step="0.01" min="0" value={openForm.openingAmount} onChange={e => setOpenForm(prev => ({ ...prev, openingAmount: e.target.value }))} required placeholder="0,00" />
              <label className="block text-sm font-medium text-gray-700 mb-1">Observações</label>
              <textarea name="notes" value={openForm.notes} onChange={e => setOpenForm(prev => ({ ...prev, notes: e.target.value }))} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent" />
            </div>
            <div className="flex justify-end gap-3 border-t pt-6">
              <Button type="button" variant="outline" onClick={() => setShowModal(false)}>Cancelar</Button>
              <Button type="submit" loading={submitting} className="bg-green-600 hover:bg-green-700">{submitting ? "Abrindo..." : "Abrir Caixa"}</Button>
            </div>
          </form>
        </Modal>
      )}

      {viewingRegister && (
        <Modal
          open={true}
          onClose={() => setViewingRegister(null)}
          title={`Caixa #${viewingRegister.sessionNumber.toString().padStart(6, "0")}`}
          size="xl"
        >
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card><CardContent className="p-4"><p className="text-sm text-green-700">Abertura</p><p className="text-2xl font-bold text-green-900">{formatCurrency(viewingRegister.openingAmount)}</p></CardContent></Card>
              <Card><CardContent className="p-4"><p className="text-sm text-blue-700">Vendas Líquidas</p><p className="text-2xl font-bold text-blue-900">{formatCurrency(viewingRegister.summary?.netSales || 0)}</p></CardContent></Card>
              <Card><CardContent className="p-4"><p className="text-sm text-purple-700">Suprimentos</p><p className="text-2xl font-bold text-purple-900">{formatCurrency(viewingRegister.summary?.suprimentos || 0)}</p></CardContent></Card>
              <Card><CardContent className="p-4"><p className="text-sm text-orange-700">Sangrias</p><p className="text-2xl font-bold text-orange-900">{formatCurrency(viewingRegister.summary?.sangrias || 0)}</p></CardContent></Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card><CardContent className="p-4"><p className="text-sm text-gray-700">Despesas</p><p className="text-2xl font-bold text-gray-900">{formatCurrency(viewingRegister.summary?.expenses || 0)}</p></CardContent></Card>
              <Card><CardContent className="p-4"><p className="text-sm text-indigo-700">Esperado no Fechamento</p><p className="text-2xl font-bold text-indigo-900">{formatCurrency(viewingRegister.summary?.expectedClosing || 0)}</p></CardContent></Card>
              <Card><CardContent className={viewingRegister.closingAmount ? "p-4 bg-emerald-50" : "p-4 bg-yellow-50"}><p className="text-sm text-gray-700">Fechamento Real</p><p className="text-2xl font-bold">{viewingRegister.closingAmount ? formatCurrency(viewingRegister.closingAmount) : "Aberto"}</p></CardContent></Card>
              <Card><CardContent className={cn("p-4", (viewingRegister.difference ?? 0) >= 0 ? "bg-green-50" : "bg-red-50")}><p className="text-sm text-gray-700">Diferença</p><p className={cn("text-2xl font-bold", (viewingRegister.difference ?? 0) >= 0 ? "text-green-900" : "text-red-900")}>{(viewingRegister.difference ?? 0) >= 0 ? "+" : ""}{formatCurrency(viewingRegister.difference ?? 0)}</p></CardContent></Card>
            </div>

            {viewingRegister.summary?.salesByMethod && Object.keys(viewingRegister.summary.salesByMethod).length > 0 && (
              <Card>
                <CardHeader><CardTitle>Vendas por Forma de Pagamento</CardTitle></CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {Object.entries(viewingRegister.summary.salesByMethod).map(([method, value]) => (
                      <Card key={method} className="bg-gray-50"><CardContent className="p-3"><p className="text-xs text-gray-500">{method}</p><p className="font-medium">{formatCurrency(value)}</p></CardContent></Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {viewingRegister.status === "OPEN" && (
              <>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle>Movimentações</CardTitle>
                    <Badge variant="success">CAIXA ABERTO</Badge>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {viewingRegister.movements?.map((mov: CashMovement, i: number) => (
                        <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <Badge variant={MOVEMENT_TYPE_COLORS[mov.type].replace("bg-", "").replace("-100", "").replace("-800", "") as any}>{MOVEMENT_TYPE_LABELS[mov.type]}</Badge>
                            <div>
                              <p className="text-sm font-medium">{mov.description}</p>
                              {mov.paymentMethod && <p className="text-xs text-gray-500">{mov.paymentMethod}</p>}
                              {mov.serviceOrder && <p className="text-xs text-gray-400">OS #{mov.serviceOrder.orderNumber} - {mov.serviceOrder.client.name}</p>}
                            </div>
                          </div>
                          <span className={cn("text-sm font-medium", ["SALE", "OPENING", "SUPRIMENTO"].includes(mov.type) ? "text-green-600" : "text-red-600")}>
                            {["SALE", "OPENING", "SUPRIMENTO"].includes(mov.type) ? "+" : "-"}{formatCurrency(mov.amount)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader><CardTitle>Nova Movimentação</CardTitle></CardHeader>
                  <CardContent>
                    <form onSubmit={handleAddMovement} className="space-y-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Select
                        label="Tipo"
                        name="type"
                        value={movementForm.type}
                        onChange={e => setMovementForm(prev => ({ ...prev, type: e.target.value as CashMovementType }))}
                        options={[
                          { value: "SALE", label: "Venda" },
                          { value: "REFUND", label: "Estorno" },
                          { value: "SANGRIA", label: "Sangria" },
                          { value: "SUPRIMENTO", label: "Suprimento" },
                          { value: "EXPENSE", label: "Despesa" },
                        ]}
                      />
                      <Input label="Valor *" name="amount" type="number" step="0.01" min="0.01" value={movementForm.amount} onChange={e => setMovementForm(prev => ({ ...prev, amount: e.target.value }))} required />
                      <Select
                        label="Forma de Pagamento"
                        name="paymentMethod"
                        value={movementForm.paymentMethod}
                        onChange={e => setMovementForm(prev => ({ ...prev, paymentMethod: e.target.value }))}
                        options={[
                          { value: "", label: "Selecione" },
                          { value: "DINHEIRO", label: "Dinheiro" },
                          { value: "CARTAO_CREDITO", label: "Cartão Crédito" },
                          { value: "CARTAO_DEBITO", label: "Cartão Débito" },
                          { value: "PIX", label: "PIX" },
                          { value: "TRANSFERENCIA", label: "Transferência" },
                        ]}
                      />
                      <Input label="Descrição" name="description" value={movementForm.description} onChange={e => setMovementForm(prev => ({ ...prev, description: e.target.value }))} placeholder="Ex: Sangria para depósito" className="md:col-span-2" />
                      <div className="md:col-span-2 flex justify-end">
                        <Button type="submit" loading={addingMovement} className="bg-blue-600 hover:bg-blue-700">{addingMovement ? "Adicionando..." : "Adicionar Movimentação"}</Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>

                <Card className="bg-green-50 border-green-200">
                  <CardHeader><CardTitle>Fechar Caixa</CardTitle></CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-3">Valor esperado: <strong>{formatCurrency(viewingRegister.summary?.expectedClosing || 0)}</strong></p>
                    <form onSubmit={handleCloseRegister} className="space-y-4">
                      <Input label="Valor Contado no Caixa *" name="closingAmount" type="number" step="0.01" min="0" value={closeForm.closingAmount} onChange={e => setCloseForm(prev => ({ ...prev, closingAmount: e.target.value }))} required placeholder="0,00" />
                      <label className="block text-sm font-medium text-gray-700 mb-1">Observações</label>
                      <textarea name="notes" value={closeForm.notes} onChange={e => setCloseForm(prev => ({ ...prev, notes: e.target.value }))} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent" />
                      <Button type="submit" loading={submitting} className="w-full bg-green-600 hover:bg-green-700">{submitting ? "Fechando..." : "Fechar Caixa"}</Button>
                    </form>
                  </CardContent>
                </Card>
              </>
            )}

            {viewingRegister.status === "CLOSED" && (
              <Card className="bg-gray-50">
                <CardContent className="p-4 text-center">
                  <p className="text-gray-600">Este caixa foi fechado por {viewingRegister.closedBy} em {viewingRegister.closedAt ? format(new Date(viewingRegister.closedAt), "dd/MM/yyyy HH:mm") : ""}</p>
                </CardContent>
              </Card>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
}