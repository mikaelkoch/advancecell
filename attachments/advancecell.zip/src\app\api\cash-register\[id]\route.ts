import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { CashRegisterStatus, CashMovementType } from "@prisma/client";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const register = await prisma.cashRegister.findUnique({
    where: { id },
    include: {
      movements: {
        orderBy: { createdAt: "asc" },
        include: { serviceOrder: { select: { orderNumber: true, client: { select: { name: true } } } } },
      },
    },
  });

  if (!register) {
    return NextResponse.json({ error: "Caixa não encontrado" }, { status: 404 });
  }

  const salesByMethod = register.movements
    .filter(m => [CashMovementType.SALE, CashMovementType.REFUND].includes(m.type))
    .reduce((acc, m) => {
      const key = m.paymentMethod || "Não informado";
      acc[key] = (acc[key] || 0) + Number(m.amount);
      return acc;
    }, {} as Record<string, number>);

  const sangrias = register.movements
    .filter(m => m.type === CashMovementType.SANGRIA)
    .reduce((s, m) => s + Number(m.amount), 0);

  const suprimentos = register.movements
    .filter(m => m.type === CashMovementType.SUPRIMENTO)
    .reduce((s, m) => s + Number(m.amount), 0);

  const expenses = register.movements
    .filter(m => m.type === CashMovementType.EXPENSE)
    .reduce((s, m) => s + Number(m.amount), 0);

  const sales = register.movements
    .filter(m => m.type === CashMovementType.SALE)
    .reduce((s, m) => s + Number(m.amount), 0);

  const refunds = register.movements
    .filter(m => m.type === CashMovementType.REFUND)
    .reduce((s, m) => s + Number(m.amount), 0);

  const expectedClosing = Number(register.openingAmount) + sales - refunds + suprimentos - sangrias - expenses;

  return NextResponse.json({
    ...register,
    openingAmount: Number(register.openingAmount),
    closingAmount: register.closingAmount ? Number(register.closingAmount) : null,
    expectedAmount: register.expectedAmount ? Number(register.expectedAmount) : null,
    difference: register.difference ? Number(register.difference) : null,
    summary: {
      sales,
      refunds,
      sangrias,
      suprimentos,
      expenses,
      netSales: sales - refunds,
      expectedClosing,
      salesByMethod,
    },
  });
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await request.json();
  const { action, closingAmount, notes, closedBy } = body;

  const register = await prisma.cashRegister.findUnique({
    where: { id },
    include: { movements: true },
  });

  if (!register) {
    return NextResponse.json({ error: "Caixa não encontrado" }, { status: 404 });
  }

  if (register.status === CashRegisterStatus.CLOSED) {
    return NextResponse.json({ error: "Caixa já está fechado" }, { status: 400 });
  }

  if (action === "close") {
    if (closingAmount === undefined || closingAmount < 0) {
      return NextResponse.json({ error: "Valor de fechamento inválido" }, { status: 400 });
    }

    const sales = register.movements
      .filter(m => m.type === CashMovementType.SALE)
      .reduce((s, m) => s + Number(m.amount), 0);

    const refunds = register.movements
      .filter(m => m.type === CashMovementType.REFUND)
      .reduce((s, m) => s + Number(m.amount), 0);

    const sangrias = register.movements
      .filter(m => m.type === CashMovementType.SANGRIA)
      .reduce((s, m) => s + Number(m.amount), 0);

    const suprimentos = register.movements
      .filter(m => m.type === CashMovementType.SUPRIMENTO)
      .reduce((s, m) => s + Number(m.amount), 0);

    const expenses = register.movements
      .filter(m => m.type === CashMovementType.EXPENSE)
      .reduce((s, m) => s + Number(m.amount), 0);

    const expectedClosing = Number(register.openingAmount) + sales - refunds + suprimentos - sangrias - expenses;
    const difference = closingAmount - expectedClosing;

    const updated = await prisma.cashRegister.update({
      where: { id },
      data: {
        status: CashRegisterStatus.CLOSED,
        closedAt: new Date(),
        closedBy: closedBy || "Sistema",
        closingAmount,
        expectedAmount: expectedClosing,
        difference,
        notes: notes || register.notes,
      },
    });

    await prisma.cashMovement.create({
      data: {
        cashRegisterId: id,
        type: CashMovementType.CLOSING,
        amount: closingAmount,
        description: "Fechamento de caixa",
        createdBy: closedBy || "Sistema",
      },
    });

    return NextResponse.json({
      ...updated,
      openingAmount: Number(updated.openingAmount),
      closingAmount: Number(updated.closingAmount),
      expectedAmount: Number(updated.expectedAmount),
      difference: Number(updated.difference),
    });
  }

  return NextResponse.json({ error: "Ação inválida" }, { status: 400 });
}