import { WhatsAppSettings, WhatsAppProvider, WhatsAppMessageType, WhatsAppMessageStatus, PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export interface WhatsAppMessage {
  to: string;
  message: string;
  type: WhatsAppMessageType;
  serviceOrderId?: string;
  clientId?: string;
}

export interface WhatsAppResult {
  success: boolean;
  providerId?: string;
  error?: string;
}

class WhatsAppService {
  private settings: WhatsAppSettings | null = null;

  async getSettings(): Promise<WhatsAppSettings | null> {
    if (this.settings) return this.settings;
    this.settings = await prisma.whatsAppSettings.findFirst({ where: { active: true } });
    return this.settings;
  }

  async sendMessage(data: WhatsAppMessage): Promise<WhatsAppResult> {
    const settings = await this.getSettings();
    
    if (!settings || !settings.active) {
      return { success: false, error: "WhatsApp não configurado ou inativo" };
    }

    const log = await prisma.whatsAppLog.create({
      data: {
        type: data.type,
        to: data.to,
        message: data.message,
        status: "PENDING",
        serviceOrderId: data.serviceOrderId,
        clientId: data.clientId,
      },
    });

    try {
      let result: WhatsAppResult;
      
      switch (settings.provider) {
        case "TWILIO":
          result = await this.sendViaTwilio(settings, data.to, data.message);
          break;
        case "META":
          result = await this.sendViaMeta(settings, data.to, data.message);
          break;
        case "ZENVIA":
          result = await this.sendViaZenvia(settings, data.to, data.message);
          break;
        case "WATI":
          result = await this.sendViaWati(settings, data.to, data.message);
          break;
        case "GUPSHUP":
          result = await this.sendViaGupshup(settings, data.to, data.message);
          break;
        case "MOCK":
        default:
          result = await this.sendMock(data.to, data.message);
          break;
      }

      await prisma.whatsAppLog.update({
        where: { id: log.id },
        data: {
          status: result.success ? "SENT" : "FAILED",
          providerId: result.providerId,
          errorMessage: result.error,
          sentAt: result.success ? new Date() : null,
        },
      });

      return result;
    } catch (error) {
      await prisma.whatsAppLog.update({
        where: { id: log.id },
        data: {
          status: "FAILED",
          errorMessage: error instanceof Error ? error.message : "Erro desconhecido",
        },
      });
      return { success: false, error: error instanceof Error ? error.message : "Erro desconhecido" };
    }
  }

  private async sendMock(to: string, message: string): Promise<WhatsAppResult> {
    console.log(`[WHATSAPP MOCK] Para: ${to}`);
    console.log(`[WHATSAPP MOCK] Mensagem: ${message}`);
    return { success: true, providerId: `mock-${Date.now()}` };
  }

  private async sendViaTwilio(settings: WhatsAppSettings, to: string, message: string): Promise<WhatsAppResult> {
    if (!settings.accountSid || !settings.authToken || !settings.phoneNumber) {
      return { success: false, error: "Credenciais Twilio incompletas" };
    }
    
    const response = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${settings.accountSid}/Messages.json`,
      {
        method: "POST",
        headers: {
          "Authorization": `Basic ${Buffer.from(`${settings.accountSid}:${settings.authToken}`).toString("base64")}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          From: `whatsapp:${settings.phoneNumber}`,
          To: `whatsapp:${to}`,
          Body: message,
        }),
      }
    );

    const data = await response.json();
    if (!response.ok) {
      return { success: false, error: data.message || "Erro Twilio" };
    }
    return { success: true, providerId: data.sid };
  }

  private async sendViaMeta(settings: WhatsAppSettings, to: string, message: string): Promise<WhatsAppResult> {
    if (!settings.apiUrl || !settings.apiKey || !settings.phoneNumber) {
      return { success: false, error: "Credenciais Meta incompletas" };
    }

    const response = await fetch(`${settings.apiUrl}/${settings.phoneNumber}/messages`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${settings.apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to: to.replace(/\D/g, ""),
        type: "text",
        text: { body: message },
      }),
    });

    const data = await response.json();
    if (!response.ok) {
      return { success: false, error: data.error?.message || "Erro Meta" };
    }
    return { success: true, providerId: data.messages?.[0]?.id };
  }

  private async sendViaZenvia(settings: WhatsAppSettings, to: string, message: string): Promise<WhatsAppResult> {
    if (!settings.apiKey || !settings.phoneNumber) {
      return { success: false, error: "Credenciais Zenvia incompletas" };
    }

    const response = await fetch("https://api.zenvia.com/v2/channels/whatsapp/messages", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${settings.apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: settings.phoneNumber,
        to: to,
        contents: [{ type: "text", text: message }],
      }),
    });

    const data = await response.json();
    if (!response.ok) {
      return { success: false, error: data.message || "Erro Zenvia" };
    }
    return { success: true, providerId: data.id };
  }

  private async sendViaWati(settings: WhatsAppSettings, to: string, message: string): Promise<WhatsAppResult> {
    if (!settings.apiUrl || !settings.apiKey) {
      return { success: false, error: "Credenciais Wati incompletas" };
    }

    const response = await fetch(`${settings.apiUrl}/api/v1/sendSessionMessage/${to.replace(/\D/g, "")}`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${settings.apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messageText: message,
      }),
    });

    const data = await response.json();
    if (!response.ok) {
      return { success: false, error: data.message || "Erro Wati" };
    }
    return { success: true, providerId: data.messageId };
  }

  private async sendViaGupshup(settings: WhatsAppSettings, to: string, message: string): Promise<WhatsAppResult> {
    if (!settings.apiKey || !settings.phoneNumber) {
      return { success: false, error: "Credenciais Gupshup incompletas" };
    }

    const response = await fetch("https://api.gupshup.io/sm/api/v1/msg", {
      method: "POST",
      headers: {
        "apikey": settings.apiKey,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        channel: "whatsapp",
        source: settings.phoneNumber,
        destination: to,
        message: JSON.stringify({ type: "text", text: message }),
        "src.name": "Advancecell",
      }),
    });

    const data = await response.json();
    if (!response.ok) {
      return { success: false, error: data.errorMessage || "Erro Gupshup" };
    }
    return { success: true, providerId: data.messageId };
  }

  formatPhone(phone: string): string {
    let cleaned = phone.replace(/\D/g, "");
    if (cleaned.startsWith("55")) return cleaned;
    if (cleaned.length === 10 || cleaned.length === 11) return "55" + cleaned;
    return cleaned;
  }

  getTemplate(type: WhatsAppMessageType, data: Record<string, string>): string {
    const templates: Record<WhatsAppMessageType, (d: Record<string, string>) => string> = {
      OS_CREATED: (d) => 
        `📱 *Advancecell - Nova OS #${d.orderNumber}*\n\n` +
        `Olá ${d.clientName}!\n` +
        `Recebemos seu ${d.deviceBrand} ${d.deviceModel} para análise.\n` +
        `📋 *Defeito:* ${d.defectDesc}\n` +
        `🔢 *OS:* #${d.orderNumber}\n\n` +
        `Acompanhe o status pelo nosso sistema.\n` +
        `Obrigado pela confiança! 🙏`,

      OS_STATUS_CHANGED: (d) =>
        `📱 *Advancecell - Atualização OS #${d.orderNumber}*\n\n` +
        `Olá ${d.clientName}!\n` +
        `Status do seu ${d.deviceBrand} ${d.deviceModel}: *${d.newStatus}*\n\n` +
        `${d.notes ? `📝 *Observação:* ${d.notes}\n\n` : ""}` +
        `Acompanhe pelo sistema.\n` +
        `Advancecell Assistência Técnica 🔧`,

      OS_READY: (d) =>
        `✅ *Advancecell - OS #${d.orderNumber} PRONTA*\n\n` +
        `Olá ${d.clientName}!\n` +
        `Seu ${d.deviceBrand} ${d.deviceModel} está *pronto para retirada*.\n\n` +
        `💰 *Total:* ${d.totalPrice}\n` +
        `💳 *Pago:* ${d.paidAmount}\n` +
        `⏳ *A pagar:* ${Number(d.totalPrice) - Number(d.paidAmount) > 0 ? String(Number(d.totalPrice) - Number(d.paidAmount)) : "0"}\n\n` +
        `📍 Retire em nosso endereço.\n` +
        `Garantia de ${d.warrantyDays} dias.\n\n` +
        `Advancecell - Sua confiança, nosso compromisso! 🤝`,

      OS_DELIVERED: (d) =>
        `📦 *Advancecell - OS #${d.orderNumber} ENTREGUE*\n\n` +
        `Olá ${d.clientName}!\n` +
        `Confirmamos a entrega do seu ${d.deviceBrand} ${d.deviceModel}.\n\n` +
        `✅ Serviço concluído com sucesso!\n` +
        `🔧 Garantia de ${d.warrantyDays} dias a partir de hoje.\n\n` +
        `Precisando, estamos à disposição!\n` +
        `Advancecell Assistência Técnica 📱`,

      PAYMENT_REMINDER: (d) =>
        `💰 *Advancecell - Lembrete de Pagamento*\n\n` +
        `Olá ${d.clientName}!\n` +
        `Sua OS #${d.orderNumber} possui valor pendente:\n\n` +
        `💵 *Total:* ${d.totalPrice}\n` +
        `✅ *Pago:* ${d.paidAmount}\n` +
        `⏳ *A pagar:* ${d.pendingAmount}\n\n` +
        `Por favor, regularize para evitar juros.\n` +
        `Pix/Cartão/Dinheiro na loja.\n\n` +
        `Advancecell 💙`,

      LOW_STOCK: (d) =>
        `⚠️ *Advancecell - Alerta de Estoque Baixo*\n\n` +
        `Produto: ${d.productName}\n` +
        `Estoque atual: ${d.currentStock}\n` +
        `Estoque mínimo: ${d.minStock}\n\n` +
        `Faça o reposição o quanto antes.\n` +
        `Advancecell Sistema 📦`,

      CUSTOM: (d) => d.message || "Mensagem personalizada",
    };

    const template = templates[type] || templates.CUSTOM;
    return template(data);
  }

  async notifyOSCreated(orderNumber: number, clientName: string, clientPhone: string, deviceBrand: string, deviceModel: string, defectDesc: string) {
    const phone = this.formatPhone(clientPhone);
    const message = this.getTemplate("OS_CREATED", {
      orderNumber: orderNumber.toString(),
      clientName,
      deviceBrand,
      deviceModel,
      defectDesc,
    });
    return this.sendMessage({ to: phone, message, type: "OS_CREATED" });
  }

  async notifyOSStatusChanged(orderNumber: number, clientName: string, clientPhone: string, deviceBrand: string, deviceModel: string, newStatus: string, notes?: string) {
    const phone = this.formatPhone(clientPhone);
    const message = this.getTemplate("OS_STATUS_CHANGED", {
      orderNumber: orderNumber.toString(),
      clientName,
      deviceBrand,
      deviceModel,
      newStatus,
      notes: notes || "",
    });
    return this.sendMessage({ to: phone, message, type: "OS_STATUS_CHANGED" });
  }

  async notifyOSReady(orderNumber: number, clientName: string, clientPhone: string, deviceBrand: string, deviceModel: string, totalPrice: string, paidAmount: string, warrantyDays: number) {
    const phone = this.formatPhone(clientPhone);
    const message = this.getTemplate("OS_READY", {
      orderNumber: orderNumber.toString(),
      clientName,
      deviceBrand,
      deviceModel,
      totalPrice,
      paidAmount,
      warrantyDays: warrantyDays.toString(),
    });
    return this.sendMessage({ to: phone, message, type: "OS_READY" });
  }

  async notifyOSDelivered(orderNumber: number, clientName: string, clientPhone: string, deviceBrand: string, deviceModel: string, warrantyDays: number) {
    const phone = this.formatPhone(clientPhone);
    const message = this.getTemplate("OS_DELIVERED", {
      orderNumber: orderNumber.toString(),
      clientName,
      deviceBrand,
      deviceModel,
      warrantyDays: warrantyDays.toString(),
    });
    return this.sendMessage({ to: phone, message, type: "OS_DELIVERED" });
  }

  async notifyPaymentReminder(orderNumber: number, clientName: string, clientPhone: string, totalPrice: string, paidAmount: string, pendingAmount: string) {
    const phone = this.formatPhone(clientPhone);
    const message = this.getTemplate("PAYMENT_REMINDER", {
      orderNumber: orderNumber.toString(),
      clientName,
      totalPrice,
      paidAmount,
      pendingAmount,
    });
    return this.sendMessage({ to: phone, message, type: "PAYMENT_REMINDER" });
  }

  async notifyLowStock(productName: string, currentStock: number, minStock: number) {
    const settings = await this.getSettings();
    if (!settings) return { success: false, error: "WhatsApp não configurado" };
    
    const phone = this.formatPhone(settings.phoneNumber);
    const message = this.getTemplate("LOW_STOCK", {
      productName,
      currentStock: currentStock.toString(),
      minStock: minStock.toString(),
    });
    return this.sendMessage({ to: phone, message, type: "LOW_STOCK" });
  }

  async sendCustom(to: string, message: string) {
    const phone = this.formatPhone(to);
    return this.sendMessage({ to: phone, message, type: "CUSTOM" });
  }

  async getLogs(limit = 50, offset = 0) {
    return prisma.whatsAppLog.findMany({
      take: limit,
      skip: offset,
      orderBy: { createdAt: "desc" },
      include: { serviceOrder: { select: { orderNumber: true } }, client: { select: { name: true } } },
    });
  }

  async getStats() {
    const [total, sent, failed, pending] = await Promise.all([
      prisma.whatsAppLog.count(),
      prisma.whatsAppLog.count({ where: { status: "SENT" } }),
      prisma.whatsAppLog.count({ where: { status: "FAILED" } }),
      prisma.whatsAppLog.count({ where: { status: "PENDING" } }),
    ]);
    return { total, sent, failed, pending };
  }
}

export const whatsappService = new WhatsAppService();