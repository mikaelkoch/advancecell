import { NextRequest, NextResponse } from "next/server";
import { whatsappService } from "@/lib/whatsapp";
import { WhatsAppMessageType } from "@prisma/client";

export async function POST(request: NextRequest) {
  const body = await request.json();
  const { type, to, message, serviceOrderId, clientId, data } = body;

  if (!type || !to) {
    return NextResponse.json({ error: "Tipo e destinatário obrigatórios" }, { status: 400 });
  }

  let finalMessage = message;

  if (data && type !== "CUSTOM") {
    finalMessage = whatsappService.getTemplate(type as WhatsAppMessageType, data);
  }

  const result = await whatsappService.sendMessage({
    to,
    message: finalMessage,
    type: type as WhatsAppMessageType,
    serviceOrderId,
    clientId,
  });

  return NextResponse.json(result);
}