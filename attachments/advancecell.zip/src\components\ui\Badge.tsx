"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: "default" | "secondary" | "destructive" | "outline" | "success" | "warning" | "info" | "purple";
  size?: "default" | "sm" | "lg";
}

const Badge = React.forwardRef<HTMLSpanElement, BadgeProps>(
  ({ className, variant = "default", size = "default", ...props }, ref) => {
    const variants = {
      default: "bg-blue-100 text-blue-800 hover:bg-blue-100",
      secondary: "bg-gray-100 text-gray-800 hover:bg-gray-200",
      destructive: "bg-red-100 text-red-800 hover:bg-red-100",
      outline: "border border-gray-300 bg-white text-gray-700 hover:bg-gray-50",
      success: "bg-green-100 text-green-800 hover:bg-green-100",
      warning: "bg-yellow-100 text-yellow-800 hover:bg-yellow-100",
      info: "bg-sky-100 text-sky-800 hover:bg-sky-100",
      purple: "bg-purple-100 text-purple-800 hover:bg-purple-100",
    };

    const sizes = {
      default: "px-2.5 py-0.5 text-xs",
      sm: "px-2 py-0.5 text-[10px]",
      lg: "px-3 py-1 text-sm",
    };

    return (
      <span
        ref={ref}
        className={cn(
          "inline-flex items-center font-medium rounded-full transition-colors duration-200",
          variants[variant],
          sizes[size],
          className
        )}
        {...props}
      />
    );
  }
);

Badge.displayName = "Badge";
export { Badge };