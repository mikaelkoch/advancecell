"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { Plus, Search, Filter, ChevronDown, Edit, Trash2, FileText, Eye, Download, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Select } from "@/components/ui/Select";
import { Modal } from "@/components/ui/Modal";
import { ConfirmDialog } from "@/components/ui/Modal";
import { Badge } from "@/components/ui/Badge";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell, TableCaption } from "@/components/ui/Table";
import { DropdownMenu } from "@/components/ui/Dropdown";
import { ServiceOrder, Client, Product, ServiceType, ServiceOrderStatus, STATUS_LABELS, STATUS_COLORS, STATUS_FLOW } from "@/lib/types";
import { format, formatCurrency } from "@/lib/utils";
import API from "@/lib/api";
import { ChangeEvent, FormEvent, useState, useEffect } from "react";

interface ServiceOrderManagerV2Props {
  clients: Client[];
  products: Product[];
  serviceTypes: ServiceType[];
  onDataChange: () => void;
}

export function ServiceOrderManagerV2({ clients, products, serviceTypes, onDataChange }: ServiceOrderManagerV2Props) {
  const [orders, setOrders] = useState<ServiceOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<ServiceOrder | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<ServiceOrder | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [filterStatus, setFilterStatus] = useState<ServiceOrderStatus | "all">("all");
  const [search, setSearch] = useState("");
  const [viewingOrder, setViewingOrder] = useState<ServiceOrder | null>(null);

  const [form, setForm] = useState({
    clientId: "",
    deviceBrand: "",
    deviceModel: "",
    deviceSerial: "",
    deviceImei: "",
    defectDesc: "",
    accessories: "",
    diagnosis: "",
    solution: "",
    technician: "",
    warrantyDays: "90",
    discount: "0",
    paidAmount: "0",
    paymentMethod: "",
    notes: "",
    estimatedDate: "",
    items: [] as { productId: string; quantity: number; unitPrice: string }[],
    services: [] as { serviceTypeId: string; quantity: number; unitPrice: string; notes: string }[],
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const data = await API.serviceOrders.list({ 
        status: filterStatus !== "all" ? filterStatus : undefined, 
        search: search || undefined 
      });
      setOrders(data);
    } catch (error) {
      console.error("Erro ao carregar OS:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [filterStatus, search]);

  const calculateTotals = () => {
    const partsPrice = form.items.reduce((sum, i) => sum + i.quantity * parseFloat(i.unitPrice || "0"), 0);
    const laborPrice = form.services.reduce((sum, s) => sum + s.quantity * parseFloat(s.unitPrice || "0"), 0);
    const discount = parseFloat(form.discount || "0");
    return { partsPrice, laborPrice, totalPrice: partsPrice + laborPrice - discount };
  };

  const sendWhatsAppNotification = async (order: ServiceOrder, type: "OS_CREATED" | "OS_STATUS_CHANGED" | "OS_READY" | "OS_DELIVERED", extraData?: Record<string, string>) => {
    const clientPhone = order.client.whatsapp || order.client.phone;
    if (!clientPhone) return;

    const data = {
      orderNumber: order.orderNumber.toString(),
      clientName: order.client.name,
      deviceBrand: order.deviceBrand,
      deviceModel: order.deviceModel,
      defectDesc: order.defectDesc,
      newStatus: STATUS_LABELS[order.status] || order.status,
      totalPrice: formatCurrency(Number(order.totalPrice)),
      paidAmount: formatCurrency(Number(order.paidAmount)),
      pendingAmount: formatCurrency(Number(order.totalPrice) - Number(order.paidAmount)),
      warrantyDays: order.warrantyDays.toString(),
      ...extraData,
    };

    await API.whatsapp.send({ type, to: clientPhone, serviceOrderId: order.id, clientId: order.clientId, data });
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const { partsPrice, laborPrice, totalPrice } = calculateTotals();
      const payload = {
        ...form,
        items: form.items.map(i => ({ productId: i.productId, quantity: i.quantity, unitPrice: parseFloat(i.unitPrice || "0") })),
        services: form.services.map(s => ({ serviceTypeId: s.serviceTypeId, quantity: s.quantity, unitPrice: parseFloat(s.unitPrice || "0"), notes: s.notes })),
        laborPrice, partsPrice, discount: parseFloat(form.discount || "0"), totalPrice,
        paidAmount: parseFloat(form.paidAmount || "0"),
        estimatedDate: form.estimatedDate || null,
      };
      let savedOrder: ServiceOrder;
      if (editing) {
        await API.serviceOrders.update(editing.id, payload);
        savedOrder = { ...editing, ...payload } as ServiceOrder;
      } else {
        const result = await API.serviceOrders.create(payload);
        savedOrder = result;
      }
      closeModal();
      onDataChange();

      if (!editing) {
        sendWhatsAppNotification(savedOrder, "OS_CREATED");
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    await API.serviceOrders.delete(confirmDelete.id);
    setConfirmDelete(null);
    onDataChange();
  };

  const handleEdit = async (order: ServiceOrder) => {
    setEditing(order);
    setForm({
      clientId: order.clientId,
      deviceBrand: order.deviceBrand,
      deviceModel: order.deviceModel,
      deviceSerial: order.deviceSerial || "",
      deviceImei: order.deviceImei || "",
      defectDesc: order.defectDesc,
      accessories: order.accessories || "",
      diagnosis: order.diagnosis || "",
      solution: order.solution || "",
      technician: order.technician || "",
      warrantyDays: order.warrantyDays.toString(),
      discount: order.discount.toString(),
      paidAmount: order.paidAmount.toString(),
      paymentMethod: order.paymentMethod || "",
      notes: order.notes || "",
      estimatedDate: order.estimatedDate ? order.estimatedDate.split("T")[0] : "",
      items: order.items.map(i => ({ productId: i.productId, quantity: i.quantity, unitPrice: i.unitPrice.toString() })),
      services: order.services.map(s => ({ serviceTypeId: s.serviceTypeId, quantity: s.quantity, unitPrice: s.unitPrice.toString(), notes: s.notes || "" })),
    });
    setShowModal(true);
  };

  const handleView = (order: ServiceOrder) => {
    setViewingOrder(order);
  };

  const handleNew = () => {
    setEditing(null);
    setForm({
      clientId: clients[0]?.id || "",
      deviceBrand: "", deviceModel: "", deviceSerial: "", deviceImei: "",
      defectDesc: "", accessories: "", diagnosis: "", solution: "", technician: "",
      warrantyDays: "90", discount: "0", paidAmount: "0", paymentMethod: "", notes: "", estimatedDate: "",
      items: [], services: [],
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditing(null);
    setForm({
      clientId: clients[0]?.id || "",
      deviceBrand: "", deviceModel: "", deviceSerial: "", deviceImei: "",
      defectDesc: "", accessories: "", diagnosis: "", solution: "", technician: "",
      warrantyDays: "90", discount: "0", paidAmount: "0", paymentMethod: "", notes: "", estimatedDate: "",
      items: [], services: [],
    });
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const addItem = () => setForm(prev => ({ ...prev, items: [...prev.items, { productId: "", quantity: 1, unitPrice: "" }] }));
  const removeItem = (idx: number) => setForm(prev => ({ ...prev, items: prev.items.filter((_, i) => i !== idx) }));
  const updateItem = (idx: number, field: string, value: string) => setForm(prev => ({ ...prev, items: prev.items.map((i, i2) => i2 === idx ? { ...i, [field]: value } : i) }));

  const addService = () => setForm(prev => ({ ...prev, services: [...prev.services, { serviceTypeId: "", quantity: 1, unitPrice: "", notes: "" }] }));
  const removeService = (idx: number) => setForm(prev => ({ ...prev, services: prev.services.filter((_, i) => i !== idx) }));
  const updateService = (idx: number, field: string, value: string) => setForm(prev => ({ ...prev, services: prev.services.map((s, i) => i === idx ? { ...s, [field]: value } : s) }));

  const canTransition = (current: ServiceOrderStatus, next: ServiceOrderStatus) => STATUS_FLOW[current]?.includes(next) ?? false;

  const handleStatusChange = async (order: ServiceOrder, newStatus: ServiceOrderStatus) => {
    if (!canTransition(order.status, newStatus)) return;
    await API.serviceOrders.update(order.id, { status: newStatus });
    onDataChange();

    const updatedOrder = { ...order, status: newStatus };
    
    if (newStatus === "READY") {
      sendWhatsAppNotification(updatedOrder, "OS_READY");
    } else if (newStatus === "DELIVERED") {
      sendWhatsAppNotification(updatedOrder, "OS_DELIVERED");
    } else {
      sendWhatsAppNotification(updatedOrder, "OS_STATUS_CHANGED");
    }
  };

  const getOrderActions = (order: ServiceOrder) => [
    { label: "Visualizar", value: `view-${order.id}`, icon: <Eye className="h-4 w-4" /> },
    { label: "Editar", value: `edit-${order.id}`, icon: <Edit className="h-4 w-4" /> },
    { label: "Imprimir PDF", value: `pdf-${order.id}`, icon: <FileText className="h-4 w-4" /> },
    { label: "Baixar PDF", value: `download-${order.id}`, icon: <Download className="h-4 w-4" /> },
    { label: "Excluir", value: `delete-${order.id}`, icon: <Trash2 className="h-4 w-4" />, danger: true },
  ];

  const handleAction = (value: string) => {
    const [action, id] = value.split("-");
    const order = orders.find(o => o.id === id);
    if (!order) return;
    
    switch (action) {
      case "view": handleView(order); break;
      case "edit": handleEdit(order); break;
      case "pdf": window.open(`/api/service-orders/${order.id}/pdf`, "_blank"); break;
      case "download": window.open(`/api/service-orders/${order.id}/pdf`, "_blank"); break;
      case "delete": setConfirmDelete(order); break;
    }
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Ordens de Serviço</h1>
          <p className="text-gray-500 mt-1">Gerencie todas as ordens de serviço da assistência técnica.</p>
        </div>
        <Button onClick={handleNew} className="w-full sm:w-auto">
          <Plus className="h-4 w-4" /> Nova OS
        </Button>
      </div>

      <div className="card bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-col sm:flex-row gap-4 mb-4">
          <div className="flex-1">
            <Input
              placeholder="Buscar por #OS, cliente, modelo..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full"
            />
          </div>
          <Select
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value as ServiceOrderStatus | "all")}
            options={[
              { value: "all", label: "Todos os status" },
              { value: "RECEIVED", label: "Recebido" },
              { value: "DIAGNOSING", label: "Diagnosticando" },
              { value: "WAITING_APPROVAL", label: "Aguardando Aprovação" },
              { value: "IN_REPAIR", label: "Em Reparo" },
              { value: "READY", label: "Pronto" },
              { value: "DELIVERED", label: "Entregue" },
              { value: "CANCELLED", label: "Cancelado" },
            ]}
            className="w-full sm:w-48"
          />
        </div>

        {orders.length === 0 ? (
          <div className="text-center py-12">
            <Wrench className="h-12 w-12 mx-auto text-gray-300 mb-3" />
            <h3 className="text-lg font-medium text-gray-900 mb-1">Nenhuma ordem de serviço</h3>
            <p className="text-gray-500 mb-4">Comece criando a primeira OS</p>
            <Button onClick={handleNew}><Plus className="h-4 w-4 mr-2" /> Criar primeira OS</Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-24">#OS</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Aparelho</TableHead>
                  <TableHead className="w-36">Status</TableHead>
                  <TableHead className="w-32 text-right">Total</TableHead>
                  <TableHead className="w-32 text-right">Pago</TableHead>
                  <TableHead className="w-40">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-mono text-gray-900">#{order.orderNumber.toString().padStart(6, "0")}</TableCell>
                    <TableCell>
                      <p className="font-medium text-gray-900">{order.client.name}</p>
                      <p className="text-sm text-gray-500">{formatPhone(order.client.phone)}</p>
                    </TableCell>
                    <TableCell className="text-gray-500">
                      <p className="font-medium">{order.deviceBrand} {order.deviceModel}</p>
                      {order.deviceSerial && <p className="text-xs text-gray-400">SN: {order.deviceSerial}</p>}
                    </TableCell>
                    <TableCell>
                      <Badge variant={order.status === "READY" || order.status === "DELIVERED" ? "success" : order.status === "CANCELLED" ? "destructive" : order.status === "WAITING_APPROVAL" ? "warning" : "default"}>
                        {STATUS_ICONS[order.status]}
                        {STATUS_LABELS[order.status] || order.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right font-medium text-gray-900">{formatCurrency(Number(order.totalPrice))}</TableCell>
                    <TableCell className="text-right">
                      <span className={Number(order.paidAmount) >= Number(order.totalPrice) ? "text-green-600" : "text-gray-900"}>
                        {formatCurrency(Number(order.paidAmount))}
                      </span>
                      {Number(order.paidAmount) < Number(order.totalPrice) && (
                        <span className="ml-1 text-red-500 text-sm">⚠</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu
                        trigger={
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        }
                        items={getOrderActions(order)}
                        onSelect={handleAction}
                        align="right"
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      {showModal && (
        <Modal
          open={true}
          onClose={closeModal}
          title={editing ? `Editar OS #${editing.orderNumber.toString().padStart(6, "0")}` : "Nova Ordem de Serviço"}
          description={editing ? undefined : "Preencha os dados abaixo para criar uma nova ordem de serviço."}
          size="xl"
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Select
                label="Cliente *"
                name="clientId"
                value={form.clientId}
                onChange={handleChange}
                options={clients.map(c => ({ value: c.id, label: `${c.name} - ${formatPhone(c.phone)}` }))}
                placeholder="Selecione o cliente"
                required
              />
              <Input label="Marca *" name="deviceBrand" value={form.deviceBrand} onChange={handleChange} required placeholder="Ex: Apple, Samsung, Motorola" />
              <Input label="Modelo *" name="deviceModel" value={form.deviceModel} onChange={handleChange} required placeholder="Ex: iPhone 13, Galaxy S22" />
              <Input label="Nº Série" name="deviceSerial" value={form.deviceSerial} onChange={handleChange} placeholder="Número de série do aparelho" />
              <Input label="IMEI" name="deviceImei" value={form.deviceImei} onChange={handleChange} placeholder="IMEI do aparelho" />
              <Input label="Garantia (dias)" name="warrantyDays" type="number" value={form.warrantyDays} onChange={handleChange} />
              <Input label="Técnico" name="technician" value={form.technician} onChange={handleChange} placeholder="Responsável pelo reparo" />
              <Input label="Previsão Entrega" name="estimatedDate" type="date" value={form.estimatedDate} onChange={handleChange} />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Defeito Relatado *</label>
              <textarea name="defectDesc" value={form.defectDesc} onChange={handleChange} rows={3} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="Descreva o problema relatado pelo cliente..." />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Acessórios Entregues</label>
              <textarea name="accessories" value={form.accessories} onChange={handleChange} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="Ex: Carregador, cabo, capa, película..." />
            </div>

            {editing && (
              <div className="border-t pt-4">
                <h4 className="font-medium mb-3">Alterar Status</h4>
                <div className="flex flex-wrap gap-2">
                  {STATUS_FLOW[editing.status].map(s => (
                    <Button
                      key={s}
                      type="button"
                      variant={STATUS_COLORS[s].includes("green") ? "default" : STATUS_COLORS[s].includes("red") ? "destructive" : "outline"}
                      onClick={() => handleStatusChange(editing, s)}
                      className="whitespace-nowrap"
                    >
                      {STATUS_ICONS[s]}
                      {STATUS_LABELS[s]}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            <div className="border-t pt-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium">Peças / Produtos Utilizados</h4>
                <Button type="button" variant="outline" size="sm" onClick={addItem}><Plus className="h-4 w-4 mr-1" /> Adicionar</Button>
              </div>
              <div className="space-y-2">
                {form.items.length === 0 && <p className="text-sm text-gray-500 text-center py-4">Nenhum produto adicionado</p>}
                {form.items.map((item, idx) => (
                  <div key={idx} className="flex gap-2 p-3 bg-gray-50 rounded-lg">
                    <Select
                      value={item.productId}
                      onChange={e => updateItem(idx, "productId", e.target.value)}
                      options={products.filter(p => p.active).map(p => ({ value: p.id, label: `${p.name} - ${formatCurrency(Number(p.price))} (Est: ${p.stock})` }))}
                      placeholder="Selecione produto"
                      className="flex-1"
                    />
                    <Input name={`item-qty-${idx}`} type="number" min="1" value={item.quantity} onChange={e => updateItem(idx, "quantity", e.target.value)} className="w-20" />
                    <Input name={`item-price-${idx}`} type="number" step="0.01" min="0" value={item.unitPrice} onChange={e => updateItem(idx, "unitPrice", e.target.value)} placeholder="Preço unit." className="w-32" />
                    <Button type="button" variant="ghost" size="icon" onClick={() => removeItem(idx)} className="text-red-500 hover:text-red-700"><Trash2 className="h-4 w-4" /></Button>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t pt-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium">Serviços Realizados</h4>
                <Button type="button" variant="outline" size="sm" onClick={addService}><Plus className="h-4 w-4 mr-1" /> Adicionar</Button>
              </div>
              <div className="space-y-2">
                {form.services.length === 0 && <p className="text-sm text-gray-500 text-center py-4">Nenhum serviço adicionado</p>}
                {form.services.map((svc, idx) => (
                  <div key={idx} className="flex gap-2 p-3 bg-gray-50 rounded-lg">
                    <Select
                      value={svc.serviceTypeId}
                      onChange={e => updateService(idx, "serviceTypeId", e.target.value)}
                      options={serviceTypes.filter(s => s.active).map(s => ({ value: s.id, label: `${s.name} - ${formatCurrency(Number(s.price))}` }))}
                      placeholder="Selecione serviço"
                      className="flex-1"
                    />
                    <Input name={`svc-qty-${idx}`} type="number" min="1" value={svc.quantity} onChange={e => updateService(idx, "quantity", e.target.value)} className="w-20" />
                    <Input name={`svc-price-${idx}`} type="number" step="0.01" min="0" value={svc.unitPrice} onChange={e => updateService(idx, "unitPrice", e.target.value)} placeholder="Preço unit." className="w-32" />
                    <Input name={`svc-notes-${idx}`} value={svc.notes} onChange={e => updateService(idx, "notes", e.target.value)} placeholder="Obs." className="flex-1" />
                    <Button type="button" variant="ghost" size="icon" onClick={() => removeService(idx)} className="text-red-500 hover:text-red-700"><Trash2 className="h-4 w-4" /></Button>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t pt-4">
              <Input label="Desconto" name="discount" type="number" step="0.01" min="0" value={form.discount} onChange={handleChange} />
              <Input label="Valor Pago" name="paidAmount" type="number" step="0.01" min="0" value={form.paidAmount} onChange={handleChange} />
              <Select
                label="Forma de Pagamento"
                name="paymentMethod"
                value={form.paymentMethod}
                onChange={handleChange}
                options={[
                  { value: "DINHEIRO", label: "Dinheiro" },
                  { value: "CARTAO_CREDITO", label: "Cartão Crédito" },
                  { value: "CARTAO_DEBITO", label: "Cartão Débito" },
                  { value: "PIX", label: "PIX" },
                  { value: "TRANSFERENCIA", label: "Transferência" },
                ]}
                placeholder="Selecione"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Diagnóstico</label>
              <textarea name="diagnosis" value={form.diagnosis} onChange={handleChange} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Solução</label>
              <textarea name="solution" value={form.solution} onChange={handleChange} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Observações Internas</label>
              <textarea name="notes" value={form.notes} onChange={handleChange} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
            </div>

            {editing && (
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <h4 className="font-medium mb-3">Resumo Financeiro</h4>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div><span className="text-gray-500">Peças:</span> <span className="font-medium ml-2">{formatCurrency(calculateTotals().partsPrice)}</span></div>
                  <div><span className="text-gray-500">Mão de obra:</span> <span className="font-medium ml-2">{formatCurrency(calculateTotals().laborPrice)}</span></div>
                  <div><span className="text-gray-500">Total:</span> <span className="font-bold text-lg ml-2">{formatCurrency(calculateTotals().totalPrice)}</span></div>
                </div>
              </div>
            )}

            <div className="flex justify-end gap-3 border-t pt-6">
              <Button type="button" variant="outline" onClick={closeModal}>Cancelar</Button>
              <Button type="submit" loading={submitting}>{submitting ? "Salvando..." : editing ? "Atualizar" : "Criar OS"}</Button>
            </div>
          </form>
        </Modal>
      )}

      {viewingOrder && (
        <Modal
          open={true}
          onClose={() => setViewingOrder(null)}
          title={`OS #${viewingOrder.orderNumber.toString().padStart(6, "0")}`}
          size="xl"
        >
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-gray-500">Cliente</p>
                <p className="font-medium text-gray-900">{viewingOrder.client.name}</p>
                <p className="text-sm text-gray-500">{formatPhone(viewingOrder.client.phone)}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Status</p>
                <Badge variant={viewingOrder.status === "READY" || viewingOrder.status === "DELIVERED" ? "success" : viewingOrder.status === "CANCELLED" ? "destructive" : viewingOrder.status === "WAITING_APPROVAL" ? "warning" : "default"}>
                  {STATUS_ICONS[viewingOrder.status]}
                  {STATUS_LABELS[viewingOrder.status] || viewingOrder.status}
                </Badge>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Aparelho</p>
                <p className="font-medium text-gray-900">{viewingOrder.deviceBrand} {viewingOrder.deviceModel}</p>
                {viewingOrder.deviceSerial && <p className="text-sm text-gray-500">SN: {viewingOrder.deviceSerial}</p>}
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Data</p>
                <p className="font-medium text-gray-900">{format(new Date(viewingOrder.createdAt), "dd/MM/yyyy HH:mm")}</p>
              </div>
            </div>

            <div className="border-t pt-4">
              <h4 className="font-medium mb-2">Defeito Relatado</h4>
              <p className="text-gray-900">{viewingOrder.defectDesc}</p>
            </div>

            {viewingOrder.accessories && (
              <div className="border-t pt-4">
                <h4 className="font-medium mb-2">Acessórios Entregues</h4>
                <p className="text-gray-900">{viewingOrder.accessories}</p>
              </div>
            )}

            {viewingOrder.diagnosis && (
              <div className="border-t pt-4">
                <h4 className="font-medium mb-2">Diagnóstico</h4>
                <p className="text-gray-900">{viewingOrder.diagnosis}</p>
              </div>
            )}

            {viewingOrder.solution && (
              <div className="border-t pt-4">
                <h4 className="font-medium mb-2">Solução</h4>
                <p className="text-gray-900">{viewingOrder.solution}</p>
              </div>
            )}

            <div className="border-t pt-4">
              <h4 className="font-medium mb-3">Itens da OS</h4>
              <div className="space-y-2">
                {viewingOrder.items.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <p className="font-medium">{item.product.name}</p>
                      <p className="text-sm text-gray-500">Qtd: {item.quantity} × {formatCurrency(Number(item.unitPrice))}</p>
                    </div>
                    <span className="font-medium">{formatCurrency(Number(item.totalPrice))}</span>
                  </div>
                ))}
                {viewingOrder.services.map((svc, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <p className="font-medium">{svc.serviceType.name}</p>
                      {svc.notes && <p className="text-sm text-gray-500">{svc.notes}</p>}
                      <p className="text-sm text-gray-500">Qtd: {svc.quantity} × {formatCurrency(Number(svc.unitPrice))}</p>
                    </div>
                    <span className="font-medium">{formatCurrency(Number(svc.totalPrice))}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
              <h4 className="font-medium mb-3">Totais</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><span className="text-gray-500">Peças:</span> <span className="font-medium ml-2">{formatCurrency(Number(viewingOrder.partsPrice))}</span></div>
                <div><span className="text-gray-500">Mão de obra:</span> <span className="font-medium ml-2">{formatCurrency(Number(viewingOrder.laborPrice))}</span></div>
                <div><span className="text-gray-500">Desconto:</span> <span className="font-medium ml-2 text-red-600">-{formatCurrency(Number(viewingOrder.discount))}</span></div>
                <div><span className="text-gray-500">Total:</span> <span className="font-bold text-lg ml-2">{formatCurrency(Number(viewingOrder.totalPrice))}</span></div>
                <div><span className="text-gray-500">Pago:</span> <span className="font-medium ml-2">{formatCurrency(Number(viewingOrder.paidAmount))}</span></div>
                <div><span className="text-gray-500">A Receber:</span> <span className="font-bold text-lg ml-2 text-orange-600">{formatCurrency(Number(viewingOrder.totalPrice) - Number(viewingOrder.paidAmount))}</span></div>
              </div>
              {viewingOrder.paymentMethod && (
                <p className="mt-2 text-sm text-gray-500">Forma: {viewingOrder.paymentMethod}</p>
              )}
            </div>
          </div>
        </Modal>
      )}

      {confirmDelete && (
        <ConfirmDialog
          open={true}
          onClose={() => setConfirmDelete(null)}
          onConfirm={handleDelete}
          title="Excluir Ordem de Serviço"
          message={`Tem certeza que deseja excluir a OS #${confirmDelete.orderNumber.toString().padStart(6, "0")}? Esta ação não pode ser desfeita.`}
          confirmLabel="Excluir"
          variant="destructive"
        />
      )}
    </div>
  );
}