import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const types = await prisma.serviceType.findMany({
    where: { active: true },
    orderBy: { name: "asc" },
  });
  return NextResponse.json(types);
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const type = await prisma.serviceType.create({
    data: {
      name: body.name,
      description: body.description,
      price: body.price,
      durationMin: body.durationMin || 60,
      active: body.active !== false,
    },
  });
  return NextResponse.json(type, { status: 201 });
}