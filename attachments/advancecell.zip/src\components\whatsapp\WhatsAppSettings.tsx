"use client";

import { useState, useEffect, FormEvent, ChangeEvent } from "react";
import { Modal } from "@/components/ui/Modal";
import { WhatsAppSettings, WhatsAppProvider, WHATSAPP_PROVIDERS } from "@/lib/types";
import API from "@/lib/api";
import { format } from "date-fns";

interface WhatsAppSettingsManagerProps {
  onDataChange: () => void;
}

export function WhatsAppSettingsManager({ onDataChange }: WhatsAppSettingsManagerProps) {
  const [settings, setSettings] = useState<WhatsAppSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showTestModal, setShowTestModal] = useState(false);
  const [testPhone, setTestPhone] = useState("");
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [logs, setLogs] = useState<any[]>([]);
  const [logsLoading, setLogsLoading] = useState(false);

  const [form, setForm] = useState({
    provider: "MOCK" as WhatsAppProvider,
    phoneNumber: "",
    accountSid: "",
    authToken: "",
    apiUrl: "",
    apiKey: "",
    templatePrefix: "advancecell",
    active: false,
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const data = await API.whatsapp.getSettings();
      setSettings(data);
      setForm({
        provider: data.provider as WhatsAppProvider,
        phoneNumber: data.phoneNumber,
        accountSid: data.accountSid === "***" ? "" : data.accountSid,
        authToken: "",
        apiUrl: data.apiUrl,
        apiKey: data.hasApiKey ? "" : "",
        templatePrefix: data.templatePrefix || "advancecell",
        active: data.active,
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchLogs = async () => {
    setLogsLoading(true);
    try {
      const res = await API.whatsapp.getLogs(20);
      setLogs(res.logs);
    } finally {
      setLogsLoading(false);
    }
  };

  useEffect(() => { fetchData(); fetchLogs(); }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await API.whatsapp.saveSettings(form);
      fetchData();
      onDataChange();
    } finally {
      setSaving(false);
    }
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === "checkbox") {
      setForm(prev => ({ ...prev, [name]: (e.target as HTMLInputElement).checked }));
    } else {
      setForm(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleTestSend = async (e: FormEvent) => {
    e.preventDefault();
    if (!testPhone) return;
    
    const result = await API.whatsapp.send({
      type: "CUSTOM",
      to: testPhone,
      message: `🧪 *Teste Advancecell*\n\nEsta é uma mensagem de teste das configurações de WhatsApp.\n\nEnviado em: ${format(new Date(), "dd/MM/yyyy HH:mm")}`,
    });
    
    setTestResult(result);
    fetchLogs();
  };

  const currentProvider = WHATSAPP_PROVIDERS.find(p => p.value === form.provider);
  const requiredFields = currentProvider?.fields || [];

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">Configurações WhatsApp</h2>
        <button onClick={() => { setShowTestModal(true); setTestPhone(settings?.phoneNumber || ""); setTestResult(null); }} className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">Testar Envio</button>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-sm p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Provedor</label>
            <select name="provider" value={form.provider} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
              {WHATSAPP_PROVIDERS.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Número do WhatsApp *</label>
            <input type="tel" name="phoneNumber" value={form.phoneNumber} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="5511999999999" />
            <p className="text-xs text-gray-500 mt-1">Formato: 55 + DDD + número (ex: 5511999999999)</p>
          </div>
        </div>

        {requiredFields.includes("accountSid") && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Account SID</label>
              <input type="text" name="accountSid" value={form.accountSid} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Auth Token</label>
              <input type="password" name="authToken" value={form.authToken} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>
        )}

        {requiredFields.includes("apiUrl") && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">API URL</label>
              <input type="url" name="apiUrl" value={form.apiUrl} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="https://api.exemplo.com" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">API Key</label>
              <input type="password" name="apiKey" value={form.apiKey} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>
        )}

        {requiredFields.includes("apiKey") && !requiredFields.includes("apiUrl") && (
          <div className="border-t pt-6">
            <label className="block text-sm font-medium text-gray-700 mb-1">API Key</label>
            <input type="password" name="apiKey" value={form.apiKey} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t pt-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Prefixo Template</label>
            <input type="text" name="templatePrefix" value={form.templatePrefix} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
          </div>
          <div className="flex items-center gap-2">
            <input type="checkbox" name="active" checked={form.active} onChange={handleChange} id="active" className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
            <label htmlFor="active" className="text-sm text-gray-700">Ativar WhatsApp</label>
          </div>
        </div>

        <div className="flex justify-end gap-3 border-t pt-6">
          <button type="submit" disabled={saving} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50">
            {saving ? "Salvando..." : "Salvar Configurações"}
          </button>
        </div>
      </form>

      <div className="bg-white rounded-xl shadow-sm p-6">
        <h3 className="font-bold mb-4">Logs Recentes</h3>
        {logsLoading ? (
          <div className="flex items-center justify-center h-32"><div className="animate-spin rounded-full h-6 w-6 border-4 border-blue-600 border-t-transparent"></div></div>
        ) : logs.length === 0 ? (
          <p className="text-gray-500 text-center py-8">Nenhum log encontrado</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Data</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tipo</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Destinatário</th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">OS/Cliente</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Erro</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {logs.map(log => (
                  <tr key={log.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm text-gray-500">{format(new Date(log.createdAt), "dd/MM HH:mm:ss")}</td>
                    <td className="px-6 py-4 text-sm">{log.type}</td>
                    <td className="px-6 py-4 text-sm font-mono">{log.to}</td>
                    <td className="px-6 py-4 text-center">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${log.status === "SENT" ? "bg-green-100 text-green-800" : log.status === "FAILED" ? "bg-red-100 text-red-800" : "bg-yellow-100 text-yellow-800"}`}>
                        {log.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      {log.serviceOrder && `OS #${log.serviceOrder.orderNumber}`}
                      {log.client && ` - ${log.client.name}`}
                    </td>
                    <td className="px-6 py-4 text-sm text-red-500 truncate max-w-xs">{log.errorMessage || "-"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showTestModal && (
        <Modal title="Testar Envio WhatsApp" onClose={() => setShowTestModal(false)} onSubmit={handleTestSend} submitting={false} submitLabel="Enviar Teste">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Número para Teste</label>
              <input type="tel" value={testPhone} onChange={e => setTestPhone(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500" placeholder="5511999999999" />
            </div>
            {testResult && (
              <div className={`p-4 rounded-lg ${testResult.success ? "bg-green-50 text-green-800" : "bg-red-50 text-red-800"}`}>
                {testResult.success ? "✅ Mensagem enviada com sucesso!" : `❌ Erro: ${testResult.message}`}
              </div>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
}