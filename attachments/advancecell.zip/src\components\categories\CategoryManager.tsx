"use client";

import { Category } from "@/lib/types";
import { Modal, ConfirmDialog } from "@/components/ui/Modal";
import { ChangeEvent, FormEvent, useState } from "react";
import API from "@/lib/api";

interface CategoryManagerProps {
  onDataChange: () => void;
}

export function CategoryManager({ onDataChange }: CategoryManagerProps) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Category | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Category | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({ name: "", description: "", imageUrl: "" });

  const fetchData = async () => {
    try {
      const data = await API.categories.list();
      setCategories(data);
    } catch (error) {
      console.error("Erro ao carregar categorias:", error);
      setCategories([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      if (editing) await API.categories.update(editing.id, form);
      else await API.categories.create(form);
      closeModal();
      onDataChange();
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    await API.categories.delete(confirmDelete.id);
    setConfirmDelete(null);
    onDataChange();
  };

  const handleEdit = (cat: Category) => {
    setEditing(cat);
    setForm({ name: cat.name, description: cat.description || "", imageUrl: cat.imageUrl || "" });
    setShowModal(true);
  };

  const handleNew = () => {
    setEditing(null);
    setForm({ name: "", description: "", imageUrl: "" });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditing(null);
    setForm({ name: "", description: "", imageUrl: "" });
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Categorias</h2>
        <button onClick={handleNew} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">+ Nova Categoria</button>
      </div>

      {categories.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl shadow-sm">
          <p className="text-gray-500 mb-4">Nenhuma categoria cadastrada</p>
          <button onClick={handleNew} className="bg-blue-600 text-white px-4 py-2 rounded-lg">Criar primeira categoria</button>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nome</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Slug</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Produtos</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Criado em</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {categories.map(cat => (
                <tr key={cat.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      {cat.imageUrl && <img src={cat.imageUrl} alt={cat.name} className="w-10 h-10 rounded object-cover" />}
                      <div>
                        <p className="text-sm font-medium text-gray-900">{cat.name}</p>
                        {cat.description && <p className="text-xs text-gray-500 truncate max-w-xs">{cat.description}</p>}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500 font-mono">{cat.slug}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{cat._count.products}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{new Date(cat.createdAt).toLocaleDateString("pt-BR")}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button onClick={() => handleEdit(cat)} className="text-blue-600 hover:text-blue-900 text-sm font-medium">Editar</button>
                      <button onClick={() => setConfirmDelete(cat)} className="text-red-600 hover:text-red-900 text-sm font-medium">Excluir</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <Modal title={editing ? "Editar Categoria" : "Nova Categoria"} onClose={closeModal} onSubmit={handleSubmit} submitting={submitting}>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nome *</label>
              <input type="text" name="name" value={form.name} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
              <textarea name="description" value={form.description} onChange={handleChange} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Imagem (URL)</label>
              <input type="url" name="imageUrl" value={form.imageUrl} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>
        </Modal>
      )}

      {confirmDelete && (
        <ConfirmDialog
          open={true}
          onClose={() => setConfirmDelete(null)}
          onConfirm={handleDelete}
          title="Excluir categoria"
          message={`Tem certeza que deseja excluir "${confirmDelete.name}"?`}
        />
      )}
    </div>
  );
}