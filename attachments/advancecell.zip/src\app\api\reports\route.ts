import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { startOfDay, endOfDay, subDays, startOfMonth, endOfMonth, format } from "date-fns";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get("type") || "sales";
  const startDate = searchParams.get("startDate");
  const endDate = searchParams.get("endDate");
  const groupBy = searchParams.get("groupBy") || "day";

  const start = startDate ? new Date(startDate) : startOfDay(subDays(new Date(), 30));
  const end = endDate ? endOfDay(new Date(endDate)) : endOfDay(new Date());

  switch (type) {
    case "sales": {
      const orders = await prisma.serviceOrder.findMany({
        where: {
          createdAt: { gte: start, lte: end },
          status: { not: "CANCELLED" },
        },
        include: {
          client: true,
          items: { include: { product: { include: { category: true } } } },
          services: { include: { serviceType: true } },
        },
        orderBy: { createdAt: "desc" },
      });

      const formatDate = (d: Date) => groupBy === "month" ? format(d, "yyyy-MM") : format(d, "yyyy-MM-dd");

      const grouped = orders.reduce((acc, order) => {
        const key = formatDate(order.createdAt);
        if (!acc[key]) {
          acc[key] = { date: key, orders: 0, revenue: 0, partsRevenue: 0, laborRevenue: 0, paid: 0, pending: 0 };
        }
        acc[key].orders++;
        acc[key].revenue += Number(order.totalPrice);
        acc[key].partsRevenue += Number(order.partsPrice);
        acc[key].laborRevenue += Number(order.laborPrice);
        acc[key].paid += Number(order.paidAmount);
        acc[key].pending += Number(order.totalPrice) - Number(order.paidAmount);
        return acc;
      }, {} as Record<string, { date: string; orders: number; revenue: number; partsRevenue: number; laborRevenue: number; paid: number; pending: number }>);

      return NextResponse.json({
        type: "sales",
        period: { start, end },
        summary: {
          totalOrders: orders.length,
          totalRevenue: orders.reduce((s, o) => s + Number(o.totalPrice), 0),
          totalParts: orders.reduce((s, o) => s + Number(o.partsPrice), 0),
          totalLabor: orders.reduce((s, o) => s + Number(o.laborPrice), 0),
          totalPaid: orders.reduce((s, o) => s + Number(o.paidAmount), 0),
          totalPending: orders.reduce((s, o) => s + Number(o.totalPrice) - Number(o.paidAmount), 0),
          avgTicket: orders.length > 0 ? orders.reduce((s, o) => s + Number(o.totalPrice), 0) / orders.length : 0,
        },
        data: Object.values(grouped).sort((a, b) => a.date.localeCompare(b.date)),
        details: orders,
      });
    }

    case "products": {
      const items = await prisma.serviceOrderItem.findMany({
        where: { serviceOrder: { createdAt: { gte: start, lte: end }, status: { not: "CANCELLED" } } },
        include: { product: { include: { category: true } }, serviceOrder: { include: { client: true } } },
      });

      const byProduct = items.reduce((acc, item) => {
        const key = item.productId;
        if (!acc[key]) {
          acc[key] = { productId: key, name: item.product.name, category: item.product.category.name, sku: item.product.sku, quantity: 0, revenue: 0, cost: 0 };
        }
        acc[key].quantity += item.quantity;
        acc[key].revenue += Number(item.totalPrice);
        acc[key].cost += Number(item.product.costPrice || 0) * item.quantity;
        return acc;
      }, {} as Record<string, { productId: string; name: string; category: string; sku: string | null; quantity: number; revenue: number; cost: number }>);

      return NextResponse.json({
        type: "products",
        period: { start, end },
        summary: {
          totalItemsSold: items.reduce((s, i) => s + i.quantity, 0),
          totalRevenue: items.reduce((s, i) => s + Number(i.totalPrice), 0),
          totalCost: items.reduce((s, i) => s + Number(i.product.costPrice || 0) * i.quantity, 0),
        },
        data: Object.values(byProduct).sort((a, b) => b.quantity - a.quantity),
      });
    }

    case "services": {
      const services = await prisma.serviceOrderService.findMany({
        where: { serviceOrder: { createdAt: { gte: start, lte: end }, status: { not: "CANCELLED" } } },
        include: { serviceType: true, serviceOrder: { include: { client: true } } },
      });

      const byService = services.reduce((acc, svc) => {
        const key = svc.serviceTypeId;
        if (!acc[key]) {
          acc[key] = { serviceTypeId: key, name: svc.serviceType.name, quantity: 0, revenue: 0, avgPrice: 0 };
        }
        acc[key].quantity += svc.quantity;
        acc[key].revenue += Number(svc.totalPrice);
        return acc;
      }, {} as Record<string, { serviceTypeId: string; name: string; quantity: number; revenue: number; avgPrice: number }>);

      Object.values(byService).forEach(s => { s.avgPrice = s.quantity > 0 ? s.revenue / s.quantity : 0; });

      return NextResponse.json({
        type: "services",
        period: { start, end },
        summary: {
          totalServices: services.reduce((s, i) => s + i.quantity, 0),
          totalRevenue: services.reduce((s, i) => s + Number(i.totalPrice), 0),
        },
        data: Object.values(byService).sort((a, b) => b.quantity - a.quantity),
      });
    }

    case "clients": {
      const orders = await prisma.serviceOrder.findMany({
        where: { createdAt: { gte: start, lte: end }, status: { not: "CANCELLED" } },
        include: { client: true },
      });

      const byClient = orders.reduce((acc, order) => {
        const key = order.clientId;
        if (!acc[key]) {
          acc[key] = { clientId: key, name: order.client.name, phone: order.client.phone, orders: 0, totalSpent: 0, lastOrder: order.createdAt };
        }
        acc[key].orders++;
        acc[key].totalSpent += Number(order.totalPrice);
        if (order.createdAt > acc[key].lastOrder) acc[key].lastOrder = order.createdAt;
        return acc;
      }, {} as Record<string, { clientId: string; name: string; phone: string; orders: number; totalSpent: number; lastOrder: Date }>);

      return NextResponse.json({
        type: "clients",
        period: { start, end },
        summary: {
          totalClients: Object.keys(byClient).length,
          totalOrders: orders.length,
          totalRevenue: orders.reduce((s, o) => s + Number(o.totalPrice), 0),
        },
        data: Object.values(byClient).sort((a, b) => b.totalSpent - a.totalSpent),
      });
    }

    case "technician": {
      const orders = await prisma.serviceOrder.findMany({
        where: { createdAt: { gte: start, lte: end }, status: { not: "CANCELLED" }, technician: { not: null } },
        include: { items: true, services: true },
      });

      const byTech = orders.reduce((acc, order) => {
        const key = order.technician || "Sem técnico";
        if (!acc[key]) {
          acc[key] = { technician: key, orders: 0, revenue: 0, partsRevenue: 0, laborRevenue: 0 };
        }
        acc[key].orders++;
        acc[key].revenue += Number(order.totalPrice);
        acc[key].partsRevenue += Number(order.partsPrice);
        acc[key].laborRevenue += Number(order.laborPrice);
        return acc;
      }, {} as Record<string, { technician: string; orders: number; revenue: number; partsRevenue: number; laborRevenue: number }>);

      return NextResponse.json({
        type: "technician",
        period: { start, end },
        summary: {
          totalOrders: orders.length,
          totalRevenue: orders.reduce((s, o) => s + Number(o.totalPrice), 0),
        },
        data: Object.values(byTech).sort((a, b) => b.revenue - a.revenue),
      });
    }

    case "payment": {
      const orders = await prisma.serviceOrder.findMany({
        where: { createdAt: { gte: start, lte: end }, status: { not: "CANCELLED" } },
        select: { paymentMethod: true, paidAmount: true, totalPrice: true, createdAt: true },
      });

      const byMethod = orders.reduce((acc, order) => {
        const key = order.paymentMethod || "Não informado";
        if (!acc[key]) {
          acc[key] = { method: key, count: 0, paid: 0, total: 0 };
        }
        acc[key].count++;
        acc[key].paid += Number(order.paidAmount);
        acc[key].total += Number(order.totalPrice);
        return acc;
      }, {} as Record<string, { method: string; count: number; paid: number; total: number }>);

      return NextResponse.json({
        type: "payment",
        period: { start, end },
        summary: {
          totalPaid: orders.reduce((s, o) => s + Number(o.paidAmount), 0),
          totalPending: orders.reduce((s, o) => s + Number(o.totalPrice) - Number(o.paidAmount), 0),
        },
        data: Object.values(byMethod).sort((a, b) => b.paid - a.paid),
      });
    }

    case "abc": {
      const items = await prisma.serviceOrderItem.findMany({
        where: { serviceOrder: { createdAt: { gte: start, lte: end }, status: { not: "CANCELLED" } } },
        include: { product: true },
      });

      const byProduct = items.reduce((acc, item) => {
        const key = item.productId;
        if (!acc[key]) {
          acc[key] = { productId: key, name: item.product.name, revenue: 0 };
        }
        acc[key].revenue += Number(item.totalPrice);
        return acc;
      }, {} as Record<string, { productId: string; name: string; revenue: number }>);

      const sorted = Object.values(byProduct).sort((a, b) => b.revenue - a.revenue);
      const totalRevenue = sorted.reduce((s, p) => s + p.revenue, 0);
      let cumulative = 0;

      const withClass = sorted.map(p => {
        cumulative += p.revenue;
        const percent = totalRevenue > 0 ? (cumulative / totalRevenue) * 100 : 0;
        let curve = "C";
        if (percent <= 80) curve = "A";
        else if (percent <= 95) curve = "B";
        return { ...p, percent: Math.round(percent * 100) / 100, curve };
      });

      return NextResponse.json({
        type: "abc",
        period: { start, end },
        data: withClass,
        summary: { totalProducts: withClass.length, totalRevenue },
      });
    }

    default:
      return NextResponse.json({ error: "Tipo de relatório inválido" }, { status: 400 });
  }
}