"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { Plus, Search, Edit, Trash2, Eye, User, Mail, Phone, MapPin, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Modal } from "@/components/ui/Modal";
import { ConfirmDialog } from "@/components/ui/Modal";
import { Badge } from "@/components/ui/Badge";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/Table";
import { DropdownMenu } from "@/components/ui/Dropdown";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Client } from "@/lib/types";
import { format, formatPhone } from "@/lib/utils";
import API from "@/lib/api";
import { ChangeEvent, FormEvent, useState } from "react";

interface ClientManagerV2Props {
  onDataChange: () => void;
}

export function ClientManagerV2({ onDataChange }: ClientManagerV2Props) {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Client | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Client | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [search, setSearch] = useState("");
  const [viewingClient, setViewingClient] = useState<Client | null>(null);

  const [form, setForm] = useState({
    name: "", email: "", phone: "", whatsapp: "", cpfCnpj: "",
    address: "", neighborhood: "", city: "", state: "", zipCode: "", notes: ""
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const data = await API.clients.list(search);
      setClients(data);
    } catch (error) {
      console.error("Erro ao carregar clientes:", error);
      setClients([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [search]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      if (editing) await API.clients.update(editing.id, form);
      else await API.clients.create(form);
      closeModal();
      onDataChange();
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    await API.clients.delete(confirmDelete.id);
    setConfirmDelete(null);
    onDataChange();
  };

  const handleEdit = (client: Client) => {
    setEditing(client);
    setForm({
      name: client.name,
      email: client.email || "",
      phone: client.phone,
      whatsapp: client.whatsapp || "",
      cpfCnpj: client.cpfCnpj || "",
      address: client.address || "",
      neighborhood: client.neighborhood || "",
      city: client.city || "",
      state: client.state || "",
      zipCode: client.zipCode || "",
      notes: client.notes || "",
    });
    setShowModal(true);
  };

  const handleView = (client: Client) => {
    setViewingClient(client);
  };

  const handleNew = () => {
    setEditing(null);
    setForm({
      name: "", email: "", phone: "", whatsapp: "", cpfCnpj: "",
      address: "", neighborhood: "", city: "", state: "", zipCode: "", notes: ""
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditing(null);
    setForm({
      name: "", email: "", phone: "", whatsapp: "", cpfCnpj: "",
      address: "", neighborhood: "", city: "", state: "", zipCode: "", notes: ""
    });
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const clientActions = (client: Client) => [
    { label: "Visualizar", value: `view-${client.id}`, icon: <Eye className="h-4 w-4" /> },
    { label: "Editar", value: `edit-${client.id}`, icon: <Edit className="h-4 w-4" /> },
    { label: "Nova OS", value: `os-${client.id}`, icon: <Plus className="h-4 w-4" /> },
    { label: "Excluir", value: `delete-${client.id}`, icon: <Trash2 className="h-4 w-4" />, danger: true },
  ];

  const handleAction = (value: string) => {
    const [action, id] = value.split("-");
    const client = clients.find(c => c.id === id);
    if (!client) return;
    
    switch (action) {
      case "view": handleView(client); break;
      case "edit": handleEdit(client); break;
      case "delete": setConfirmDelete(client); break;
    }
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Clientes</h1>
          <p className="text-gray-500 mt-1">Gerencie sua base de clientes e histórico.</p>
        </div>
        <Button onClick={handleNew}><Plus className="h-4 w-4 mr-2" /> Novo Cliente</Button>
      </div>

      <div className="card bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-col sm:flex-row gap-4 mb-4">
          <div className="flex-1">
            <Input placeholder="Buscar por nome, telefone, email..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
        </div>

        {clients.length === 0 ? (
          <div className="text-center py-12">
            <User className="h-12 w-12 mx-auto text-gray-300 mb-3" />
            <h3 className="text-lg font-medium text-gray-900 mb-1">Nenhum cliente cadastrado</h3>
            <p className="text-gray-500 mb-4">Comece adicionando seu primeiro cliente</p>
            <Button onClick={handleNew}><Plus className="h-4 w-4 mr-2" /> Criar primeiro cliente</Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Contato</TableHead>
                  <TableHead>CPF/CNPJ</TableHead>
                  <TableHead className="w-24 text-center">OS</TableHead>
                  <TableHead className="w-24 text-right">Total Gasto</TableHead>
                  <TableHead className="w-32">Última OS</TableHead>
                  <TableHead className="w-40">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {clients.map((client) => (
                  <TableRow key={client.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-medium">
                          {client.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{client.name}</p>
                          {client.email && <p className="text-xs text-gray-500">{client.email}</p>}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-500">
                      <p className="text-sm">{formatPhone(client.phone)}</p>
                      {client.whatsapp && <p className="text-xs text-green-600">WhatsApp: {formatPhone(client.whatsapp)}</p>}
                    </TableCell>
                    <TableCell className="text-gray-500 font-mono text-sm">{client.cpfCnpj || "-"}</TableCell>
                    <TableCell className="text-center">
                      <Badge variant="default">{client._count.serviceOrders}</Badge>
                    </TableCell>
                    <TableCell className="text-right font-medium text-gray-900">
                      {client.serviceOrders && client.serviceOrders.length > 0 
                        ? formatCurrency(client.serviceOrders.reduce((s, o) => s + Number(o.totalPrice), 0))
                        : "R$ 0,00"}
                    </TableCell>
                    <TableCell className="text-gray-500 text-sm">
                      {client.serviceOrders && client.serviceOrders.length > 0
                        ? format(new Date(client.serviceOrders[0].createdAt), "dd/MM/yyyy")
                        : "-"}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu
                        trigger={<Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="h-4 w-4" /></Button>}
                        items={[
                          { label: "Visualizar", value: `view-${client.id}`, icon: <Eye className="h-4 w-4" /> },
                          { label: "Editar", value: `edit-${client.id}`, icon: <Edit className="h-4 w-4" /> },
                          { label: "Nova OS", value: `os-${client.id}`, icon: <Plus className="h-4 w-4" /> },
                          { label: "Excluir", value: `delete-${client.id}`, icon: <Trash2 className="h-4 w-4" />, danger: true },
                        ]}
                        onSelect={handleAction}
                        align="right"
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      {showModal && (
        <Modal
          open={true}
          onClose={closeModal}
          title={editing ? `Editar Cliente: ${editing.name}` : "Novo Cliente"}
          size="lg"
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Input label="Nome *" name="name" value={form.name} onChange={handleChange} required placeholder="Nome completo" />
              </div>
              <Input label="Telefone *" name="phone" type="tel" value={form.phone} onChange={handleChange} required placeholder="(11) 99999-9999" />
              <Input label="WhatsApp" name="whatsapp" type="tel" value={form.whatsapp} onChange={handleChange} placeholder="(11) 99999-9999" />
              <Input label="Email" name="email" type="email" value={form.email} onChange={handleChange} placeholder="cliente@email.com" />
              <Input label="CPF/CNPJ" name="cpfCnpj" value={form.cpfCnpj} onChange={handleChange} placeholder="000.000.000-00 ou 00.000.000/0000-00" />
              <Input label="CEP" name="zipCode" value={form.zipCode} onChange={handleChange} placeholder="00000-000" />
              <Input label="Endereço" name="address" value={form.address} onChange={handleChange} placeholder="Rua, número, complemento" />
              <Input label="Bairro" name="neighborhood" value={form.neighborhood} onChange={handleChange} />
              <Input label="Cidade" name="city" value={form.city} onChange={handleChange} />
              <Input label="Estado" name="state" value={form.state} onChange={handleChange} maxLength={2} placeholder="SP" />
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Observações</label>
                <textarea name="notes" value={form.notes} onChange={handleChange} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
              </div>
            </div>
            <div className="flex justify-end gap-3 border-t pt-6">
              <Button type="button" variant="outline" onClick={closeModal}>Cancelar</Button>
              <Button type="submit" loading={submitting}>{submitting ? "Salvando..." : editing ? "Atualizar" : "Criar Cliente"}</Button>
            </div>
          </form>
        </Modal>
      )}

      {viewingClient && (
        <Modal
          open={true}
          onClose={() => setViewingClient(null)}
          title={viewingClient.name}
          size="lg"
        >
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-gray-500">Nome</p>
                <p className="font-medium text-gray-900">{viewingClient.name}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Telefone</p>
                <p className="font-medium text-gray-900">{formatPhone(viewingClient.phone)}</p>
              </div>
              {viewingClient.whatsapp && (
                <div>
                  <p className="text-sm font-medium text-gray-500">WhatsApp</p>
                  <p className="font-medium text-green-600">{formatPhone(viewingClient.whatsapp)}</p>
                </div>
              )}
              {viewingClient.email && (
                <div>
                  <p className="text-sm font-medium text-gray-500">Email</p>
                  <p className="font-medium text-gray-900">{viewingClient.email}</p>
                </div>
              )}
              {viewingClient.cpfCnpj && (
                <div>
                  <p className="text-sm font-medium text-gray-500">CPF/CNPJ</p>
                  <p className="font-mono text-gray-900">{viewingClient.cpfCnpj}</p>
                </div>
              )}
              {viewingClient.zipCode && (
                <div>
                  <p className="text-sm font-medium text-gray-500">CEP</p>
                  <p className="font-medium text-gray-900">{viewingClient.zipCode}</p>
                </div>
              )}
            </div>

            {viewingClient.address && (
              <div className="border-t pt-4">
                <h4 className="font-medium mb-2">Endereço</h4>
                <p className="text-gray-900">{viewingClient.address}</p>
                {viewingClient.neighborhood && <p className="text-gray-500">{viewingClient.neighborhood}</p>}
                {viewingClient.city && viewingClient.state && <p className="text-gray-500">{viewingClient.city} - {viewingClient.state}</p>}
                {viewingClient.zipCode && <p className="text-gray-500">CEP: {viewingClient.zipCode}</p>}
              </div>
            )}

            {viewingClient.notes && (
              <div className="border-t pt-4">
                <h4 className="font-medium mb-2">Observações</h4>
                <p className="text-gray-900">{viewingClient.notes}</p>
              </div>
            )}

            <div className="border-t pt-4">
              <h4 className="font-medium mb-3">Histórico de Ordens de Serviço ({viewingClient._count.serviceOrders})</h4>
              <p className="text-sm text-gray-500">Clique em "Nova OS" para criar uma nova ordem para este cliente.</p>
            </div>
          </div>
        </Modal>
      )}

      {confirmDelete && (
        <ConfirmDialog
          open={true}
          onClose={() => setConfirmDelete(null)}
          onConfirm={handleDelete}
          title="Excluir Cliente"
          message={`Tem certeza que deseja excluir "${confirmDelete.name}"?`}
          confirmLabel="Excluir"
          variant="destructive"
        />
      )}
    </div>
  );
}