import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { startOfDay, endOfDay, startOfMonth, endOfMonth, subDays, subMonths, format } from "date-fns";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const period = searchParams.get("period") || "month"; // today, week, month, year

  const now = new Date();
  let startDate: Date;
  let endDate: Date = endOfDay(now);

  switch (period) {
    case "today":
      startDate = startOfDay(now);
      break;
    case "week":
      startDate = startOfDay(subDays(now, 7));
      break;
    case "month":
      startDate = startOfDay(subMonths(now, 1));
      break;
    case "year":
      startDate = startOfDay(subMonths(now, 12));
      break;
    default:
      startDate = startOfMonth(now);
  }

  const [
    totalClients,
    totalProducts,
    totalServiceOrders,
    serviceOrdersPeriod,
    revenuePeriod,
    ordersByStatus,
    topServices,
    topProducts,
    lowStockProducts,
    monthlyRevenue,
    monthlyOrders,
  ] = await Promise.all([
    prisma.client.count(),
    prisma.product.count({ where: { active: true } }),
    prisma.serviceOrder.count(),
    prisma.serviceOrder.count({
      where: { createdAt: { gte: startDate, lte: endDate } },
    }),
    prisma.serviceOrder.aggregate({
      where: {
        createdAt: { gte: startDate, lte: endDate },
        status: { not: "CANCELLED" },
      },
      _sum: { totalPrice: true, paidAmount: true },
    }),
    prisma.serviceOrder.groupBy({
      by: ["status"],
      where: { createdAt: { gte: startDate, lte: endDate } },
      _count: { id: true },
    }),
    prisma.serviceOrderService.groupBy({
      by: ["serviceTypeId"],
      where: { serviceOrder: { createdAt: { gte: startDate, lte: endDate }, status: { not: "CANCELLED" } } },
      _sum: { quantity: true, totalPrice: true },
      _count: { id: true },
      orderBy: { _sum: { quantity: "desc" } },
      take: 10,
    }),
    prisma.serviceOrderItem.groupBy({
      by: ["productId"],
      where: { serviceOrder: { createdAt: { gte: startDate, lte: endDate }, status: { not: "CANCELLED" } } },
      _sum: { quantity: true, totalPrice: true },
      _count: { id: true },
      orderBy: { _sum: { quantity: "desc" } },
      take: 10,
    }),
    prisma.product.findMany({
      where: { active: true, stock: { lte: prisma.product.fields.minStock } },
      orderBy: { stock: "asc" },
      take: 10,
      include: { category: true },
    }),
    prisma.$queryRaw`SELECT 
      TO_CHAR("createdAt", 'YYYY-MM') as month,
      SUM("totalPrice") as revenue,
      COUNT(*) as orders
    FROM "ServiceOrder"
    WHERE "createdAt" >= ${startDate} AND "status" != 'CANCELLED'
    GROUP BY TO_CHAR("createdAt", 'YYYY-MM')
    ORDER BY month ASC`,
  ]);

  // Get service type names for top services
  const serviceTypeIds = topServices.map(s => s.serviceTypeId);
  const serviceTypes = await prisma.serviceType.findMany({
    where: { id: { in: serviceTypeIds } },
  });
  const serviceTypeMap = Object.fromEntries(serviceTypes.map(s => [s.id, s.name]));

  // Get product names for top products
  const productIds = topProducts.map(p => p.productId);
  const products = await prisma.product.findMany({
    where: { id: { in: productIds } },
  });
  const productMap = Object.fromEntries(products.map(p => [p.id, p.name]));

  return NextResponse.json({
    period,
    kpis: {
      totalClients,
      totalProducts,
      totalServiceOrders,
      ordersPeriod: serviceOrdersPeriod,
      revenue: Number(revenuePeriod._sum.totalPrice || 0),
      paid: Number(revenuePeriod._sum.paidAmount || 0),
      pending: Number(revenuePeriod._sum.totalPrice || 0) - Number(revenuePeriod._sum.paidAmount || 0),
      avgTicket: serviceOrdersPeriod > 0 ? Number(revenuePeriod._sum.totalPrice || 0) / serviceOrdersPeriod : 0,
    },
    ordersByStatus: ordersByStatus.map(o => ({
      status: o.status,
      count: o._count.id,
    })),
    topServices: topServices.map(s => ({
      name: serviceTypeMap[s.serviceTypeId] || "N/A",
      quantity: s._sum.quantity || 0,
      revenue: Number(s._sum.totalPrice || 0),
      count: s._count.id,
    })),
    topProducts: topProducts.map(p => ({
      name: productMap[p.productId] || "N/A",
      quantity: p._sum.quantity || 0,
      revenue: Number(p._sum.totalPrice || 0),
      count: p._count.id,
    })),
    lowStockProducts: lowStockProducts.map(p => ({
      id: p.id,
      name: p.name,
      stock: p.stock,
      minStock: p.minStock,
      category: p.category.name,
    })),
    monthlyRevenue: (monthlyRevenue as Array<{ month: string; revenue: number; orders: bigint }>).map(m => ({
      month: m.month,
      revenue: Number(m.revenue),
      orders: Number(m.orders),
    })),
  });
}