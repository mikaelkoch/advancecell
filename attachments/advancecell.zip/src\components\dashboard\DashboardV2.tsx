"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { Users, Package, Wrench, DollarSign, TrendingUp, TrendingDown, Minus, Clock, CheckCircle, AlertTriangle, XCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { formatCurrency } from "@/lib/utils";
import API from "@/lib/api";
import { useState, useEffect } from "react";

interface KPIData {
  totalClients: number;
  totalProducts: number;
  totalOrders: number;
  ordersPeriod: number;
  revenue: number;
  paid: number;
  pending: number;
  avgTicket: number;
}

interface DashboardData {
  period: string;
  kpis: KPIData;
  ordersByStatus: { status: string; count: number }[];
  monthlyRevenue: { month: string; revenue: number; orders: number }[];
  lowStockProducts: { id: string; name: string; stock: number; minStock: number; category: string }[];
}

const STATUS_LABELS: Record<string, string> = {
  RECEIVED: "Recebido",
  DIAGNOSING: "Diagnosticando",
  WAITING_APPROVAL: "Aguardando Aprovação",
  IN_REPAIR: "Em Reparo",
  READY: "Pronto",
  DELIVERED: "Entregue",
  CANCELLED: "Cancelado",
};

const STATUS_COLORS: Record<string, string> = {
  RECEIVED: "bg-blue-100 text-blue-800",
  DIAGNOSING: "bg-purple-100 text-purple-800",
  WAITING_APPROVAL: "bg-yellow-100 text-yellow-800",
  IN_REPAIR: "bg-orange-100 text-orange-800",
  READY: "bg-green-100 text-green-800",
  DELIVERED: "bg-gray-100 text-gray-800",
  CANCELLED: "bg-red-100 text-red-800",
};

const STATUS_ICONS: Record<string, React.ReactNode> = {
  RECEIVED: <Clock className="h-4 w-4" />,
  DIAGNOSING: <Wrench className="h-4 w-4" />,
  WAITING_APPROVAL: <AlertTriangle className="h-4 w-4" />,
  IN_REPAIR: <Wrench className="h-4 w-4" />,
  READY: <CheckCircle className="h-4 w-4" />,
  DELIVERED: <CheckCircle className="h-4 w-4" />,
  CANCELLED: <XCircle className="h-4 w-4" />,
};

const KPI_CARDS = [
  { key: "totalClients", label: "Clientes", icon: Users, color: "bg-blue-500", trend: "+12%" },
  { key: "totalProducts", label: "Produtos Ativos", icon: Package, color: "bg-green-500", trend: "+5%" },
  { key: "ordersPeriod", label: "OS no Período", icon: Wrench, color: "bg-purple-500", trend: "+8%" },
  { key: "revenue", label: "Faturamento", icon: DollarSign, color: "bg-orange-500", trend: "+15%", isCurrency: true },
];

export function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<"today" | "week" | "month" | "year">("month");

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await API.dashboard.get(period);
      setData(res);
    } catch (error) {
      console.error("Erro ao carregar dashboard:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [period]);

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="flex items-center justify-between">
          <div>
            <div className="h-6 w-48 bg-gray-200 rounded" />
            <div className="mt-2 h-4 w-64 bg-gray-200 rounded" />
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-24 bg-gray-200 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Erro ao carregar dashboard</p>
        <Button onClick={fetchData} className="mt-4">Tentar novamente</Button>
      </div>
    );
  }

  const { kpis, ordersByStatus, monthlyRevenue, lowStockProducts } = data;

  const getTrendIcon = (trend: string) => {
    if (trend.startsWith("+")) return <TrendingUp className="h-4 w-4 text-green-600" />;
    if (trend.startsWith("-")) return <TrendingDown className="h-4 w-4 text-red-600" />;
    return <Minus className="h-4 w-4 text-gray-400" />;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-500 mt-1">Acompanhe os principais indicadores da sua assistência técnica.</p>
        </div>
        <div className="flex items-center gap-2">
          {(["today", "week", "month", "year"] as const).map((p) => (
            <Button
              key={p}
              variant={period === p ? "default" : "outline"}
              size="sm"
              onClick={() => setPeriod(p)}
            >
              {p === "today" ? "Hoje" : p === "week" ? "7 dias" : p === "month" ? "30 dias" : "12 meses"}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {KPI_CARDS.map((kpi) => (
          <Card key={kpi.key}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">{kpi.label}</p>
                  <p className="mt-2 text-2xl font-bold text-gray-900">
                    {kpi.isCurrency ? formatCurrency(kpis[kpi.key as keyof KPIData] as number) : (kpis[kpi.key as keyof KPIData] as number).toLocaleString("pt-BR")}
                  </p>
                  <p className="mt-2 flex items-center gap-1 text-sm text-gray-500">
                    {getTrendIcon(kpi.trend)}
                    <span className="font-medium text-green-600">{kpi.trend}</span>
                    <span>vs período anterior</span>
                  </p>
                </div>
                <div className={cn("p-3 rounded-xl", kpi.color)}>
                  <kpi.icon className="h-6 w-6 text-white" aria-hidden="true" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        <Card className="lg:col-span-4">
          <CardHeader>
            <CardTitle>Faturamento por Período</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-end gap-2">
              {monthlyRevenue.length > 0 ? (
                monthlyRevenue.map((m, i) => {
                  const maxRevenue = Math.max(...monthlyRevenue.map(x => x.revenue));
                  const height = maxRevenue > 0 ? (m.revenue / maxRevenue) * 100 : 0;
                  return (
                    <div key={m.month} className="flex-1 flex flex-col items-center" title={formatCurrency(m.revenue)}>
                      <div className="w-full bg-gray-100 rounded-t flex-1 relative">
                        <div
                          className="absolute bottom-0 left-0 right-0 bg-blue-600 rounded-t transition-all duration-300"
                          style={{ height: `${height}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-500 mt-2">{m.month}</span>
                      <span className="text-xs font-medium text-gray-900">{formatCurrency(m.revenue)}</span>
                    </div>
                  );
                })
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-gray-400">
                  <Package className="h-12 w-12 mb-2" />
                  <p>Sem dados para o período</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Ordens de Serviço por Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {ordersByStatus.length > 0 ? (
                ordersByStatus.map((s) => (
                  <div key={s.status} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className={cn("px-2 py-1 rounded-full text-xs font-medium", STATUS_COLORS[s.status])}>
                        {STATUS_ICONS[s.status]}
                        {STATUS_LABELS[s.status] || s.status}
                      </span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-32 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-600 rounded-full transition-all duration-300"
                          style={{ width: `${ordersByStatus.length > 0 ? (s.count / Math.max(...ordersByStatus.map(x => x.count))) * 100 : 0}%` }}
                        />
                      </div>
                      <span className="font-medium text-gray-900 w-12 text-right">{s.count}</span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-gray-400">
                  <Wrench className="h-12 w-12 mx-auto mb-2" />
                  <p>Nenhuma OS no período</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Produtos com Estoque Baixo</CardTitle>
          </CardHeader>
          <CardContent>
            {lowStockProducts.length > 0 ? (
              <div className="space-y-3">
                {lowStockProducts.slice(0, 5).map((p) => (
                  <div key={p.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-yellow-100 rounded-lg">
                        <AlertTriangle className="h-5 w-5 text-yellow-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{p.name}</p>
                        <p className="text-xs text-gray-500">{p.category} • Mín: {p.minStock}</p>
                      </div>
                    </div>
                    <Badge variant="warning">{p.stock}</Badge>
                  </div>
                ))}
                {lowStockProducts.length > 5 && (
                  <p className="text-sm text-gray-500 text-center mt-2">+{lowStockProducts.length - 5} produtos</p>
                )}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-400">
                <CheckCircle className="h-12 w-12 mx-auto mb-2 text-green-500" />
                <p className="font-medium">Todos os estoques OK</p>
                <p className="text-sm">Nenhum produto abaixo do mínimo</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Total Recebido</p>
                <p className="mt-1 text-2xl font-bold text-green-600">{formatCurrency(kpis.paid)}</p>
              </div>
              <div className="p-3 bg-green-100 rounded-xl">
                <DollarSign className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">A Receber</p>
                <p className="mt-1 text-2xl font-bold text-orange-600">{formatCurrency(kpis.pending)}</p>
              </div>
              <div className="p-3 bg-orange-100 rounded-xl">
                <Clock className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Ticket Médio</p>
                <p className="mt-1 text-2xl font-bold text-gray-900">{formatCurrency(kpis.avgTicket)}</p>
              </div>
              <div className="p-3 bg-purple-100 rounded-xl">
                <TrendingUp className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export { Dashboard as DashboardV2 };