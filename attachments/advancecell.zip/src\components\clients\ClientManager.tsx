"use client";

import { Client } from "@/lib/types";
import { Modal, ConfirmDialog } from "@/components/ui/Modal";
import { ChangeEvent, FormEvent, useState } from "react";
import API from "@/lib/api";

export function ClientManager({ onDataChange }: { onDataChange: () => void }) {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Client | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Client | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState({
    name: "", email: "", phone: "", whatsapp: "", cpfCnpj: "",
    address: "", neighborhood: "", city: "", state: "", zipCode: "", notes: ""
  });

  const fetchData = async () => {
    try {
      const data = await API.clients.list(search);
      setClients(data);
    } catch (error) {
      console.error("Erro ao carregar clientes:", error);
      setClients([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      if (editing) await API.clients.update(editing.id, form);
      else await API.clients.create(form);
      closeModal();
      onDataChange();
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    await API.clients.delete(confirmDelete.id);
    setConfirmDelete(null);
    onDataChange();
  };

  const handleEdit = (client: Client) => {
    setEditing(client);
    setForm({
      name: client.name,
      email: client.email || "",
      phone: client.phone,
      whatsapp: client.whatsapp || "",
      cpfCnpj: client.cpfCnpj || "",
      address: client.address || "",
      neighborhood: client.neighborhood || "",
      city: client.city || "",
      state: client.state || "",
      zipCode: client.zipCode || "",
      notes: client.notes || "",
    });
    setShowModal(true);
  };

  const handleNew = () => {
    setEditing(null);
    setForm({
      name: "", email: "", phone: "", whatsapp: "", cpfCnpj: "",
      address: "", neighborhood: "", city: "", state: "", zipCode: "", notes: ""
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditing(null);
    setForm({
      name: "", email: "", phone: "", whatsapp: "", cpfCnpj: "",
      address: "", neighborhood: "", city: "", state: "", zipCode: "", notes: ""
    });
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Clientes</h2>
        <div className="flex items-center gap-4">
          <input
            type="text"
            placeholder="Buscar por nome, telefone, email..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg w-64 focus:ring-2 focus:ring-blue-500"
          />
          <button onClick={handleNew} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">+ Novo Cliente</button>
        </div>
      </div>

      {clients.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl shadow-sm">
          <p className="text-gray-500 mb-4">Nenhum cliente cadastrado</p>
          <button onClick={handleNew} className="bg-blue-600 text-white px-4 py-2 rounded-lg">Criar primeiro cliente</button>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nome</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Contato</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">CPF/CNPJ</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">OS</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {clients.map(client => (
                <tr key={client.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <p className="text-sm font-medium text-gray-900">{client.name}</p>
                    {client.email && <p className="text-xs text-gray-500">{client.email}</p>}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {client.phone}
                    {client.whatsapp && <span className="ml-2 text-green-600">✓ WhatsApp</span>}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500 font-mono">{client.cpfCnpj || "-"}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{client._count.serviceOrders}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button onClick={() => handleEdit(client)} className="text-blue-600 hover:text-blue-900 text-sm font-medium">Editar</button>
                      <button onClick={() => setConfirmDelete(client)} className="text-red-600 hover:text-red-900 text-sm font-medium">Excluir</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <Modal title={editing ? "Editar Cliente" : "Novo Cliente"} onClose={closeModal} onSubmit={handleSubmit} submitting={submitting}>
          <div className="space-y-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Nome *</label>
              <input type="text" name="name" value={form.name} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Telefone *</label>
              <input type="tel" name="phone" value={form.phone} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">WhatsApp</label>
              <input type="tel" name="whatsapp" value={form.whatsapp} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input type="email" name="email" value={form.email} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">CPF/CNPJ</label>
              <input type="text" name="cpfCnpj" value={form.cpfCnpj} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Endereço</label>
              <input type="text" name="address" value={form.address} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Bairro</label>
              <input type="text" name="neighborhood" value={form.neighborhood} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Cidade</label>
              <input type="text" name="city" value={form.city} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Estado</label>
              <input type="text" name="state" value={form.state} onChange={handleChange} maxLength={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">CEP</label>
              <input type="text" name="zipCode" value={form.zipCode} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Observações</label>
              <textarea name="notes" value={form.notes} onChange={handleChange} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>
        </Modal>
      )}

      {confirmDelete && (
        <ConfirmDialog open={true} onClose={() => setConfirmDelete(null)} onConfirm={handleDelete} title="Excluir cliente" message={`Excluir "${confirmDelete.name}"?`} />
      )}
    </div>
  );
}