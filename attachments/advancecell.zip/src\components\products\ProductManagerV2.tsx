"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { Plus, Search, Filter, Edit, Trash2, Eye, Package, AlertTriangle, CheckCircle, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Select } from "@/components/ui/Select";
import { Modal } from "@/components/ui/Modal";
import { ConfirmDialog } from "@/components/ui/Modal";
import { Badge } from "@/components/ui/Badge";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/Table";
import { DropdownMenu } from "@/components/ui/Dropdown";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Product, Category } from "@/lib/types";
import { formatCurrency } from "@/lib/utils";
import API from "@/lib/api";
import { ChangeEvent, FormEvent, useState } from "react";

interface ProductManagerV2Props {
  categories: Category[];
  onDataChange: () => void;
}

export function ProductManagerV2({ categories, onDataChange }: ProductManagerV2Props) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Product | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [viewMode, setViewMode] = useState<"table" | "grid">("table");
  const [search, setSearch] = useState("");
  const [filterCategory, setFilterCategory] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "active" | "inactive" | "low-stock">("all");

  const [form, setForm] = useState({
    name: "", description: "", price: "", costPrice: "", stock: "0", minStock: "5",
    sku: "", barcode: "", imageUrl: "", active: true, featured: false, categoryId: ""
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const data = await API.products.list({ categoryId: filterCategory || undefined, search: search || undefined });
      setProducts(data);
    } catch (error) {
      console.error("Erro ao carregar produtos:", error);
      setProducts([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [filterCategory, search, filterStatus]);

  const filteredProducts = products.filter(p => {
    if (filterStatus === "active" && !p.active) return false;
    if (filterStatus === "inactive" && p.active) return false;
    if (filterStatus === "low-stock" && (p.stock > p.minStock || !p.active)) return false;
    return true;
  });

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const payload = {
        name: form.name,
        description: form.description,
        price: parseFloat(form.price) || 0,
        costPrice: form.costPrice ? parseFloat(form.costPrice) : null,
        stock: parseInt(form.stock) || 0,
        minStock: parseInt(form.minStock) || 5,
        sku: form.sku || null,
        barcode: form.barcode || null,
        imageUrl: form.imageUrl || null,
        active: form.active,
        featured: form.featured,
        categoryId: form.categoryId,
      };
      if (editing) await API.products.update(editing.id, payload);
      else await API.products.create(payload);
      closeModal();
      onDataChange();
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    await API.products.delete(confirmDelete.id);
    setConfirmDelete(null);
    onDataChange();
  };

  const handleEdit = (prod: Product) => {
    setEditing(prod);
    setForm({
      name: prod.name,
      description: prod.description || "",
      price: prod.price.toString(),
      costPrice: prod.costPrice?.toString() || "",
      stock: prod.stock.toString(),
      minStock: prod.minStock.toString(),
      sku: prod.sku || "",
      barcode: prod.barcode || "",
      imageUrl: prod.imageUrl || "",
      active: prod.active,
      featured: prod.featured,
      categoryId: prod.categoryId,
    });
    setShowModal(true);
  };

  const handleNew = () => {
    setEditing(null);
    setForm({
      name: "", description: "", price: "", costPrice: "", stock: "0", minStock: "5",
      sku: "", barcode: "", imageUrl: "", active: true, featured: false, categoryId: categories[0]?.id || ""
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditing(null);
    setForm({
      name: "", description: "", price: "", costPrice: "", stock: "0", minStock: "5",
      sku: "", barcode: "", imageUrl: "", active: true, featured: false, categoryId: categories[0]?.id || ""
    });
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === "checkbox") setForm(prev => ({ ...prev, [name]: (e.target as HTMLInputElement).checked }));
    else setForm(prev => ({ ...prev, [name]: value }));
  };

  const lowStockCount = products.filter(p => p.stock <= p.minStock && p.active).length;

  const getStockBadge = (prod: Product) => {
    if (prod.stock === 0) return { variant: "destructive" as const, label: "Sem estoque" };
    if (prod.stock <= prod.minStock) return { variant: "warning" as const, label: `Baixo (${prod.stock})` };
    return { variant: "success" as const, label: `OK (${prod.stock})` };
  };

  const productActions = (prod: Product) => [
    { label: "Visualizar", value: `view-${prod.id}`, icon: <Eye className="h-4 w-4" /> },
    { label: "Editar", value: `edit-${prod.id}`, icon: <Edit className="h-4 w-4" /> },
    { label: "Ajustar Estoque", value: `stock-${prod.id}`, icon: <Package className="h-4 w-4" /> },
    { label: "Excluir", value: `delete-${prod.id}`, icon: <Trash2 className="h-4 w-4" />, danger: true },
  ];

  const handleAction = (value: string) => {
    const [action, id] = value.split("-");
    const prod = products.find(p => p.id === id);
    if (!prod) return;
    
    switch (action) {
      case "edit": handleEdit(prod); break;
      case "stock": handleEdit(prod); break;
      case "delete": setConfirmDelete(prod); break;
    }
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Produtos</h1>
          <p className="text-gray-500 mt-1">Gerencie seu catálogo de acessórios e peças.</p>
        </div>
        <div className="flex items-center gap-3">
          {lowStockCount > 0 && (
            <Badge variant="warning" className="gap-1">
              <AlertTriangle className="h-3 w-3" />
              {lowStockCount} com estoque baixo
            </Badge>
          )}
          <Button onClick={handleNew}><Plus className="h-4 w-4 mr-2" /> Novo Produto</Button>
        </div>
      </div>

      <div className="card bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-col sm:flex-row gap-4 mb-4">
          <div className="flex-1">
            <Input placeholder="Buscar por nome, SKU, código de barras..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <Select
            value={filterCategory}
            onChange={e => setFilterCategory(e.target.value)}
            options={[{ value: "", label: "Todas as categorias" }, ...categories.map(c => ({ value: c.id, label: c.name }))]}
            className="w-full sm:w-48"
          />
          <Select
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value as "all" | "active" | "inactive" | "low-stock")}
            options={[
              { value: "all", label: "Todos" },
              { value: "active", label: "Ativos" },
              { value: "inactive", label: "Inativos" },
              { value: "low-stock", label: "Estoque Baixo" },
            ]}
            className="w-full sm:w-40"
          />
          <div className="flex items-center gap-2">
            <Button variant={viewMode === "table" ? "default" : "outline"} size="icon" onClick={() => setViewMode("table")}><Table className="h-4 w-4" /></Button>
            <Button variant={viewMode === "grid" ? "default" : "outline"} size="icon" onClick={() => setViewMode("grid")}><Package className="h-4 w-4" /></Button>
          </div>
        </div>

        {filteredProducts.length === 0 ? (
          <div className="text-center py-12">
            <Package className="h-12 w-12 mx-auto text-gray-300 mb-3" />
            <h3 className="text-lg font-medium text-gray-900 mb-1">Nenhum produto encontrado</h3>
            <p className="text-gray-500 mb-4">Comece adicionando seu primeiro produto</p>
            <Button onClick={handleNew}><Plus className="h-4 w-4 mr-2" /> Criar primeiro produto</Button>
          </div>
        ) : viewMode === "table" ? (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-16"></TableHead>
                  <TableHead>Produto</TableHead>
                  <TableHead>Categoria</TableHead>
                  <TableHead className="w-32 text-right">Preço</TableHead>
                  <TableHead className="w-28 text-center">Estoque</TableHead>
                  <TableHead className="w-28 text-center">Status</TableHead>
                  <TableHead className="w-40">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProducts.map((prod) => (
                  <TableRow key={prod.id} className={prod.stock <= prod.minStock && prod.active ? "bg-yellow-50" : ""}>
                    <TableCell>
                      {prod.imageUrl && (
                        <img src={prod.imageUrl} alt={prod.name} className="h-12 w-12 rounded-lg object-cover" />
                      )}
                    </TableCell>
                    <TableCell>
                      <p className="font-medium text-gray-900">{prod.name}</p>
                      {prod.sku && <p className="text-xs text-gray-500">SKU: {prod.sku}</p>}
                      {prod.barcode && <p className="text-xs text-gray-400">Cód: {prod.barcode}</p>}
                    </TableCell>
                    <TableCell className="text-gray-500">{prod.category.name}</TableCell>
                    <TableCell className="text-right">
                      <p className="font-medium text-gray-900">{formatCurrency(Number(prod.price))}</p>
                      {prod.costPrice && <p className="text-xs text-gray-400">Custo: {formatCurrency(Number(prod.costPrice))}</p>}
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant={getStockBadge(prod).variant}>{prod.stock}</Badge>
                      {prod.stock <= prod.minStock && prod.active && <p className="text-xs text-yellow-600 mt-1">Mín: {prod.minStock}</p>}
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant={prod.active ? "success" : "secondary"}>{prod.active ? "Ativo" : "Inativo"}</Badge>
                      {prod.featured && <Badge variant="purple" className="mt-1">Destaque</Badge>}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu
                        trigger={<Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="h-4 w-4" /></Button>}
                        items={productActions(prod)}
                        onSelect={handleAction}
                        align="right"
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredProducts.map((prod) => (
              <Card key={prod.id} className={cn("overflow-hidden transition-shadow hover:shadow-lg", prod.stock <= prod.minStock && prod.active ? "border-yellow-200" : "")}>
                {prod.imageUrl && (
                  <img src={prod.imageUrl} alt={prod.name} className="w-full h-40 object-cover" />
                )}
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <Badge variant={prod.active ? "success" : "secondary"} className="mt-0.5">{prod.active ? "Ativo" : "Inativo"}</Badge>
                    {prod.featured && <Badge variant="purple">Destaque</Badge>}
                    {prod.stock <= prod.minStock && prod.active && <Badge variant="warning" className="mt-0.5"><AlertTriangle className="h-3 w-3 mr-1" /> Baixo</Badge>}
                  </div>
                  <h3 className="font-semibold text-gray-900 truncate mb-1">{prod.name}</h3>
                  <p className="text-sm text-gray-500 mb-2">{prod.category.name}</p>
                  {prod.sku && <p className="text-xs text-gray-400 mb-1">SKU: {prod.sku}</p>}
                  <div className="flex items-center justify-between pt-2 border-t border-gray-100">
                    <span className="text-lg font-bold text-gray-900">{formatCurrency(Number(prod.price))}</span>
                    <Badge variant={getStockBadge(prod).variant}>{prod.stock}</Badge>
                  </div>
                  <div className="flex gap-2 mt-3 pt-3 border-t border-gray-100">
                    <Button variant="outline" size="sm" className="flex-1" onClick={() => handleEdit(prod)}><Edit className="h-3 w-3 mr-1" /> Editar</Button>
                    <DropdownMenu
                      trigger={<Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="h-4 w-4" /></Button>}
                      items={productActions(prod)}
                      onSelect={handleAction}
                      align="right"
                    />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {showModal && (
        <Modal
          open={true}
          onClose={closeModal}
          title={editing ? `Editar Produto: ${editing.name}` : "Novo Produto"}
          size="lg"
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Input label="Nome *" name="name" value={form.name} onChange={handleChange} required placeholder="Nome do produto" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
                <textarea name="description" value={form.description} onChange={handleChange} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
              </div>
              <Input label="Preço de Venda *" name="price" type="number" step="0.01" min="0" value={form.price} onChange={handleChange} required />
              <Input label="Preço de Custo" name="costPrice" type="number" step="0.01" min="0" value={form.costPrice} onChange={handleChange} />
              <Input label="Estoque Atual *" name="stock" type="number" min="0" value={form.stock} onChange={handleChange} required />
              <Input label="Estoque Mínimo" name="minStock" type="number" min="0" value={form.minStock} onChange={handleChange} />
              <Input label="SKU" name="sku" value={form.sku} onChange={handleChange} placeholder="Código interno" />
              <Input label="Código de Barras" name="barcode" value={form.barcode} onChange={handleChange} placeholder="EAN/GTIN" />
              <Select
                label="Categoria *"
                name="categoryId"
                value={form.categoryId}
                onChange={handleChange}
                options={categories.map(c => ({ value: c.id, label: c.name }))}
                placeholder="Selecione a categoria"
                required
              />
              <Input label="Imagem (URL)" name="imageUrl" type="url" value={form.imageUrl} onChange={handleChange} placeholder="https://exemplo.com/imagem.jpg" />
              <div className="flex items-center gap-2">
                <input type="checkbox" name="active" checked={form.active} onChange={handleChange} id="active" className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
                <label htmlFor="active" className="text-sm text-gray-700">Produto Ativo</label>
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" name="featured" checked={form.featured} onChange={handleChange} id="featured" className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
                <label htmlFor="featured" className="text-sm text-gray-700">Produto em Destaque</label>
              </div>
            </div>
            <div className="flex justify-end gap-3 border-t pt-6">
              <Button type="button" variant="outline" onClick={closeModal}>Cancelar</Button>
              <Button type="submit" loading={submitting}>{submitting ? "Salvando..." : editing ? "Atualizar" : "Criar Produto"}</Button>
            </div>
          </form>
        </Modal>
      )}

      {confirmDelete && (
        <ConfirmDialog
          open={true}
          onClose={() => setConfirmDelete(null)}
          onConfirm={handleDelete}
          title="Excluir Produto"
          message={`Tem certeza que deseja excluir "${confirmDelete.name}"?`}
          confirmLabel="Excluir"
          variant="destructive"
        />
      )}
    </div>
  );
}