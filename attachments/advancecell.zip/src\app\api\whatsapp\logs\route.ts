import { NextRequest, NextResponse } from "next/server";
import { whatsappService } from "@/lib/whatsapp";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const limit = parseInt(searchParams.get("limit") || "50");
  const offset = parseInt(searchParams.get("offset") || "0");

  const [logs, stats] = await Promise.all([
    whatsappService.getLogs(limit, offset),
    whatsappService.getStats(),
  ]);

  return NextResponse.json({ logs, stats });
}