param(
    [string]$Nome = "projeto",
    [ValidateSet("7z","zip","rar")][string]$Formato = "zip",
    [string]$Saida = "."
)

$excluir = @("node_modules", ".next", ".git", "dist", "build", ".turbo", ".vercel", "coverage", "*.log", ".DS_Store", "Thumbs.db")

Write-Host "Limpando arquivos desnecessarios..." -ForegroundColor Yellow
foreach ($item in $excluir) {
    Get-ChildItem -Path . -Recurse -Force -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like $item } |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}

$tamanho = (Get-ChildItem -Recurse -Force -File | Measure-Object Length -Sum).Sum / 1MB
Write-Host "Tamanho apos limpeza: $([math]::Round($tamanho, 2)) MB" -ForegroundColor Cyan

$arquivo = "$Saida\$Nome.$Formato"
Write-Host "Compactando em $arquivo..." -ForegroundColor Yellow

switch ($Formato) {
    "7z" { & 7z a -t7z -mx=9 -m0=lzma2 -md=64m "$arquivo" .\* -xr!$excluir }
    "zip" { Compress-Archive -Path .\* -DestinationPath "$arquivo" -Force -CompressionLevel Optimal }
    "rar" { & rar a -r -m5 -md64m -ep1 "$arquivo" .\* -x$excluir }
}

if ($LASTEXITCODE -eq 0) {
    $final = (Get-Item "$arquivo").Length / 1MB
    Write-Host "Pronto! $arquivo ($([math]::Round($final, 2)) MB)" -ForegroundColor Green
} else {
    Write-Host "Erro ao compactar" -ForegroundColor Red
    exit 1
}