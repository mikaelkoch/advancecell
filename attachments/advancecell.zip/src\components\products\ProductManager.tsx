"use client";

import { Category, Product } from "@/lib/types";
import { Modal, ConfirmDialog } from "@/components/ui/Modal";
import { ChangeEvent, FormEvent, useState } from "react";
import API from "@/lib/api";

interface ProductManagerProps {
  categories: Category[];
  onDataChange: () => void;
}

export function ProductManager({ categories, onDataChange }: ProductManagerProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Product | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    name: "", description: "", price: "", costPrice: "", stock: "0", minStock: "5",
    sku: "", barcode: "", imageUrl: "", active: true, featured: false, categoryId: ""
  });

  const fetchData = async () => {
    try {
      const data = await API.products.list();
      setProducts(data);
    } catch (error) {
      console.error("Erro ao carregar produtos:", error);
      setProducts([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const payload = {
        name: form.name,
        description: form.description,
        price: parseFloat(form.price) || 0,
        costPrice: form.costPrice ? parseFloat(form.costPrice) : null,
        stock: parseInt(form.stock) || 0,
        minStock: parseInt(form.minStock) || 5,
        sku: form.sku || null,
        barcode: form.barcode || null,
        imageUrl: form.imageUrl || null,
        active: form.active,
        featured: form.featured,
        categoryId: form.categoryId,
      };
      if (editing) await API.products.update(editing.id, payload);
      else await API.products.create(payload);
      closeModal();
      onDataChange();
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    await API.products.delete(confirmDelete.id);
    setConfirmDelete(null);
    onDataChange();
  };

  const handleEdit = (prod: Product) => {
    setEditing(prod);
    setForm({
      name: prod.name,
      description: prod.description || "",
      price: prod.price.toString(),
      costPrice: prod.costPrice?.toString() || "",
      stock: prod.stock.toString(),
      minStock: prod.minStock.toString(),
      sku: prod.sku || "",
      barcode: prod.barcode || "",
      imageUrl: prod.imageUrl || "",
      active: prod.active,
      featured: prod.featured,
      categoryId: prod.categoryId,
    });
    setShowModal(true);
  };

  const handleNew = () => {
    setEditing(null);
    setForm({
      name: "", description: "", price: "", costPrice: "", stock: "0", minStock: "5",
      sku: "", barcode: "", imageUrl: "", active: true, featured: false, categoryId: categories[0]?.id || ""
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditing(null);
    setForm({
      name: "", description: "", price: "", costPrice: "", stock: "0", minStock: "5",
      sku: "", barcode: "", imageUrl: "", active: true, featured: false, categoryId: categories[0]?.id || ""
    });
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === "checkbox") setForm(prev => ({ ...prev, [name]: (e.target as HTMLInputElement).checked }));
    else setForm(prev => ({ ...prev, [name]: value }));
  };

  const getStockBadge = (prod: Product) => {
    if (prod.stock === 0) return "bg-red-100 text-red-800";
    if (prod.stock <= prod.minStock) return "bg-yellow-100 text-yellow-800";
    return "bg-green-100 text-green-800";
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  const lowStock = products.filter(p => p.stock <= p.minStock && p.active).length;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Produtos</h2>
        <div className="flex items-center gap-4">
          {lowStock > 0 && (
            <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">
              ⚠ {lowStock} com estoque baixo
            </span>
          )}
          <button onClick={handleNew} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">+ Novo Produto</button>
        </div>
      </div>

      {products.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl shadow-sm">
          <p className="text-gray-500 mb-4">Nenhum produto cadastrado</p>
          <button onClick={handleNew} className="bg-blue-600 text-white px-4 py-2 rounded-lg">Criar primeiro produto</button>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Produto</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Categoria</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Preço</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Estoque</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {products.map(prod => (
                <tr key={prod.id} className={`hover:bg-gray-50 ${prod.stock <= prod.minStock && prod.active ? "bg-yellow-50" : ""}`}>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      {prod.imageUrl && <img src={prod.imageUrl} alt={prod.name} className="w-10 h-10 rounded object-cover" />}
                      <div>
                        <p className="text-sm font-medium text-gray-900">{prod.name}</p>
                        {prod.sku && <p className="text-xs text-gray-500">SKU: {prod.sku}</p>}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">{prod.category.name}</td>
                  <td className="px-6 py-4 text-right text-sm font-medium text-gray-900">
                    R$ {Number(prod.price).toFixed(2).replace(".", ",")}
                    {prod.costPrice && <p className="text-xs text-gray-400">Custo: R$ {Number(prod.costPrice).toFixed(2).replace(".", ",")}</p>}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStockBadge(prod)}`}>{prod.stock}</span>
                    {prod.stock <= prod.minStock && prod.active && <p className="text-xs text-yellow-600 mt-1">Mín: {prod.minStock}</p>}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${prod.active ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}`}>
                      {prod.active ? "Ativo" : "Inativo"}
                    </span>
                    {prod.featured && <span className="ml-1 px-2 py-1 text-xs font-medium bg-purple-100 text-purple-800 rounded-full">Destaque</span>}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button onClick={() => handleEdit(prod)} className="text-blue-600 hover:text-blue-900 text-sm font-medium">Editar</button>
                      <button onClick={() => setConfirmDelete(prod)} className="text-red-600 hover:text-red-900 text-sm font-medium">Excluir</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <Modal title={editing ? "Editar Produto" : "Novo Produto"} onClose={closeModal} onSubmit={handleSubmit} submitting={submitting}>
          <div className="space-y-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Nome *</label>
              <input type="text" name="name" value={form.name} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
              <textarea name="description" value={form.description} onChange={handleChange} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Preço de Venda *</label>
              <input type="number" step="0.01" min="0" name="price" value={form.price} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Preço de Custo</label>
              <input type="number" step="0.01" min="0" name="costPrice" value={form.costPrice} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Estoque Atual *</label>
              <input type="number" min="0" name="stock" value={form.stock} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Estoque Mínimo</label>
              <input type="number" min="0" name="minStock" value={form.minStock} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">SKU</label>
              <input type="text" name="sku" value={form.sku} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Código de Barras</label>
              <input type="text" name="barcode" value={form.barcode} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Categoria *</label>
              <select name="categoryId" value={form.categoryId} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                <option value="">Selecione</option>
                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Imagem (URL)</label>
              <input type="url" name="imageUrl" value={form.imageUrl} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" name="active" checked={form.active} onChange={handleChange} id="active" className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
              <label htmlFor="active" className="text-sm text-gray-700">Ativo</label>
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" name="featured" checked={form.featured} onChange={handleChange} id="featured" className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
              <label htmlFor="featured" className="text-sm text-gray-700">Destaque</label>
            </div>
          </div>
        </Modal>
      )}

      {confirmDelete && (
        <ConfirmDialog open={true} onClose={() => setConfirmDelete(null)} onConfirm={handleDelete} title="Excluir produto" message={`Excluir "${confirmDelete.name}"?`} />
      )}
    </div>
  );
}