"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

interface TabsProps {
  value: string;
  onValueChange: (value: string) => void;
  children: React.ReactNode;
  className?: string;
  variant?: "default" | "underline" | "pills";
}

interface TabsListProps {
  children: React.ReactNode;
  className?: string;
}

interface TabsTriggerProps {
  value: string;
  children: React.ReactNode;
  disabled?: boolean;
  className?: string;
  icon?: React.ReactNode;
}

interface TabsContentProps {
  value: string;
  children: React.ReactNode;
  className?: string;
}

export function Tabs({ value, onValueChange, children, className, variant = "default" }: TabsProps) {
  return (
    <div className={cn("w-full", className)}>
      {React.Children.map(children, (child) => {
        if (React.isValidElement(child) && (child.type as any).displayName === "TabsList") {
          return React.cloneElement(child, { value, onValueChange, variant });
        }
        if (React.isValidElement(child) && (child.type as any).displayName === "TabsContent") {
          return React.cloneElement(child, { value });
        }
        return child;
      })}
    </div>
  );
}

export function TabsList({ children, className, value, onValueChange, variant }: TabsListProps & { value: string; onValueChange: (v: string) => void; variant: string }) {
  const baseStyles = "inline-flex items-center justify-center gap-1 rounded-lg";
  const variants = {
    default: "bg-gray-100 p-1",
    underline: "bg-transparent p-0 border-b border-gray-200",
    pills: "bg-transparent p-1 gap-2",
  };

  return (
    <div className={cn(baseStyles, variants[variant as keyof typeof variants], className)} role="tablist">
      {React.Children.map(children, (child) => {
        if (React.isValidElement(child)) {
          return React.cloneElement(child, { value, onValueChange, variant });
        }
        return child;
      })}
    </div>
  );
}
TabsList.displayName = "TabsList";

export function TabsTrigger({ value, children, disabled, className, icon, onValueChange, variant }: TabsTriggerProps & { onValueChange: (v: string) => void; variant: string }) {
  const isActive = value === (onValueChange as any)?.currentValue;
  const triggerRef = React.useRef<HTMLButtonElement>(null);
  
  const variants = {
    default: "data-[state=active]:bg-white data-[state=active]:shadow-sm",
    underline: "data-[state=active]:border-b-2 data-[state=active]:border-blue-600 data-[state=active]:text-blue-600",
    pills: "data-[state=active]:bg-blue-600 data-[state=active]:text-white",
  };

  const sizes = {
    default: "px-4 py-2 text-sm",
    underline: "px-4 py-3 text-sm",
    pills: "px-4 py-2 text-sm",
  };

  const handleClick = () => {
    if (!disabled) onValueChange(value);
  };

  return (
    <button
      ref={triggerRef}
      role="tab"
      aria-selected={isActive}
      aria-disabled={disabled}
      onClick={handleClick}
      disabled={disabled}
      className={cn(
        "relative inline-flex items-center justify-center gap-2 font-medium transition-all duration-200",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
        "disabled:pointer-events-none disabled:opacity-50",
        "rounded-lg",
        variants[variant as keyof typeof variants],
        sizes[variant as keyof typeof sizes],
        className
      )}
    >
      {icon && <span className="h-4 w-4" aria-hidden="true">{icon}</span>}
      {children}
    </button>
  );
}
TabsTrigger.displayName = "TabsTrigger";

export function TabsContent({ value, children, className }: TabsContentProps & { value: string }) {
  const isActive = value === (children as any)?.props?.value;
  // We need to get the parent Tabs value - this is a simplified version
  return (
    <div role="tabpanel" className={cn("mt-4", className)}>
      {children}
    </div>
  );
}
TabsContent.displayName = "TabsContent";

// Better implementation with context
const TabsContext = React.createContext<{ value: string; onValueChange: (v: string) => void; variant: string } | null>(null);

export function TabsProvider({ value, onValueChange, children, variant = "default" }: TabsProps) {
  return (
    <TabsContext.Provider value={{ value, onValueChange, variant }}>
      <div className="w-full">{children}</div>
    </TabsContext.Provider>
  );
}

export function TabsListContext({ children, className }: TabsListProps) {
  const context = React.useContext(TabsContext);
  if (!context) throw new Error("TabsList must be used within TabsProvider");
  
  const { value, onValueChange, variant } = context;
  const baseStyles = "inline-flex items-center justify-center gap-1 rounded-lg";
  const variants = {
    default: "bg-gray-100 p-1",
    underline: "bg-transparent p-0 border-b border-gray-200",
    pills: "bg-transparent p-1 gap-2",
  };

  return (
    <div className={cn(baseStyles, variants[variant], className)} role="tablist">
      {React.Children.map(children, (child) => {
        if (React.isValidElement(child)) {
          return React.cloneElement(child, { value, onValueChange, variant });
        }
        return child;
      })}
    </div>
  );
}
TabsListContext.displayName = "TabsList";

export function TabsTriggerContext({ value, children, disabled, className, icon }: TabsTriggerProps) {
  const context = React.useContext(TabsContext);
  if (!context) throw new Error("TabsTrigger must be used within TabsProvider");
  
  const { value: currentValue, onValueChange, variant } = context;
  const isActive = currentValue === value;
  
  const variants = {
    default: "data-[state=active]:bg-white data-[state=active]:shadow-sm",
    underline: "data-[state=active]:border-b-2 data-[state=active]:border-blue-600 data-[state=active]:text-blue-600",
    pills: "data-[state=active]:bg-blue-600 data-[state=active]:text-white",
  };

  const sizes = {
    default: "px-4 py-2 text-sm",
    underline: "px-4 py-3 text-sm",
    pills: "px-4 py-2 text-sm",
  };

  return (
    <button
      role="tab"
      aria-selected={isActive}
      aria-disabled={disabled}
      onClick={() => !disabled && onValueChange(value)}
      disabled={disabled}
      className={cn(
        "relative inline-flex items-center justify-center gap-2 font-medium transition-all duration-200",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
        "disabled:pointer-events-none disabled:opacity-50",
        "rounded-lg",
        variants[variant],
        sizes[variant],
        className
      )}
      data-state={isActive ? "active" : "inactive"}
    >
      {icon && <span className="h-4 w-4" aria-hidden="true">{icon}</span>}
      {children}
    </button>
  );
}
TabsTriggerContext.displayName = "TabsTrigger";

export function TabsContentContext({ value, children, className }: TabsContentProps) {
  const context = React.useContext(TabsContext);
  if (!context) throw new Error("TabsContent must be used within TabsProvider");
  
  const isActive = context.value === value;
  
  if (!isActive) return null;
  
  return <div role="tabpanel" className={cn("mt-4 animate-in fade-in-0 duration-200", className)}>{children}</div>;
}
TabsContentContext.displayName = "TabsContent";