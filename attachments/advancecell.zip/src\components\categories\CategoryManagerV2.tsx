"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { Plus, Search, Edit, Trash2, Image, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Modal } from "@/components/ui/Modal";
import { ConfirmDialog } from "@/components/ui/Modal";
import { Badge } from "@/components/ui/Badge";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/Table";
import { DropdownMenu } from "@/components/ui/Dropdown";
import { Category } from "@/lib/types";
import API from "@/lib/api";
import { ChangeEvent, FormEvent, useState } from "react";

interface CategoryManagerV2Props {
  onDataChange: () => void;
}

export function CategoryManagerV2({ onDataChange }: CategoryManagerV2Props) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Category | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Category | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [search, setSearch] = useState("");

  const [form, setForm] = useState({ name: "", description: "", imageUrl: "" });

  const fetchData = async () => {
    setLoading(true);
    try {
      const data = await API.categories.list();
      setCategories(data);
    } catch (error) {
      console.error("Erro ao carregar categorias:", error);
      setCategories([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      if (editing) await API.categories.update(editing.id, form);
      else await API.categories.create(form);
      closeModal();
      onDataChange();
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    await API.categories.delete(confirmDelete.id);
    setConfirmDelete(null);
    onDataChange();
  };

  const handleEdit = (cat: Category) => {
    setEditing(cat);
    setForm({ name: cat.name, description: cat.description || "", imageUrl: cat.imageUrl || "" });
    setShowModal(true);
  };

  const handleNew = () => {
    setEditing(null);
    setForm({ name: "", description: "", imageUrl: "" });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditing(null);
    setForm({ name: "", description: "", imageUrl: "" });
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const categoryActions = (cat: Category) => [
    { label: "Editar", value: `edit-${cat.id}`, icon: <Edit className="h-4 w-4" /> },
    { label: "Excluir", value: `delete-${cat.id}`, icon: <Trash2 className="h-4 w-4" />, danger: true },
  ];

  const handleAction = (value: string) => {
    const [action, id] = value.split("-");
    const cat = categories.find(c => c.id === id);
    if (!cat) return;
    
    switch (action) {
      case "edit": handleEdit(cat); break;
      case "delete": setConfirmDelete(cat); break;
    }
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Categorias</h1>
          <p className="text-gray-500 mt-1">Organize seus produtos por categorias.</p>
        </div>
        <Button onClick={handleNew}><Plus className="h-4 w-4 mr-2" /> Nova Categoria</Button>
      </div>

      <div className="card bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-col sm:flex-row gap-4 mb-4">
          <div className="flex-1">
            <Input placeholder="Buscar categorias..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
        </div>

        {categories.length === 0 ? (
          <div className="text-center py-12">
            <div className="h-12 w-12 mx-auto bg-gray-100 rounded-full flex items-center justify-center mb-3">
              <Image className="h-6 w-6 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-1">Nenhuma categoria cadastrada</h3>
            <p className="text-gray-500 mb-4">Crie categorias para organizar seus produtos</p>
            <Button onClick={handleNew}><Plus className="h-4 w-4 mr-2" /> Criar primeira categoria</Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-16"></TableHead>
                  <TableHead>Nome</TableHead>
                  <TableHead>Slug</TableHead>
                  <TableHead>Produtos</TableHead>
                  <TableHead>Criado em</TableHead>
                  <TableHead className="w-40">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {categories.map((cat) => (
                  <TableRow key={cat.id}>
                    <TableCell>
                      {cat.imageUrl ? (
                        <img src={cat.imageUrl} alt={cat.name} className="h-12 w-12 rounded-lg object-cover" />
                      ) : (
                        <div className="h-12 w-12 rounded-lg bg-gray-100 flex items-center justify-center">
                          <Image className="h-6 w-6 text-gray-400" />
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <p className="font-medium text-gray-900">{cat.name}</p>
                      {cat.description && <p className="text-xs text-gray-500 truncate max-w-xs">{cat.description}</p>}
                    </TableCell>
                    <TableCell className="font-mono text-sm text-gray-500">{cat.slug}</TableCell>
                    <TableCell className="text-center">
                      <Badge variant="default">{cat._count.products}</Badge>
                    </TableCell>
                    <TableCell className="text-gray-500 text-sm">{format(new Date(cat.createdAt), "dd/MM/yyyy")}</TableCell>
                    <TableCell>
                      <DropdownMenu
                        trigger={<Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="h-4 w-4" /></Button>}
                        items={categoryActions(cat)}
                        onSelect={handleAction}
                        align="right"
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      {showModal && (
        <Modal
          open={true}
          onClose={closeModal}
          title={editing ? `Editar Categoria: ${editing.name}` : "Nova Categoria"}
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <Input label="Nome *" name="name" value={form.name} onChange={handleChange} required placeholder="Nome da categoria" />
              <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
              <textarea name="description" value={form.description} onChange={handleChange} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
              <Input label="Imagem (URL)" name="imageUrl" type="url" value={form.imageUrl} onChange={handleChange} placeholder="https://exemplo.com/imagem.jpg" />
              {form.imageUrl && (
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-1">Pré-visualização</p>
                  <img src={form.imageUrl} alt="Preview" className="h-32 w-32 rounded-lg object-cover border border-gray-200" />
                </div>
              )}
            </div>
            <div className="flex justify-end gap-3 border-t pt-6">
              <Button type="button" variant="outline" onClick={closeModal}>Cancelar</Button>
              <Button type="submit" loading={submitting}>{submitting ? "Salvando..." : editing ? "Atualizar" : "Criar Categoria"}</Button>
            </div>
          </form>
        </Modal>
      )}

      {confirmDelete && (
        <ConfirmDialog
          open={true}
          onClose={() => setConfirmDelete(null)}
          onConfirm={handleDelete}
          title="Excluir Categoria"
          message={`Tem certeza que deseja excluir "${confirmDelete.name}"? Os produtos vinculados ficarão sem categoria.`}
          confirmLabel="Excluir"
          variant="destructive"
        />
      )}
    </div>
  );
}