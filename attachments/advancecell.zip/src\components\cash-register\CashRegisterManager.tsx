"use client";

import { CashRegister, CashMovement, CashRegisterStatus, CashMovementType, MOVEMENT_TYPE_LABELS, MOVEMENT_TYPE_COLORS } from "@/lib/types";
import { Modal, ConfirmDialog } from "@/components/ui/Modal";
import { ChangeEvent, FormEvent, useState, useEffect } from "react";
import API from "@/lib/api";
import { format } from "date-fns";

const formatCurrency = (v: number) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export function CashRegisterManager({ onDataChange }: { onDataChange: () => void }) {
  const [registers, setRegisters] = useState<CashRegister[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [filterStatus, setFilterStatus] = useState<CashRegisterStatus | "">("");
  const [showModal, setShowModal] = useState(false);
  const [viewingRegister, setViewingRegister] = useState<CashRegister | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [openForm, setOpenForm] = useState({ openingAmount: "", notes: "" });
  const [movementForm, setMovementForm] = useState({
    type: "SALE" as CashMovementType,
    amount: "",
    description: "",
    paymentMethod: "",
  });
  const [addingMovement, setAddingMovement] = useState(false);
  const [closeForm, setCloseForm] = useState({ closingAmount: "", notes: "" });

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await API.cashRegister.list(filterStatus || undefined, page);
      setRegisters(res.data);
      setTotalPages(res.totalPages);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [page, filterStatus]);

  const handleOpenRegister = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await API.cashRegister.open(parseFloat(openForm.openingAmount), openForm.notes, "Sistema");
      setShowModal(false);
      setOpenForm({ openingAmount: "", notes: "" });
      onDataChange();
    } finally {
      setSubmitting(false);
    }
  };

  const handleCloseRegister = async (e: FormEvent) => {
    e.preventDefault();
    if (!viewingRegister) return;
    setSubmitting(true);
    try {
      await API.cashRegister.close(viewingRegister.id, parseFloat(closeForm.closingAmount), closeForm.notes, "Sistema");
      setViewingRegister(null);
      setCloseForm({ closingAmount: "", notes: "" });
      onDataChange();
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddMovement = async (e: FormEvent) => {
    e.preventDefault();
    if (!viewingRegister) return;
    setAddingMovement(true);
    try {
      await API.cashMovements.create({
        cashRegisterId: viewingRegister.id,
        type: movementForm.type,
        amount: parseFloat(movementForm.amount),
        description: movementForm.description,
        paymentMethod: movementForm.paymentMethod || undefined,
        createdBy: "Sistema",
      });
      setMovementForm({ type: "SALE", amount: "", description: "", paymentMethod: "" });
      onDataChange();
    } finally {
      setAddingMovement(false);
    }
  };

  const viewRegister = async (register: CashRegister) => {
    const detail = await API.cashRegister.get(register.id);
    setViewingRegister(detail);
  };

  const canAddMovement = viewingRegister?.status === "OPEN";

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  const openRegister = registers.find(r => r.status === "OPEN");

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Controle de Caixa</h2>
        <div className="flex items-center gap-4">
          <select value={filterStatus} onChange={e => { setFilterStatus(e.target.value as CashRegisterStatus | ""); setPage(1); }} className="px-3 py-2 border border-gray-300 rounded-lg">
            <option value="">Todos</option>
            <option value="OPEN">Aberto</option>
            <option value="CLOSED">Fechado</option>
          </select>
          {!openRegister && (
            <button onClick={() => setShowModal(true)} className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">+ Abrir Caixa</button>
          )}
        </div>
      </div>

      {openRegister && (
        <div className="mb-6 bg-green-50 border border-green-200 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <div>
                <p className="font-medium text-green-800">Caixa Aberto - Sessão #{openRegister.sessionNumber}</p>
                <p className="text-sm text-green-600">Aberto por {openRegister.openedBy} em {format(new Date(openRegister.openedAt), "dd/MM/yyyy HH:mm")}</p>
              </div>
            </div>
            <button onClick={() => viewRegister(openRegister)} className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">Gerenciar</button>
          </div>
        </div>
      )}

      {registers.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl shadow-sm">
          <p className="text-gray-500 mb-4">Nenhuma sessão de caixa</p>
          {!openRegister && <button onClick={() => setShowModal(true)} className="bg-green-600 text-white px-4 py-2 rounded-lg">Abrir primeiro caixa</button>}
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sessão</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Abertura</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fechamento</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Abertura</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Fechamento</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Diferença</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {registers.map(reg => (
                <tr key={reg.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm font-mono text-gray-900">#{reg.sessionNumber.toString().padStart(6, "0")}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${reg.status === "OPEN" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}`}>
                      {reg.status === "OPEN" ? "Aberto" : "Fechado"}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">{format(new Date(reg.openedAt), "dd/MM/yyyy HH:mm")}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{reg.closedAt ? format(new Date(reg.closedAt), "dd/MM/yyyy HH:mm") : "-"}</td>
                  <td className="px-6 py-4 text-right text-sm text-gray-900">{formatCurrency(reg.openingAmount)}</td>
                  <td className="px-6 py-4 text-right text-sm text-gray-900">{reg.closingAmount ? formatCurrency(reg.closingAmount) : "-"}</td>
                  <td className="px-6 py-4 text-right">
                    {reg.difference !== null && (
                      <span className={`text-sm font-medium ${reg.difference >= 0 ? "text-green-600" : "text-red-600"}`}>
                        {reg.difference >= 0 ? "+" : ""}{formatCurrency(reg.difference)}
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button onClick={() => viewRegister(reg)} className="text-blue-600 hover:text-blue-900 text-sm font-medium">Ver</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {totalPages > 1 && (
            <div className="px-6 py-4 border-t flex justify-center gap-2">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-100 disabled:opacity-50">Anterior</button>
              <span className="px-3 py-1 text-sm text-gray-600">{page} / {totalPages}</span>
              <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-100 disabled:opacity-50">Próximo</button>
            </div>
          )}
        </div>
      )}

      {showModal && (
        <Modal title="Abrir Caixa" onClose={() => setShowModal(false)} onSubmit={handleOpenRegister} submitting={submitting}>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Valor de Abertura *</label>
              <input type="number" step="0.01" min="0" name="openingAmount" value={openForm.openingAmount} onChange={e => setOpenForm(prev => ({ ...prev, openingAmount: e.target.value }))} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500" placeholder="0,00" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Observações</label>
              <textarea name="notes" value={openForm.notes} onChange={e => setOpenForm(prev => ({ ...prev, notes: e.target.value }))} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500" />
            </div>
          </div>
        </Modal>
      )}

      {viewingRegister && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b sticky top-0 bg-white flex justify-between items-center">
              <h2 className="text-xl font-bold">Caixa #{viewingRegister.sessionNumber.toString().padStart(6, "0")}</h2>
              <button onClick={() => setViewingRegister(null)} className="text-gray-400 hover:text-gray-600 text-2xl leading-none">×</button>
            </div>
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-green-50 p-4 rounded-lg"><p className="text-sm text-green-700">Abertura</p><p className="text-2xl font-bold text-green-900">{formatCurrency(viewingRegister.openingAmount)}</p></div>
                <div className="bg-blue-50 p-4 rounded-lg"><p className="text-sm text-blue-700">Vendas Líquidas</p><p className="text-2xl font-bold text-blue-900">{formatCurrency(viewingRegister.summary?.netSales || 0)}</p></div>
                <div className="bg-purple-50 p-4 rounded-lg"><p className="text-sm text-purple-700">Suprimentos</p><p className="text-2xl font-bold text-purple-900">{formatCurrency(viewingRegister.summary?.suprimentos || 0)}</p></div>
                <div className="bg-orange-50 p-4 rounded-lg"><p className="text-sm text-orange-700">Sangrias</p><p className="text-2xl font-bold text-orange-900">{formatCurrency(viewingRegister.summary?.sangrias || 0)}</p></div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg"><p className="text-sm text-gray-700">Despesas</p><p className="text-2xl font-bold text-gray-900">{formatCurrency(viewingRegister.summary?.expenses || 0)}</p></div>
                <div className="bg-indigo-50 p-4 rounded-lg"><p className="text-sm text-indigo-700">Esperado no Fechamento</p><p className="text-2xl font-bold text-indigo-900">{formatCurrency(viewingRegister.summary?.expectedClosing || 0)}</p></div>
                <div className={viewingRegister.closingAmount ? "bg-emerald-50 p-4 rounded-lg" : "bg-yellow-50 p-4 rounded-lg"}>
                  <p className="text-sm text-gray-700">Fechamento Real</p>
                  <p className="text-2xl font-bold">{viewingRegister.closingAmount ? formatCurrency(viewingRegister.closingAmount) : "Aberto"}</p>
                </div>
                <div className={`p-4 rounded-lg ${(viewingRegister.difference ?? 0) >= 0 ? "bg-green-50" : "bg-red-50"}`}>
                  <p className="text-sm text-gray-700">Diferença</p>
                  <p className={`text-2xl font-bold ${(viewingRegister.difference ?? 0) >= 0 ? "text-green-900" : "text-red-900"}`}>
                    {(viewingRegister.difference ?? 0) >= 0 ? "+" : ""}{formatCurrency(viewingRegister.difference ?? 0)}
                  </p>
                </div>
              </div>

              {viewingRegister.summary?.salesByMethod && Object.keys(viewingRegister.summary.salesByMethod).length > 0 && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Vendas por Forma de Pagamento</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {Object.entries(viewingRegister.summary.salesByMethod).map(([method, value]) => (
                      <div key={method} className="bg-white p-3 rounded border">
                        <p className="text-xs text-gray-500">{method}</p>
                        <p className="font-medium">{formatCurrency(value)}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {viewingRegister.status === "OPEN" && (
                <>
                  <div className="border-t pt-4">
                    <h4 className="font-medium mb-3">Movimentações</h4>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {viewingRegister.movements?.map((mov: CashMovement, i: number) => (
                        <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                          <div className="flex items-center gap-3">
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${MOVEMENT_TYPE_COLORS[mov.type]}`}>
                              {MOVEMENT_TYPE_LABELS[mov.type]}
                            </span>
                            <div>
                              <p className="text-sm font-medium">{mov.description}</p>
                              {mov.paymentMethod && <p className="text-xs text-gray-500">{mov.paymentMethod}</p>}
                              {mov.serviceOrder && <p className="text-xs text-gray-400">OS #{mov.serviceOrder.orderNumber} - {mov.serviceOrder.client.name}</p>}
                            </div>
                          </div>
                          <span className={`text-sm font-medium ${["SALE", "OPENING", "SUPRIMENTO"].includes(mov.type) ? "text-green-600" : "text-red-600"}`}>
                            {["SALE", "OPENING", "SUPRIMENTO"].includes(mov.type) ? "+" : "-"}{formatCurrency(mov.amount)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <h4 className="font-medium mb-3">Nova Movimentação</h4>
                    <form onSubmit={handleAddMovement} className="space-y-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Tipo</label>
                        <select value={movementForm.type} onChange={e => setMovementForm(prev => ({ ...prev, type: e.target.value as CashMovementType }))} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                          <option value="SALE">Venda</option>
                          <option value="REFUND">Estorno</option>
                          <option value="SANGRIA">Sangria</option>
                          <option value="SUPRIMENTO">Suprimento</option>
                          <option value="EXPENSE">Despesa</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Valor *</label>
                        <input type="number" step="0.01" min="0.01" value={movementForm.amount} onChange={e => setMovementForm(prev => ({ ...prev, amount: e.target.value }))} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Forma de Pagamento</label>
                        <select value={movementForm.paymentMethod} onChange={e => setMovementForm(prev => ({ ...prev, paymentMethod: e.target.value }))} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                          <option value="">Selecione</option>
                          <option value="DINHEIRO">Dinheiro</option>
                          <option value="CARTAO_CREDITO">Cartão Crédito</option>
                          <option value="CARTAO_DEBITO">Cartão Débito</option>
                          <option value="PIX">PIX</option>
                          <option value="TRANSFERENCIA">Transferência</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
                        <input type="text" value={movementForm.description} onChange={e => setMovementForm(prev => ({ ...prev, description: e.target.value }))} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="Ex: Sangria para depósito" />
                      </div>
                      <div className="md:col-span-2 flex justify-end">
                        <button type="submit" disabled={addingMovement} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50">
                          {addingMovement ? "Adicionando..." : "Adicionar Movimentação"}
                        </button>
                      </div>
                    </form>
                  </div>

                  <div className="border-t pt-4 bg-green-50 rounded-lg p-4">
                    <h4 className="font-medium mb-3">Fechar Caixa</h4>
                    <p className="text-sm text-gray-600 mb-3">Valor esperado: <strong>{formatCurrency(viewingRegister.summary?.expectedClosing || 0)}</strong></p>
                    <form onSubmit={handleCloseRegister} className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Valor Contado no Caixa *</label>
                        <input type="number" step="0.01" min="0" name="closingAmount" value={closeForm.closingAmount} onChange={e => setCloseForm(prev => ({ ...prev, closingAmount: e.target.value }))} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500" placeholder="0,00" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Observações</label>
                        <textarea name="notes" value={closeForm.notes} onChange={e => setCloseForm(prev => ({ ...prev, notes: e.target.value }))} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500" />
                      </div>
                      <button type="submit" disabled={submitting} className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 disabled:opacity-50">
                        {submitting ? "Fechando..." : "Fechar Caixa"}
                      </button>
                    </form>
                  </div>
                </>
              )}

              {viewingRegister.status === "CLOSED" && (
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <p className="text-gray-600">Este caixa foi fechado por {viewingRegister.closedBy} em {viewingRegister.closedAt ? format(new Date(viewingRegister.closedAt), "dd/MM/yyyy HH:mm") : ""}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}