"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { Plus, Search, Send, MessageSquare, Settings, CheckCircle, AlertCircle, Clock, MoreHorizontal, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Select } from "@/components/ui/Select";
import { Modal } from "@/components/ui/Modal";
import { Badge } from "@/components/ui/Badge";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/Table";
import { DropdownMenu } from "@/components/ui/Dropdown";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/Tabs";
import { WhatsAppSettings, WhatsAppLog, WhatsAppProvider, WHATSAPP_PROVIDERS, MESSAGE_TYPE_LABELS, MESSAGE_STATUS_COLORS } from "@/lib/types";
import API from "@/lib/api";
import { ChangeEvent, FormEvent, useState, useEffect } from "react";

interface WhatsAppManagerV2Props {
  onDataChange: () => void;
}

export function WhatsAppManagerV2({ onDataChange }: WhatsAppManagerV2Props) {
  const [settings, setSettings] = useState<WhatsAppSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testPhone, setTestPhone] = useState("");
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [logs, setLogs] = useState<WhatsAppLog[]>([]);
  const [logsLoading, setLogsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<"config" | "logs" | "test">("config");

  const [form, setForm] = useState({
    provider: "MOCK" as WhatsAppProvider,
    phoneNumber: "",
    accountSid: "",
    authToken: "",
    apiUrl: "",
    apiKey: "",
    templatePrefix: "advancecell",
    active: false,
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const data = await API.whatsapp.getSettings();
      setSettings(data);
      setForm({
        provider: data.provider as WhatsAppProvider,
        phoneNumber: data.phoneNumber,
        accountSid: data.accountSid === "***" ? "" : data.accountSid,
        authToken: "",
        apiUrl: data.apiUrl,
        apiKey: data.hasApiKey ? "" : "",
        templatePrefix: data.templatePrefix || "advancecell",
        active: data.active,
      });
    } catch (error) {
      console.error("Erro ao carregar configurações:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchLogs = async () => {
    setLogsLoading(true);
    try {
      const res = await API.whatsapp.getLogs(50);
      setLogs(res.logs);
    } catch (error) {
      console.error("Erro ao carregar logs:", error);
    } finally {
      setLogsLoading(false);
    }
  };

  useEffect(() => { fetchData(); fetchLogs(); }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await API.whatsapp.saveSettings(form);
      fetchData();
      onDataChange();
    } finally {
      setSaving(false);
    }
  };

  const handleTestSend = async (e: FormEvent) => {
    e.preventDefault();
    if (!testPhone) return;
    
    const result = await API.whatsapp.send({
      type: "CUSTOM",
      to: testPhone,
      message: `🧪 *Teste Advancecell*\n\nEsta é uma mensagem de teste das configurações de WhatsApp.\n\nEnviado em: ${new Date().toLocaleString("pt-BR")}`,
    });
    
    setTestResult(result);
    fetchLogs();
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === "checkbox") {
      setForm(prev => ({ ...prev, [name]: (e.target as HTMLInputElement).checked }));
    } else {
      setForm(prev => ({ ...prev, [name]: value }));
    }
  };

  const currentProvider = WHATSAPP_PROVIDERS.find(p => p.value === form.provider);
  const requiredFields = currentProvider?.fields || [];

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="config"><Settings className="h-4 w-4 mr-2" /> Configurações</TabsTrigger>
          <TabsTrigger value="test"><MessageSquare className="h-4 w-4 mr-2" /> Testar Envio</TabsTrigger>
          <TabsTrigger value="logs"><MessageSquare className="h-4 w-4 mr-2" /> Logs</TabsTrigger>
        </TabsList>

        <TabsContent value="config">
          <form onSubmit={handleSubmit} className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Configurações do WhatsApp</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Select
                    label="Provedor"
                    name="provider"
                    value={form.provider}
                    onChange={handleChange}
                    options={WHATSAPP_PROVIDERS.map(p => ({ value: p.value, label: p.label }))}
                  />
                  <Input
                    label="Número do WhatsApp *"
                    name="phoneNumber"
                    type="tel"
                    value={form.phoneNumber}
                    onChange={handleChange}
                    required
                    placeholder="5511999999999"
                  />
                  <p className="text-xs text-gray-500 md:col-span-2">Formato: 55 + DDD + número (ex: 5511999999999)</p>
                </div>

                {requiredFields.includes("accountSid") && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-6">
                    <Input label="Account SID" name="accountSid" value={form.accountSid} onChange={handleChange} />
                    <Input label="Auth Token" name="authToken" type="password" value={form.authToken} onChange={handleChange} />
                  </div>
                )}

                {requiredFields.includes("apiUrl") && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-6">
                    <Input label="API URL" name="apiUrl" type="url" value={form.apiUrl} onChange={handleChange} placeholder="https://api.exemplo.com" />
                    <Input label="API Key" name="apiKey" type="password" value={form.apiKey} onChange={handleChange} />
                  </div>
                )}

                {requiredFields.includes("apiKey") && !requiredFields.includes("apiUrl") && (
                  <div className="border-t pt-6">
                    <Input label="API Key" name="apiKey" type="password" value={form.apiKey} onChange={handleChange} />
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t pt-6">
                  <Input label="Prefixo Template" name="templatePrefix" value={form.templatePrefix} onChange={handleChange} />
                  <div className="flex items-center gap-2">
                    <input type="checkbox" name="active" checked={form.active} onChange={handleChange} id="active" className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
                    <label htmlFor="active" className="text-sm text-gray-700">Ativar WhatsApp</label>
                  </div>
                </div>

                <div className="flex justify-end gap-3 border-t pt-6">
                  <Button type="submit" loading={saving}>{saving ? "Salvando..." : "Salvar Configurações"}</Button>
                </div>
              </CardContent>
            </Card>

            {form.provider !== "MOCK" && form.active && (
              <Card className="border-yellow-200 bg-yellow-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><AlertTriangle className="h-5 w-5 text-yellow-600" /> Atenção</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-yellow-800">Você está usando o provedor <strong>{currentProvider?.label}</strong> com a integração ativa. Certifique-se de que as credenciais estão corretas.</p>
                </CardContent>
              </Card>
            )}
          </form>
        </TabsContent>

        <TabsContent value="test">
          <Card>
            <CardHeader>
              <CardTitle>Testar Envio de Mensagem</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleTestSend} className="space-y-4">
                <Input label="Número para Teste" type="tel" value={testPhone} onChange={e => setTestPhone(e.target.value)} placeholder="5511999999999" />
                {testResult && (
                  <div className={cn("p-4 rounded-lg", testResult.success ? "bg-green-50 text-green-800 border border-green-200" : "bg-red-50 text-red-800 border border-red-200")}>
                    <div className="flex items-center gap-2">
                      {testResult.success ? <CheckCircle className="h-5 w-5" /> : <AlertCircle className="h-5 w-5" />}
                      <span>{testResult.success ? "✅ Mensagem enviada com sucesso!" : `❌ Erro: ${testResult.message}`}</span>
                    </div>
                  </div>
                )}
                <Button type="submit" className="bg-green-600 hover:bg-green-700">
                  <Send className="h-4 w-4 mr-2" /> Enviar Mensagem de Teste
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Logs de Envio</CardTitle>
              <Button variant="outline" size="sm" onClick={fetchLogs} loading={logsLoading}><RotateCcw className="h-4 w-4 mr-2" /> Atualizar</Button>
            </CardHeader>
            <CardContent>
              {logsLoading ? (
                <div className="flex items-center justify-center h-32"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>
              ) : logs.length === 0 ? (
                <div className="text-center py-12">
                  <MessageSquare className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                  <p className="text-gray-500">Nenhum log encontrado</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Data/Hora</TableHead>
                        <TableHead>Tipo</TableHead>
                        <TableHead>Destinatário</TableHead>
                        <TableHead className="w-28 text-center">Status</TableHead>
                        <TableHead>OS/Cliente</TableHead>
                        <TableHead>Erro</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {logs.map(log => (
                        <TableRow key={log.id}>
                          <TableCell className="text-sm text-gray-500">{format(new Date(log.createdAt), "dd/MM HH:mm:ss")}</TableCell>
                          <TableCell>
                            <Badge variant="default">{MESSAGE_TYPE_LABELS[log.type]}</Badge>
                          </TableCell>
                          <TableCell className="font-mono text-sm">{log.to}</TableCell>
                          <TableCell className="text-center">
                            <Badge variant={log.status === "SENT" ? "success" : log.status === "FAILED" ? "destructive" : "warning"}>
                              {log.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm text-gray-500">
                            {log.serviceOrder && `OS #${log.serviceOrder.orderNumber}`}
                            {log.client && ` - ${log.client.name}`}
                          </TableCell>
                          <TableCell className="text-sm text-red-500 truncate max-w-xs">{log.errorMessage || "-"}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}