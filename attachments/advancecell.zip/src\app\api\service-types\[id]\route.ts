import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const type = await prisma.serviceType.findUnique({ where: { id } });
  if (!type) {
    return NextResponse.json({ error: "Tipo de serviço não encontrado" }, { status: 404 });
  }
  return NextResponse.json(type);
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await request.json();
  const type = await prisma.serviceType.update({
    where: { id },
    data: {
      name: body.name,
      description: body.description,
      price: body.price,
      durationMin: body.durationMin,
      active: body.active,
    },
  });
  return NextResponse.json(type);
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  await prisma.serviceType.delete({ where: { id } });
  return NextResponse.json({ success: true });
}