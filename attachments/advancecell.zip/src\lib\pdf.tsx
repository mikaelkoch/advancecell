import { Page, View, Text, StyleSheet, pdf } from "@react-pdf/renderer";
import { ServiceOrder, Client, ServiceOrderItem, ServiceOrderService, Product, ServiceType } from "@/lib/types";
import { format, formatCurrency } from "@/lib/utils";

interface ServiceOrderPDFProps {
  order: ServiceOrder & {
    client: Client;
    items: (ServiceOrderItem & { product: Product })[];
    services: (ServiceOrderService & { serviceType: ServiceType })[];
  };
}

const styles = StyleSheet.create({
  page: { flexDirection: "column", padding: 30, fontFamily: "Helvetica" },
  header: { flexDirection: "row", justifyContent: "space-between", marginBottom: 20, borderBottom: "2 solid #1e40af", paddingBottom: 15 },
  logo: { fontSize: 24, fontWeight: "bold", color: "#1e40af" },
  subtitle: { fontSize: 10, color: "#64748b", marginTop: 2 },
  osNumber: { fontSize: 14, fontWeight: "bold", color: "#1e40af", textAlign: "right" },
  osDate: { fontSize: 9, color: "#64748b", textAlign: "right", marginTop: 2 },
  section: { marginBottom: 15 },
  sectionTitle: { fontSize: 11, fontWeight: "bold", color: "#1e40af", textTransform: "uppercase", marginBottom: 8, borderBottom: "1 solid #e2e8f0", paddingBottom: 3 },
  row: { flexDirection: "row", marginBottom: 4 },
  label: { fontSize: 9, fontWeight: "bold", color: "#475569", width: 100 },
  value: { fontSize: 9, color: "#1e293b" },
  tableHeader: { flexDirection: "row", backgroundColor: "#1e40af", padding: 6, marginTop: 10 },
  tableRow: { flexDirection: "row", padding: 6, borderBottom: "0.5 solid #e2e8f0" },
  tableRowAlt: { flexDirection: "row", padding: 6, backgroundColor: "#f8fafc", borderBottom: "0.5 solid #e2e8f0" },
  cell: { fontSize: 8, color: "#ffffff", fontWeight: "bold" },
  cellData: { fontSize: 8, color: "#1e293b" },
  col1: { width: 120 },
  col2: { width: 50, textAlign: "center" },
  col3: { width: 70, textAlign: "right" },
  col4: { width: 70, textAlign: "right" },
  colService1: { width: 150 },
  colService2: { width: 50, textAlign: "center" },
  colService3: { width: 80, textAlign: "right" },
  colService4: { width: 80, textAlign: "right" },
  totalsBox: { marginTop: 15, padding: 10, backgroundColor: "#f1f5f9", borderRadius: 4 },
  totalsRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 4 },
  totalsLabel: { fontSize: 9, color: "#475569" },
  totalsValue: { fontSize: 9, fontWeight: "bold", color: "#1e293b" },
  totalFinal: { fontSize: 11, fontWeight: "bold", color: "#1e40af", borderTop: "1 solid #cbd5e1", paddingTop: 6, marginTop: 4 },
  footer: { marginTop: 30, paddingTop: 15, borderTop: "1 solid #e2e8f0", fontSize: 8, color: "#64748b", textAlign: "center" },
  warranty: { marginTop: 10, padding: 8, backgroundColor: "#fef3c7", borderRadius: 4, border: "1 solid #fcd34d" },
  warrantyText: { fontSize: 8, color: "#92400e" },
  statusBadge: { padding: 2, paddingHorizontal: 6, borderRadius: 3, fontSize: 7, fontWeight: "bold" },
});

const STATUS_COLORS_PDF: Record<string, { bg: string; text: string }> = {
  RECEIVED: { bg: "#dbeafe", text: "#1e40af" },
  DIAGNOSING: { bg: "#ede9fe", text: "#6d28d9" },
  WAITING_APPROVAL: { bg: "#fef3c7", text: "#b45309" },
  IN_REPAIR: { bg: "#ffedd5", text: "#c2410c" },
  READY: { bg: "#dcfce7", text: "#166534" },
  DELIVERED: { bg: "#f1f5f9", text: "#475569" },
  CANCELLED: { bg: "#fee2e2", text: "#991b1b" },
};

const STATUS_LABELS_PDF: Record<string, string> = {
  RECEIVED: "RECEBIDO",
  DIAGNOSING: "DIAGNOSTICANDO",
  WAITING_APPROVAL: "AGUARD. APROV.",
  IN_REPAIR: "EM REPARO",
  READY: "PRONTO",
  DELIVERED: "ENTREGUE",
  CANCELLED: "CANCELADA",
};

function ServiceOrderPDFDocument({ order }: ServiceOrderPDFProps) {
  const statusColor = STATUS_COLORS_PDF[order.status] || { bg: "#e2e8f0", text: "#475569" };
  const statusLabel = STATUS_LABELS_PDF[order.status] || order.status;

  return (
    <Page size="A4" style={styles.page}>
      <View style={styles.header}>
        <View>
          <Text style={styles.logo}>ADVANCECELL</Text>
          <Text style={styles.subtitle}>Assistência Técnica & Acessórios</Text>
          <Text style={styles.subtitle}>CNPJ: 00.000.000/0001-00 | Tel: (00) 0000-0000</Text>
        </View>
        <View>
          <Text style={styles.osNumber}>ORDEM DE SERVIÇO #{order.orderNumber.toString().padStart(6, "0")}</Text>
          <Text style={styles.osDate}>Data: {format(new Date(order.createdAt), "dd/MM/yyyy HH:mm")}</Text>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Dados do Cliente</Text>
        <View style={styles.row}>
          <Text style={styles.label}>Nome:</Text>
          <Text style={styles.value}>{order.client.name}</Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.label}>Telefone:</Text>
          <Text style={styles.value}>{order.client.phone}</Text>
        </View>
        {order.client.whatsapp && (
          <View style={styles.row}>
            <Text style={styles.label}>WhatsApp:</Text>
            <Text style={styles.value}>{order.client.whatsapp}</Text>
          </View>
        )}
        {order.client.email && (
          <View style={styles.row}>
            <Text style={styles.label}>E-mail:</Text>
            <Text style={styles.value}>{order.client.email}</Text>
          </View>
        )}
        {order.client.cpfCnpj && (
          <View style={styles.row}>
            <Text style={styles.label}>CPF/CNPJ:</Text>
            <Text style={styles.value}>{order.client.cpfCnpj}</Text>
          </View>
        )}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Aparelho</Text>
        <View style={styles.row}>
          <Text style={styles.label}>Marca:</Text>
          <Text style={styles.value}>{order.deviceBrand}</Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.label}>Modelo:</Text>
          <Text style={styles.value}>{order.deviceModel}</Text>
        </View>
        {order.deviceSerial && (
          <View style={styles.row}>
            <Text style={styles.label}>Nº Série:</Text>
            <Text style={styles.value}>{order.deviceSerial}</Text>
          </View>
        )}
        {order.deviceImei && (
          <View style={styles.row}>
            <Text style={styles.label}>IMEI:</Text>
            <Text style={styles.value}>{order.deviceImei}</Text>
          </View>
        )}
        <View style={styles.row}>
          <Text style={styles.label}>Defeito:</Text>
          <Text style={styles.value}>{order.defectDesc}</Text>
        </View>
        {order.accessories && (
          <View style={styles.row}>
            <Text style={styles.label}>Acessórios:</Text>
            <Text style={styles.value}>{order.accessories}</Text>
          </View>
        )}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Status</Text>
        <View style={styles.row}>
          <Text style={styles.label}>Situação:</Text>
          <Text style={[styles.value, styles.statusBadge, { backgroundColor: statusColor.bg, color: statusColor.text }]}>
            {statusLabel}
          </Text>
        </View>
        {order.technician && (
          <View style={styles.row}>
            <Text style={styles.label}>Técnico:</Text>
            <Text style={styles.value}>{order.technician}</Text>
          </View>
        )}
        {order.estimatedDate && (
          <View style={styles.row}>
            <Text style={styles.label}>Previsão:</Text>
            <Text style={styles.value}>{format(new Date(order.estimatedDate), "dd/MM/yyyy")}</Text>
          </View>
        )}
        {order.diagnosis && (
          <View style={styles.row}>
            <Text style={styles.label}>Diagnóstico:</Text>
            <Text style={styles.value}>{order.diagnosis}</Text>
          </View>
        )}
        {order.solution && (
          <View style={styles.row}>
            <Text style={styles.label}>Solução:</Text>
            <Text style={styles.value}>{order.solution}</Text>
          </View>
        )}
      </View>

      {order.items.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Peças / Produtos</Text>
          <View style={styles.tableHeader}>
            <Text style={[styles.cell, styles.col1]}>Produto</Text>
            <Text style={[styles.cell, styles.col2]}>Qtd</Text>
            <Text style={[styles.cell, styles.col3]}>Vl. Unit.</Text>
            <Text style={[styles.cell, styles.col4]}>Total</Text>
          </View>
          {order.items.map((item, idx) => (
            <View key={idx} style={[styles.tableRow, idx % 2 === 1 ? styles.tableRowAlt : {}]}>
              <Text style={[styles.cellData, styles.col1]}>{item.product.name}</Text>
              <Text style={[styles.cellData, styles.col2]}>{item.quantity}</Text>
              <Text style={[styles.cellData, styles.col3]}>{formatCurrency(Number(item.unitPrice))}</Text>
              <Text style={[styles.cellData, styles.col4]}>{formatCurrency(Number(item.totalPrice))}</Text>
            </View>
          ))}
        </View>
      )}

      {order.services.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Serviços</Text>
          <View style={styles.tableHeader}>
            <Text style={[styles.cell, styles.colService1]}>Serviço</Text>
            <Text style={[styles.cell, styles.colService2]}>Qtd</Text>
            <Text style={[styles.cell, styles.colService3]}>Vl. Unit.</Text>
            <Text style={[styles.cell, styles.colService4]}>Total</Text>
          </View>
          {order.services.map((svc, idx) => (
            <View key={idx} style={[styles.tableRow, idx % 2 === 1 ? styles.tableRowAlt : {}]}>
              <Text style={[styles.cellData, styles.colService1]}>{svc.serviceType.name}{svc.notes && ` - ${svc.notes}`}</Text>
              <Text style={[styles.cellData, styles.colService2]}>{svc.quantity}</Text>
              <Text style={[styles.cellData, styles.colService3]}>{formatCurrency(Number(svc.unitPrice))}</Text>
              <Text style={[styles.cellData, styles.colService4]}>{formatCurrency(Number(svc.totalPrice))}</Text>
            </View>
          ))}
        </View>
      )}

      <View style={styles.totalsBox}>
        <View style={styles.totalsRow}>
          <Text style={styles.totalsLabel}>Peças / Produtos:</Text>
          <Text style={styles.totalsValue}>{formatCurrency(Number(order.partsPrice))}</Text>
        </View>
        <View style={styles.totalsRow}>
          <Text style={styles.totalsLabel}>Mão de Obra / Serviços:</Text>
          <Text style={styles.totalsValue}>{formatCurrency(Number(order.laborPrice))}</Text>
        </View>
        {Number(order.discount) > 0 && (
          <View style={styles.totalsRow}>
            <Text style={styles.totalsLabel}>Desconto:</Text>
            <Text style={{ ...styles.totalsValue, color: "#dc2626" }}>- {formatCurrency(Number(order.discount))}</Text>
          </View>
        )}
        <View style={styles.totalsRow}>
          <Text style={styles.totalsLabel}>Subtotal:</Text>
          <Text style={styles.totalsValue}>{formatCurrency(Number(order.partsPrice) + Number(order.laborPrice) - Number(order.discount))}</Text>
        </View>
        <View style={styles.totalFinal}>
          <Text style={styles.totalsLabel}>TOTAL:</Text>
          <Text style={styles.totalsValue}>{formatCurrency(Number(order.totalPrice))}</Text>
        </View>
        <View style={styles.totalsRow}>
          <Text style={styles.totalsLabel}>Pago:</Text>
          <Text style={styles.totalsValue}>{formatCurrency(Number(order.paidAmount))}</Text>
        </View>
        <View style={styles.totalsRow}>
          <Text style={styles.totalsLabel}>A Pagar:</Text>
          <Text style={{ ...styles.totalsValue, color: Number(order.totalPrice) > Number(order.paidAmount) ? "#dc2626" : "#166534" }}>
            {formatCurrency(Number(order.totalPrice) - Number(order.paidAmount))}
          </Text>
        </View>
        {order.paymentMethod && (
          <View style={styles.totalsRow}>
            <Text style={styles.totalsLabel}>Forma Pagamento:</Text>
            <Text style={styles.totalsValue}>{order.paymentMethod}</Text>
          </View>
        )}
      </View>

      <View style={styles.warranty}>
        <Text style={styles.warrantyText}>
          <Text style={{ fontWeight: "bold" }}>GARANTIA: </Text>
          {order.warrantyDays} dias a partir da entrega. Peças e mão de obra. Não cobre danos por mau uso, queda, umidade ou violação do lacre.
        </Text>
      </View>

      <View style={styles.footer}>
        <Text>Advancecell - Assistência Técnica & Acessórios</Text>
        <Text>Documento gerado em {format(new Date(), "dd/MM/yyyy HH:mm")} | OS #{order.orderNumber.toString().padStart(6, "0")}</Text>
        <Text style={{ marginTop: 8 }}>Assinatura do Cliente: _________________________________________________  Data: ___/___/______</Text>
      </View>
    </Page>
  );
}

export async function generateServiceOrderPDF(order: ServiceOrderPDFProps["order"]): Promise<Blob> {
  const doc = await pdf(<ServiceOrderPDFDocument order={order} />).toBlob();
  return doc;
}