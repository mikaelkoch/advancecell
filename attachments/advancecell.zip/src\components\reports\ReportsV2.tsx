"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { Plus, Search, Download, Calendar, FileText, BarChart, TrendingUp, Package, Users, DollarSign, Settings, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Select } from "@/components/ui/Select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/Table";
import { Badge } from "@/components/ui/Badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/Tabs";
import { format, subDays, formatCurrency } from "@/lib/utils";
import API from "@/lib/api";
import { ChangeEvent, FormEvent, useState, useEffect } from "react";

type ReportType = "sales" | "products" | "services" | "clients" | "technician" | "payment" | "abc";

const REPORT_TYPES: { id: ReportType; label: string; icon: React.ReactNode }[] = [
  { id: "sales", label: "Vendas", icon: <DollarSign className="h-4 w-4" /> },
  { id: "products", label: "Produtos", icon: <Package className="h-4 w-4" /> },
  { id: "services", label: "Serviços", icon: <Settings className="h-4 w-4" /> },
  { id: "clients", label: "Clientes", icon: <Users className="h-4 w-4" /> },
  { id: "technician", label: "Técnicos", icon: <Settings className="h-4 w-4" /> },
  { id: "payment", label: "Pagamentos", icon: <DollarSign className="h-4 w-4" /> },
  { id: "abc", label: "Curva ABC", icon: <BarChart className="h-4 w-4" /> },
];

export function ReportsV2() {
  const [activeReport, setActiveReport] = useState<ReportType>("sales");
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [startDate, setStartDate] = useState(format(subDays(new Date(), 30), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [groupBy, setGroupBy] = useState<"day" | "month">("day");

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await API.reports.get(activeReport, startDate, endDate, groupBy);
      setData(res);
    } catch (error) {
      console.error("Erro ao carregar relatório:", error);
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [activeReport, startDate, endDate, groupBy]);

  const exportCSV = () => {
    if (!data?.data?.length) return;
    const headers = Object.keys(data.data[0] || {}).join(",");
    const rows = data.data.map((row: any) => Object.values(row).map(v => `"${v}"`).join(",")).join("\n");
    const csv = headers + "\n" + rows;
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `relatorio-${activeReport}-${startDate}-a-${endDate}.csv`;
    link.click();
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Relatórios</h1>
          <p className="text-gray-500 mt-1">Analise o desempenho da sua assistência técnica.</p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <Input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-auto" />
          <Input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="w-auto" />
          {activeReport === "sales" && (
            <Select
              value={groupBy}
              onChange={e => setGroupBy(e.target.value as "day" | "month")}
              options={[{ value: "day", label: "Por Dia" }, { value: "month", label: "Por Mês" }]}
              className="w-auto"
            />
          )}
          <Button onClick={exportCSV} disabled={!data?.data?.length} variant="outline">
            <Download className="h-4 w-4 mr-2" /> Exportar CSV
          </Button>
        </div>
      </div>

      <Tabs value={activeReport} onValueChange={setActiveReport} className="w-full">
        <TabsList className="grid w-full grid-cols-7">
          {REPORT_TYPES.map(t => (
            <TabsTrigger key={t.id} value={t.id} className="gap-2">
              {t.icon} {t.label}
            </TabsTrigger>
          ))}
        </TabsList>

        {REPORT_TYPES.map(t => (
          <TabsContent key={t.id} value={t.id}>
            {data?.summary && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                {Object.entries(data.summary).map(([key, value]) => (
                  <Card key={key}>
                    <CardContent className="p-4">
                      <p className="text-sm font-medium text-gray-500">{key.replace(/([A-Z])/g, " $1").replace(/^./, c => c.toUpperCase())}</p>
                      <p className="mt-1 text-2xl font-bold text-gray-900">{typeof value === "number" ? formatCurrency(value) : value}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {data?.data && data.data.length > 0 && (
              <Card>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          {getColumns(activeReport).map(col => (
                            <TableHead key={col.key}>{col.label}</TableHead>
                          ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {data.data.map((row: any, i: number) => (
                          <TableRow key={row.productId || row.serviceTypeId || row.clientId || row.technician || row.method || row.date || i}>
                            {getColumns(activeReport).map(col => (
                              <TableCell key={col.key}>
                                {col.format ? col.format(row[col.key], row) : row[col.key]}
                              </TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
              )}

              {data?.data && data.data.length === 0 && (
                <Card>
                  <CardContent className="py-12 text-center">
                    <FileText className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                    <p className="text-gray-500">Nenhum dado encontrado para o período selecionado</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          ))}
      </Tabs>
    </div>
  );
}

function getColumns(type: ReportType) {
  switch (type) {
    case "sales":
      return [
        { key: "date", label: "Data" },
        { key: "orders", label: "OS" },
        { key: "revenue", label: "Faturamento", format: (v: number) => formatCurrency(v) },
        { key: "partsRevenue", label: "Peças", format: (v: number) => formatCurrency(v) },
        { key: "laborRevenue", label: "Mão de Obra", format: (v: number) => formatCurrency(v) },
        { key: "paid", label: "Recebido", format: (v: number) => formatCurrency(v) },
        { key: "pending", label: "A Receber", format: (v: number) => formatCurrency(v) },
      ];
    case "products":
      return [
        { key: "name", label: "Produto" },
        { key: "category", label: "Categoria" },
        { key: "sku", label: "SKU" },
        { key: "quantity", label: "Qtd" },
        { key: "revenue", label: "Receita", format: (v: number) => formatCurrency(v) },
        { key: "cost", label: "Custo", format: (v: number) => formatCurrency(v) },
        { key: "margin", label: "Margem", format: (v: any, row: any) => formatCurrency(row.revenue - row.cost) },
      ];
    case "services":
      return [
        { key: "name", label: "Serviço" },
        { key: "quantity", label: "Qtd" },
        { key: "revenue", label: "Receita", format: (v: number) => formatCurrency(v) },
        { key: "avgPrice", label: "Preço Médio", format: (v: number) => formatCurrency(v) },
      ];
    case "clients":
      return [
        { key: "name", label: "Cliente" },
        { key: "phone", label: "Telefone" },
        { key: "orders", label: "OS" },
        { key: "totalSpent", label: "Total Gasto", format: (v: number) => formatCurrency(v) },
        { key: "lastOrder", label: "Última OS", format: (d: string) => format(new Date(d), "dd/MM/yyyy") },
      ];
    case "technician":
      return [
        { key: "technician", label: "Técnico" },
        { key: "orders", label: "OS" },
        { key: "revenue", label: "Faturamento", format: (v: number) => formatCurrency(v) },
        { key: "partsRevenue", label: "Peças", format: (v: number) => formatCurrency(v) },
        { key: "laborRevenue", label: "Mão de Obra", format: (v: number) => formatCurrency(v) },
      ];
    case "payment":
      return [
        { key: "method", label: "Forma" },
        { key: "count", label: "Qtd" },
        { key: "paid", label: "Recebido", format: (v: number) => formatCurrency(v) },
        { key: "total", label: "Total OS", format: (v: number) => formatCurrency(v) },
      ];
    case "abc":
      return [
        { key: "name", label: "Produto" },
        { key: "revenue", label: "Receita", format: (v: number) => formatCurrency(v) },
        { key: "percent", label: "% Acumulado", format: (v: number) => `${v}%` },
        { key: "curve", label: "Curva", format: (v: string) => (
          <Badge variant={v === "A" ? "success" : v === "B" ? "warning" : "secondary"}>{v}</Badge>
        ) },
      ];
  }
}