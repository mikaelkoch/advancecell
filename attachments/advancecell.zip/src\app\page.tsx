"use client";

import { useState, useEffect } from "react";
import { Category, Product, Client, ServiceType } from "@/lib/types";
import { CategoryManagerV2 } from "@/components/categories/CategoryManagerV2";
import { ProductManagerV2 } from "@/components/products/ProductManagerV2";
import { ClientManagerV2 } from "@/components/clients/ClientManagerV2";
import { ServiceTypeManagerV2 } from "@/components/service-types/ServiceTypeManagerV2";
import { ServiceOrderManagerV2 } from "@/components/service-orders/ServiceOrderManagerV2";
import { DashboardV2 } from "@/components/dashboard/DashboardV2";
import { ReportsV2 } from "@/components/reports/ReportsV2";
import { CashRegisterManagerV2 } from "@/components/cash-register/CashRegisterManagerV2";
import { WhatsAppManagerV2 } from "@/components/whatsapp/WhatsAppManagerV2";
import { MainLayout } from "@/components/layout/MainLayout";
import API from "@/lib/api";

type Tab = "dashboard" | "reports" | "cashRegister" | "whatsapp" | "serviceOrders" | "products" | "categories" | "clients" | "serviceTypes";

export default function Home() {
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [serviceTypes, setServiceTypes] = useState<ServiceType[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);

  const fetchAll = async () => {
    try {
      const [cats, prods, cls, svcTypes] = await Promise.all([
        API.categories.list(),
        API.products.list(),
        API.clients.list(),
        API.serviceTypes.list(),
      ]);
      setCategories(cats);
      setProducts(prods);
      setClients(cls);
      setServiceTypes(svcTypes);
    } catch (error) {
      console.error("Erro ao carregar dados iniciais:", error);
      setCategories([]);
      setProducts([]);
      setClients([]);
      setServiceTypes([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchAll(); }, []);

  const handleDataChange = () => {
    setRefreshKey(k => k + 1);
    fetchAll();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-600 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <MainLayout>
      <div className="mb-6">
        <div className="flex flex-wrap gap-2" role="tablist">
          {[
            { id: "dashboard", label: "Dashboard" },
            { id: "reports", label: "Relatórios" },
            { id: "cashRegister", label: "Caixa" },
            { id: "whatsapp", label: "WhatsApp" },
            { id: "serviceOrders", label: "Ordens de Serviço" },
            { id: "products", label: "Produtos" },
            { id: "categories", label: "Categorias" },
            { id: "clients", label: "Clientes" },
            { id: "serviceTypes", label: "Tipos de Serviço" },
          ].map((tab) => (
            <button
              key={tab.id}
              role="tab"
              aria-selected={activeTab === tab.id}
              onClick={() => setActiveTab(tab.id as Tab)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 whitespace-nowrap ${
                activeTab === tab.id
                  ? "bg-blue-600 text-white shadow-sm"
                  : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {activeTab === "dashboard" && <DashboardV2 />}
      {activeTab === "reports" && <ReportsV2 />}
      {activeTab === "cashRegister" && <CashRegisterManagerV2 onDataChange={handleDataChange} />}
      {activeTab === "whatsapp" && <WhatsAppManagerV2 onDataChange={handleDataChange} />}
      {activeTab === "categories" && <CategoryManagerV2 key={refreshKey} onDataChange={handleDataChange} />}
      {activeTab === "products" && <ProductManagerV2 key={refreshKey} categories={categories} onDataChange={handleDataChange} />}
      {activeTab === "clients" && <ClientManagerV2 key={refreshKey} onDataChange={handleDataChange} />}
      {activeTab === "serviceTypes" && <ServiceTypeManagerV2 key={refreshKey} onDataChange={handleDataChange} />}
      {activeTab === "serviceOrders" && (
        <ServiceOrderManagerV2
          key={refreshKey}
          clients={clients}
          products={products}
          serviceTypes={serviceTypes}
          onDataChange={handleDataChange}
        />
      )}
    </MainLayout>
  );
}