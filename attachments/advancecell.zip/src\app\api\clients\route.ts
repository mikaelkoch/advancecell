import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const search = searchParams.get("search");

  const where = search ? {
    OR: [
      { name: { contains: search, mode: "insensitive" } },
      { phone: { contains: search } },
      { email: { contains: search, mode: "insensitive" } },
      { cpfCnpj: { contains: search } },
    ],
  } : {};

  const clients = await prisma.client.findMany({
    where,
    include: { _count: { select: { serviceOrders: true } } },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json(clients);
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const client = await prisma.client.create({
    data: {
      name: body.name,
      email: body.email || null,
      phone: body.phone,
      whatsapp: body.whatsapp || null,
      cpfCnpj: body.cpfCnpj || null,
      address: body.address || null,
      neighborhood: body.neighborhood || null,
      city: body.city || null,
      state: body.state || null,
      zipCode: body.zipCode || null,
      notes: body.notes || null,
    },
  });
  return NextResponse.json(client, { status: 201 });
}