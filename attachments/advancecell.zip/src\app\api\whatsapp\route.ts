import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { WhatsAppProvider } from "@prisma/client";

export async function GET() {
  const settings = await prisma.whatsAppSettings.findFirst();
  if (!settings) {
    return NextResponse.json({
      provider: "MOCK",
      phoneNumber: "",
      active: false,
    });
  }
  
  return NextResponse.json({
    id: settings.id,
    provider: settings.provider,
    phoneNumber: settings.phoneNumber,
    active: settings.active,
    accountSid: settings.accountSid ? "***" : "",
    hasAuthToken: !!settings.authToken,
    apiUrl: settings.apiUrl || "",
    hasApiKey: !!settings.apiKey,
    templatePrefix: settings.templatePrefix,
  });
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const { provider, phoneNumber, accountSid, authToken, apiUrl, apiKey, templatePrefix, active } = body;

  if (!phoneNumber) {
    return NextResponse.json({ error: "Número de telefone obrigatório" }, { status: 400 });
  }

  const existing = await prisma.whatsAppSettings.findFirst();
  
  const data = {
    provider: provider as WhatsAppProvider || "MOCK",
    phoneNumber,
    accountSid,
    authToken,
    apiUrl,
    apiKey,
    templatePrefix: templatePrefix || "advancecell",
    active: active || false,
  };

  let settings;
  if (existing) {
    settings = await prisma.whatsAppSettings.update({
      where: { id: existing.id },
      data,
    });
  } else {
    settings = await prisma.whatsAppSettings.create({ data });
  }

  return NextResponse.json({ success: true, id: settings.id });
}