import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { ServiceOrderStatus } from "@prisma/client";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status");
  const clientId = searchParams.get("clientId");
  const search = searchParams.get("search");

  const where: Record<string, unknown> = {};
  if (status) where.status = status;
  if (clientId) where.clientId = clientId;
  if (search) {
    where.OR = [
      { orderNumber: { equals: parseInt(search) || 0 } },
      { client: { name: { contains: search, mode: "insensitive" } } },
      { deviceModel: { contains: search, mode: "insensitive" } },
      { deviceSerial: { contains: search, mode: "insensitive" } },
    ];
  }

  const orders = await prisma.serviceOrder.findMany({
    where,
    include: {
      client: true,
      items: { include: { product: true } },
      services: { include: { serviceType: true } },
    },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json(orders);
}

export async function POST(request: NextRequest) {
  const body = await request.json();

  const client = await prisma.client.findUnique({ where: { id: body.clientId } });
  if (!client) {
    return NextResponse.json({ error: "Cliente não encontrado" }, { status: 400 });
  }

  const partsPrice = body.items?.reduce((sum: number, item: { quantity: number; unitPrice: number }) =>
    sum + item.quantity * Number(item.unitPrice), 0) || 0;

  const laborPrice = body.services?.reduce((sum: number, svc: { quantity: number; unitPrice: number }) =>
    sum + svc.quantity * Number(svc.unitPrice), 0) || 0;

  const discount = Number(body.discount) || 0;
  const totalPrice = partsPrice + laborPrice - discount;

  const order = await prisma.serviceOrder.create({
    data: {
      clientId: body.clientId,
      deviceBrand: body.deviceBrand,
      deviceModel: body.deviceModel,
      deviceSerial: body.deviceSerial,
      deviceImei: body.deviceImei,
      defectDesc: body.defectDesc,
      accessories: body.accessories,
      diagnosis: body.diagnosis,
      solution: body.solution,
      technician: body.technician,
      warrantyDays: body.warrantyDays || 90,
      laborPrice,
      partsPrice,
      discount,
      totalPrice,
      paidAmount: Number(body.paidAmount) || 0,
      paymentMethod: body.paymentMethod,
      notes: body.notes,
      estimatedDate: body.estimatedDate ? new Date(body.estimatedDate) : null,
      items: body.items ? {
        create: body.items.map((item: { productId: string; quantity: number; unitPrice: number }) => ({
          productId: item.productId,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          totalPrice: item.quantity * item.unitPrice,
        })),
      } : undefined,
      services: body.services ? {
        create: body.services.map((svc: { serviceTypeId: string; quantity: number; unitPrice: number; notes?: string }) => ({
          serviceTypeId: svc.serviceTypeId,
          quantity: svc.quantity,
          unitPrice: svc.unitPrice,
          totalPrice: svc.quantity * svc.unitPrice,
          notes: svc.notes,
        })),
      } : undefined,
    },
    include: {
      client: true,
      items: { include: { product: true } },
      services: { include: { serviceType: true } },
    },
  });

  return NextResponse.json(order, { status: 201 });
}