import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { ServiceOrderStatus } from "@prisma/client";

const STATUS_FLOW: Record<ServiceOrderStatus, ServiceOrderStatus[]> = {
  RECEIVED: ["DIAGNOSING", "CANCELLED"],
  DIAGNOSING: ["WAITING_APPROVAL", "IN_REPAIR", "CANCELLED"],
  WAITING_APPROVAL: ["IN_REPAIR", "CANCELLED", "DIAGNOSING"],
  IN_REPAIR: ["READY", "WAITING_APPROVAL", "CANCELLED"],
  READY: ["DELIVERED", "IN_REPAIR", "CANCELLED"],
  DELIVERED: [],
  CANCELLED: [],
};

function canTransition(current: ServiceOrderStatus, next: ServiceOrderStatus): boolean {
  return STATUS_FLOW[current]?.includes(next) ?? false;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const order = await prisma.serviceOrder.findUnique({
    where: { id },
    include: {
      client: true,
      items: { include: { product: true } },
      services: { include: { serviceType: true } },
    },
  });
  if (!order) {
    return NextResponse.json({ error: "Ordem de serviço não encontrada" }, { status: 404 });
  }
  return NextResponse.json(order);
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await request.json();

  const existing = await prisma.serviceOrder.findUnique({
    where: { id },
    include: { items: true, services: true },
  });
  if (!existing) {
    return NextResponse.json({ error: "Ordem de serviço não encontrada" }, { status: 404 });
  }

  const data: Record<string, unknown> = {};
  const now = new Date();

  if (body.status && body.status !== existing.status) {
    if (!canTransition(existing.status, body.status as ServiceOrderStatus)) {
      return NextResponse.json(
        { error: `Transição inválida: ${existing.status} → ${body.status}` },
        { status: 400 }
      );
    }
    data.status = body.status;
    if (body.status === "DIAGNOSING" && !existing.startedAt) data.startedAt = now;
    if (body.status === "READY" && !existing.finishedAt) data.finishedAt = now;
    if (body.status === "DELIVERED" && !existing.deliveredAt) data.deliveredAt = now;
  }

  ["deviceBrand", "deviceModel", "deviceSerial", "deviceImei", "defectDesc", "accessories",
   "diagnosis", "solution", "technician", "warrantyDays", "notes", "paymentMethod"].forEach(field => {
    if (body[field] !== undefined) data[field] = body[field];
  });

  if (body.estimatedDate !== undefined) {
    data.estimatedDate = body.estimatedDate ? new Date(body.estimatedDate) : null;
  }

  if (body.items) {
    await prisma.serviceOrderItem.deleteMany({ where: { serviceOrderId: id } });
    data.items = {
      create: body.items.map((item: { productId: string; quantity: number; unitPrice: number }) => ({
        productId: item.productId,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        totalPrice: item.quantity * item.unitPrice,
      })),
    };
  }

  if (body.services) {
    await prisma.serviceOrderService.deleteMany({ where: { serviceOrderId: id } });
    data.services = {
      create: body.services.map((svc: { serviceTypeId: string; quantity: number; unitPrice: number; notes?: string }) => ({
        serviceTypeId: svc.serviceTypeId,
        quantity: svc.quantity,
        unitPrice: svc.unitPrice,
        totalPrice: svc.quantity * svc.unitPrice,
        notes: svc.notes,
      })),
    };
  }

  if (body.items || body.services) {
    const itemsPrice = body.items?.reduce((sum: number, item: { quantity: number; unitPrice: number }) =>
      sum + item.quantity * Number(item.unitPrice), 0) || existing.items.reduce((s, i) => s + Number(i.totalPrice), 0);
    const servicesPrice = body.services?.reduce((sum: number, svc: { quantity: number; unitPrice: number }) =>
      sum + svc.quantity * Number(svc.unitPrice), 0) || existing.services.reduce((s, svc) => s + Number(svc.totalPrice), 0);
    const discount = Number(body.discount) ?? Number(existing.discount);
    data.partsPrice = itemsPrice;
    data.laborPrice = servicesPrice;
    data.totalPrice = itemsPrice + servicesPrice - discount;
  }

  if (body.paidAmount !== undefined) data.paidAmount = body.paidAmount;
  if (body.discount !== undefined) {
    const itemsPrice = Number(data.partsPrice ?? existing.partsPrice);
    const servicesPrice = Number(data.laborPrice ?? existing.laborPrice);
    data.totalPrice = itemsPrice + servicesPrice - Number(body.discount);
    data.discount = body.discount;
  }

  const order = await prisma.serviceOrder.update({
    where: { id },
    data,
    include: {
      client: true,
      items: { include: { product: true } },
      services: { include: { serviceType: true } },
    },
  });

  return NextResponse.json(order);
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  await prisma.serviceOrder.delete({ where: { id } });
  return NextResponse.json({ success: true });
}