"use client";

import { ServiceType } from "@/lib/types";
import { Modal, ConfirmDialog } from "@/components/ui/Modal";
import { ChangeEvent, FormEvent, useState } from "react";
import API from "@/lib/api";

export function ServiceTypeManager({ onDataChange }: { onDataChange: () => void }) {
  const [types, setTypes] = useState<ServiceType[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<ServiceType | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<ServiceType | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({ name: "", description: "", price: "", durationMin: "60", active: true });

  const fetchData = async () => {
    try {
      const data = await API.serviceTypes.list();
      setTypes(data);
    } catch (error) {
      console.error("Erro ao carregar tipos de serviço:", error);
      setTypes([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const payload = {
        name: form.name,
        description: form.description,
        price: parseFloat(form.price) || 0,
        durationMin: parseInt(form.durationMin) || 60,
        active: form.active,
      };
      if (editing) await API.serviceTypes.update(editing.id, payload);
      else await API.serviceTypes.create(payload);
      closeModal();
      onDataChange();
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    await API.serviceTypes.delete(confirmDelete.id);
    setConfirmDelete(null);
    onDataChange();
  };

  const handleEdit = (type: ServiceType) => {
    setEditing(type);
    setForm({
      name: type.name,
      description: type.description || "",
      price: type.price.toString(),
      durationMin: type.durationMin.toString(),
      active: type.active,
    });
    setShowModal(true);
  };

  const handleNew = () => {
    setEditing(null);
    setForm({ name: "", description: "", price: "", durationMin: "60", active: true });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditing(null);
    setForm({ name: "", description: "", price: "", durationMin: "60", active: true });
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === "checkbox") setForm(prev => ({ ...prev, [name]: (e.target as HTMLInputElement).checked }));
    else setForm(prev => ({ ...prev, [name]: value }));
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Tipos de Serviço</h2>
        <button onClick={handleNew} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">+ Novo Tipo</button>
      </div>

      {types.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl shadow-sm">
          <p className="text-gray-500 mb-4">Nenhum tipo de serviço cadastrado</p>
          <button onClick={handleNew} className="bg-blue-600 text-white px-4 py-2 rounded-lg">Criar primeiro</button>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nome</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Descrição</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Preço</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Duração</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {types.map(type => (
                <tr key={type.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">{type.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{type.description || "-"}</td>
                  <td className="px-6 py-4 text-right text-sm font-medium text-gray-900">R$ {Number(type.price).toFixed(2).replace(".", ",")}</td>
                  <td className="px-6 py-4 text-center text-sm text-gray-500">{type.durationMin} min</td>
                  <td className="px-6 py-4 text-center">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${type.active ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}`}>
                      {type.active ? "Ativo" : "Inativo"}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button onClick={() => handleEdit(type)} className="text-blue-600 hover:text-blue-900 text-sm font-medium">Editar</button>
                      <button onClick={() => setConfirmDelete(type)} className="text-red-600 hover:text-red-900 text-sm font-medium">Excluir</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <Modal title={editing ? "Editar Tipo de Serviço" : "Novo Tipo de Serviço"} onClose={closeModal} onSubmit={handleSubmit} submitting={submitting}>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nome *</label>
              <input type="text" name="name" value={form.name} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
              <textarea name="description" value={form.description} onChange={handleChange} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Preço *</label>
                <input type="number" step="0.01" min="0" name="price" value={form.price} onChange={handleChange} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Duração (min)</label>
                <input type="number" min="1" name="durationMin" value={form.durationMin} onChange={handleChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" name="active" checked={form.active} onChange={handleChange} id="active" className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
              <label htmlFor="active" className="text-sm text-gray-700">Ativo</label>
            </div>
          </div>
        </Modal>
      )}

      {confirmDelete && (
        <ConfirmDialog open={true} onClose={() => setConfirmDelete(null)} onConfirm={handleDelete} title="Excluir tipo" message={`Excluir "${confirmDelete.name}"?`} />
      )}
    </div>
  );
}