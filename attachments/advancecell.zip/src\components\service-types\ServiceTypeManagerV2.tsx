"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { Plus, Search, Edit, Trash2, Clock, DollarSign, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Modal } from "@/components/ui/Modal";
import { ConfirmDialog } from "@/components/ui/Modal";
import { Badge } from "@/components/ui/Badge";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/Table";
import { DropdownMenu } from "@/components/ui/Dropdown";
import { ServiceType } from "@/lib/types";
import { formatCurrency } from "@/lib/utils";
import API from "@/lib/api";
import { ChangeEvent, FormEvent, useState } from "react";

interface ServiceTypeManagerV2Props {
  onDataChange: () => void;
}

export function ServiceTypeManagerV2({ onDataChange }: ServiceTypeManagerV2Props) {
  const [types, setTypes] = useState<ServiceType[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<ServiceType | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<ServiceType | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [search, setSearch] = useState("");

  const [form, setForm] = useState({ name: "", description: "", price: "", durationMin: "60", active: true });

  const fetchData = async () => {
    setLoading(true);
    try {
      const data = await API.serviceTypes.list();
      setTypes(data);
    } catch (error) {
      console.error("Erro ao carregar tipos de serviço:", error);
      setTypes([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const payload = {
        name: form.name,
        description: form.description,
        price: parseFloat(form.price) || 0,
        durationMin: parseInt(form.durationMin) || 60,
        active: form.active,
      };
      if (editing) await API.serviceTypes.update(editing.id, payload);
      else await API.serviceTypes.create(payload);
      closeModal();
      onDataChange();
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    await API.serviceTypes.delete(confirmDelete.id);
    setConfirmDelete(null);
    onDataChange();
  };

  const handleEdit = (type: ServiceType) => {
    setEditing(type);
    setForm({
      name: type.name,
      description: type.description || "",
      price: type.price.toString(),
      durationMin: type.durationMin.toString(),
      active: type.active,
    });
    setShowModal(true);
  };

  const handleNew = () => {
    setEditing(null);
    setForm({ name: "", description: "", price: "", durationMin: "60", active: true });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditing(null);
    setForm({ name: "", description: "", price: "", durationMin: "60", active: true });
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === "checkbox") setForm(prev => ({ ...prev, [name]: (e.target as HTMLInputElement).checked }));
    else setForm(prev => ({ ...prev, [name]: value }));
  };

  const typeActions = (type: ServiceType) => [
    { label: "Editar", value: `edit-${type.id}`, icon: <Edit className="h-4 w-4" /> },
    { label: "Excluir", value: `delete-${type.id}`, icon: <Trash2 className="h-4 w-4" />, danger: true },
  ];

  const handleAction = (value: string) => {
    const [action, id] = value.split("-");
    const type = types.find(t => t.id === id);
    if (!type) return;
    
    switch (action) {
      case "edit": handleEdit(type); break;
      case "delete": setConfirmDelete(type); break;
    }
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div></div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Tipos de Serviço</h1>
          <p className="text-gray-500 mt-1">Serviços padronizados para agilizar o atendimento.</p>
        </div>
        <Button onClick={handleNew}><Plus className="h-4 w-4 mr-2" /> Novo Tipo</Button>
      </div>

      <div className="card bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-col sm:flex-row gap-4 mb-4">
          <div className="flex-1">
            <Input placeholder="Buscar serviços..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
        </div>

        {types.length === 0 ? (
          <div className="text-center py-12">
            <div className="h-12 w-12 mx-auto bg-gray-100 rounded-full flex items-center justify-center mb-3">
              <DollarSign className="h-6 w-6 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-1">Nenhum tipo de serviço</h3>
            <p className="text-gray-500 mb-4">Crie tipos de serviço para padronizar os atendimentos</p>
            <Button onClick={handleNew}><Plus className="h-4 w-4 mr-2" /> Criar primeiro</Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Serviço</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead className="w-28 text-right">Preço</TableHead>
                  <TableHead className="w-24 text-center">Duração</TableHead>
                  <TableHead className="w-24 text-center">Status</TableHead>
                  <TableHead className="w-40">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {types.map((type) => (
                  <TableRow key={type.id}>
                    <TableCell>
                      <p className="font-medium text-gray-900">{type.name}</p>
                    </TableCell>
                    <TableCell className="text-gray-500">{type.description || "-"}</TableCell>
                    <TableCell className="text-right font-medium text-gray-900">{formatCurrency(Number(type.price))}</TableCell>
                    <TableCell className="text-center text-gray-500">{type.durationMin} min</TableCell>
                    <TableCell className="text-center">
                      <Badge variant={type.active ? "success" : "secondary"}>{type.active ? "Ativo" : "Inativo"}</Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu
                        trigger={<Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="h-4 w-4" /></Button>}
                        items={[
                          { label: "Editar", value: `edit-${type.id}`, icon: <Edit className="h-4 w-4" /> },
                          { label: "Excluir", value: `delete-${type.id}`, icon: <Trash2 className="h-4 w-4" />, danger: true },
                        ]}
                        onSelect={handleAction}
                        align="right"
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      {showModal && (
        <Modal
          open={true}
          onClose={closeModal}
          title={editing ? `Editar Serviço: ${editing.name}` : "Novo Tipo de Serviço"}
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <Input label="Nome *" name="name" value={form.name} onChange={handleChange} required placeholder="Ex: Troca de tela, Limpeza, Diagnóstico" />
              <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
              <textarea name="description" value={form.description} onChange={handleChange} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input label="Preço *" name="price" type="number" step="0.01" min="0" value={form.price} onChange={handleChange} required />
                <Input label="Duração (minutos)" name="durationMin" type="number" min="1" value={form.durationMin} onChange={handleChange} />
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" name="active" checked={form.active} onChange={handleChange} id="active" className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
                <label htmlFor="active" className="text-sm text-gray-700">Serviço Ativo</label>
              </div>
            </div>
            <div className="flex justify-end gap-3 border-t pt-6">
              <Button type="button" variant="outline" onClick={closeModal}>Cancelar</Button>
              <Button type="submit" loading={submitting}>{submitting ? "Salvando..." : editing ? "Atualizar" : "Criar Serviço"}</Button>
            </div>
          </form>
        </Modal>
      )}

      {confirmDelete && (
        <ConfirmDialog
          open={true}
          onClose={() => setConfirmDelete(null)}
          onConfirm={handleDelete}
          title="Excluir Tipo de Serviço"
          message={`Tem certeza que deseja excluir "${confirmDelete.name}"?`}
          confirmLabel="Excluir"
          variant="destructive"
        />
      )}
    </div>
  );
}