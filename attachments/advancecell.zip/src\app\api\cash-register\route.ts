import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { CashRegisterStatus, CashMovementType } from "@prisma/client";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status");
  const page = parseInt(searchParams.get("page") || "1");
  const limit = parseInt(searchParams.get("limit") || "20");

  const where = status ? { status: status as CashRegisterStatus } : {};

  const [registers, total] = await Promise.all([
    prisma.cashRegister.findMany({
      where,
      include: {
        _count: { select: { movements: true } },
        movements: {
          where: { type: { in: [CashMovementType.SALE, CashMovementType.REFUND] } },
          select: { amount: true, paymentMethod: true },
        },
      },
      orderBy: { openedAt: "desc" },
      skip: (page - 1) * limit,
      take: limit,
    }),
    prisma.cashRegister.count({ where }),
  ]);

  const enriched = registers.map(r => {
    const salesByMethod = r.movements.reduce((acc, m) => {
      const key = m.paymentMethod || "Não informado";
      acc[key] = (acc[key] || 0) + Number(m.amount);
      return acc;
    }, {} as Record<string, number>);

    return {
      ...r,
      totalSales: r.movements.reduce((s, m) => s + Number(m.amount), 0),
      salesByMethod,
      openingAmount: Number(r.openingAmount),
      closingAmount: r.closingAmount ? Number(r.closingAmount) : null,
      expectedAmount: r.expectedAmount ? Number(r.expectedAmount) : null,
      difference: r.difference ? Number(r.difference) : null,
    };
  });

  return NextResponse.json({ data: enriched, total, page, totalPages: Math.ceil(total / limit) });
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const { openingAmount, notes, openedBy } = body;

  if (!openingAmount || openingAmount < 0) {
    return NextResponse.json({ error: "Valor de abertura inválido" }, { status: 400 });
  }

  const openRegister = await prisma.cashRegister.findFirst({
    where: { status: CashRegisterStatus.OPEN },
  });

  if (openRegister) {
    return NextResponse.json({ error: "Já existe um caixa aberto" }, { status: 400 });
  }

  const register = await prisma.cashRegister.create({
    data: {
      openingAmount,
      notes,
      openedBy: openedBy || "Sistema",
      status: CashRegisterStatus.OPEN,
    },
  });

  await prisma.cashMovement.create({
    data: {
      cashRegisterId: register.id,
      type: CashMovementType.OPENING,
      amount: openingAmount,
      description: "Abertura de caixa",
      createdBy: openedBy || "Sistema",
    },
  });

  return NextResponse.json(register, { status: 201 });
}