import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { CashRegisterStatus, CashMovementType } from "@prisma/client";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const cashRegisterId = searchParams.get("cashRegisterId");
  const type = searchParams.get("type");

  const where: Record<string, unknown> = {};
  if (cashRegisterId) where.cashRegisterId = cashRegisterId;
  if (type) where.type = type;

  const movements = await prisma.cashMovement.findMany({
    where,
    include: {
      cashRegister: { select: { sessionNumber: true } },
      serviceOrder: { select: { orderNumber: true, client: { select: { name: true } } } },
    },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json(movements.map(m => ({
    ...m,
    amount: Number(m.amount),
  })));
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const { cashRegisterId, type, amount, description, paymentMethod, serviceOrderId, createdBy } = body;

  if (!cashRegisterId || !type || amount === undefined || amount <= 0) {
    return NextResponse.json({ error: "Dados inválidos" }, { status: 400 });
  }

  const register = await prisma.cashRegister.findUnique({
    where: { id: cashRegisterId },
  });

  if (!register) {
    return NextResponse.json({ error: "Caixa não encontrado" }, { status: 404 });
  }

  if (register.status === CashRegisterStatus.CLOSED) {
    return NextResponse.json({ error: "Caixa está fechado" }, { status: 400 });
  }

  const movement = await prisma.cashMovement.create({
    data: {
      cashRegisterId,
      type: type as CashMovementType,
      amount,
      description,
      paymentMethod,
      serviceOrderId,
      createdBy: createdBy || "Sistema",
    },
  });

  return NextResponse.json({ ...movement, amount: Number(movement.amount) }, { status: 201 });
}