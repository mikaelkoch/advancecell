import { Category, Product, Client, ServiceOrder, ServiceType, ServiceOrderStatus, CashRegister, CashMovement, CashMovementType, WhatsAppSettings, WhatsAppLog, WhatsAppMessageType } from "@/lib/types";

const API = {
  categories: {
    list: () => fetch("/api/categories").then(r => r.json()),
    create: (data: Partial<Category>) => fetch("/api/categories", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    update: (id: string, data: Partial<Category>) => fetch(`/api/categories/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    delete: (id: string) => fetch(`/api/categories/${id}`, { method: "DELETE" }).then(r => r.json()),
  },
  products: {
    list: (params?: { categoryId?: string; search?: string }) => {
      const sp = new URLSearchParams();
      if (params?.categoryId) sp.set("categoryId", params.categoryId);
      if (params?.search) sp.set("search", params.search);
      return fetch(`/api/products?${sp}`).then(r => r.json());
    },
    create: (data: Partial<Product>) => fetch("/api/products", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    update: (id: string, data: Partial<Product>) => fetch(`/api/products/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    delete: (id: string) => fetch(`/api/products/${id}`, { method: "DELETE" }).then(r => r.json()),
  },
  clients: {
    list: (search?: string) => fetch(`/api/clients${search ? `?search=${search}` : ""}`).then(r => r.json()),
    get: (id: string) => fetch(`/api/clients/${id}`).then(r => r.json()),
    create: (data: Partial<Client>) => fetch("/api/clients", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    update: (id: string, data: Partial<Client>) => fetch(`/api/clients/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    delete: (id: string) => fetch(`/api/clients/${id}`, { method: "DELETE" }).then(r => r.json()),
  },
  serviceTypes: {
    list: () => fetch("/api/service-types").then(r => r.json()),
    create: (data: Partial<ServiceType>) => fetch("/api/service-types", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    update: (id: string, data: Partial<ServiceType>) => fetch(`/api/service-types/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    delete: (id: string) => fetch(`/api/service-types/${id}`, { method: "DELETE" }).then(r => r.json()),
  },
  serviceOrders: {
    list: (params?: { status?: ServiceOrderStatus; clientId?: string; search?: string }) => {
      const sp = new URLSearchParams();
      if (params?.status) sp.set("status", params.status);
      if (params?.clientId) sp.set("clientId", params.clientId);
      if (params?.search) sp.set("search", params.search);
      return fetch(`/api/service-orders?${sp}`).then(r => r.json());
    },
    get: (id: string) => fetch(`/api/service-orders/${id}`).then(r => r.json()),
    create: (data: Partial<ServiceOrder>) => fetch("/api/service-orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    update: (id: string, data: Partial<ServiceOrder>) => fetch(`/api/service-orders/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    delete: (id: string) => fetch(`/api/service-orders/${id}`, { method: "DELETE" }).then(r => r.json()),
  },
  cashRegister: {
    list: (status?: string, page = 1, limit = 20) => fetch(`/api/cash-register${status ? `?status=${status}` : ""}&page=${page}&limit=${limit}`).then(r => r.json()),
    get: (id: string) => fetch(`/api/cash-register/${id}`).then(r => r.json()),
    open: (openingAmount: number, notes: string, openedBy: string) => fetch("/api/cash-register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ openingAmount, notes, openedBy }) }).then(r => r.json()),
    close: (id: string, closingAmount: number, notes: string, closedBy: string) => fetch(`/api/cash-register/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "close", closingAmount, notes, closedBy }) }).then(r => r.json()),
  },
  cashMovements: {
    list: (cashRegisterId?: string, type?: CashMovementType) => {
      const sp = new URLSearchParams();
      if (cashRegisterId) sp.set("cashRegisterId", cashRegisterId);
      if (type) sp.set("type", type);
      return fetch(`/api/cash-movements?${sp}`).then(r => r.json());
    },
    create: (data: { cashRegisterId: string; type: CashMovementType; amount: number; description?: string; paymentMethod?: string; serviceOrderId?: string; createdBy: string }) =>
      fetch("/api/cash-movements", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
  },
  whatsapp: {
    getSettings: () => fetch("/api/whatsapp").then(r => r.json()),
    saveSettings: (data: Partial<WhatsAppSettings>) => fetch("/api/whatsapp", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    send: (data: { type: WhatsAppMessageType; to: string; message?: string; serviceOrderId?: string; clientId?: string; data?: Record<string, string> }) =>
      fetch("/api/whatsapp/send", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    getLogs: (limit = 50, offset = 0) => fetch(`/api/whatsapp/logs?limit=${limit}&offset=${offset}`).then(r => r.json()),
  },
  dashboard: {
    get: (period: "today" | "week" | "month" | "year") => fetch(`/api/dashboard?period=${period}`).then(r => r.json()),
  },
  reports: {
    get: (type: string, startDate: string, endDate: string, groupBy: string) => fetch(`/api/reports?type=${type}&startDate=${startDate}&endDate=${endDate}&groupBy=${groupBy}`).then(r => r.json()),
  },
};

export default API;