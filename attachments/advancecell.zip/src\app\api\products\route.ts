import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const categoryId = searchParams.get("categoryId");
  const featured = searchParams.get("featured");
  const lowStock = searchParams.get("lowStock");
  const search = searchParams.get("search");

  const where: Record<string, unknown> = {};
  if (categoryId) where.categoryId = categoryId;
  if (featured === "true") where.featured = true;
  if (lowStock === "true") where.stock = { lte: prisma.product.fields.minStock };
  if (search) {
    where.OR = [
      { name: { contains: search, mode: "insensitive" } },
      { sku: { contains: search, mode: "insensitive" } },
      { barcode: { contains: search, mode: "insensitive" } },
    ];
  }

  const products = await prisma.product.findMany({
    where,
    include: { category: true },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json(products);
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const slug = body.name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

  const product = await prisma.product.create({
    data: {
      name: body.name,
      slug,
      description: body.description,
      price: body.price,
      costPrice: body.costPrice,
      stock: body.stock || 0,
      minStock: body.minStock || 5,
      sku: body.sku,
      barcode: body.barcode,
      imageUrl: body.imageUrl,
      active: body.active !== false,
      featured: body.featured || false,
      categoryId: body.categoryId,
    },
    include: { category: true },
  });
  return NextResponse.json(product, { status: 201 });
}